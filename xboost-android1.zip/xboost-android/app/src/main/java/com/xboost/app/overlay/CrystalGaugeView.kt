package com.xboost.app.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.view.View
import kotlin.math.min

/**
 * A single "instrument" view combining four live stats (Temp / CPU / RAM /
 * Storage) around a faceted octagon core — the ROG Game Genie-style
 * dashboard, redrawn for XBoost's real, non-root-limited numbers. Each of
 * the four corner readouts comes straight from SystemMonitor /
 * ThermalGuardManager (same sources the old 3-ring row used), so this is a
 * different presentation of real data, not a new set of fake numbers.
 *
 * `unknownX` flags mirror RingGaugeView's honesty rule: when a value can't
 * be read on a locked-down OEM build, that corner shows "—" instead of a
 * fabricated number.
 */
class CrystalGaugeView(context: Context) : View(context) {

    var tempC: Float = 0f
    var tempUnknown: Boolean = true
    var cpuPercent: Int = 0
    var cpuUnknown: Boolean = true
    var ramPercent: Int = 0
    var storagePercent: Int = 0

    private val density = context.resources.displayMetrics.density

    private val facetPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val edgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.4f * density
        color = Color.parseColor("#66FF6A2E")
    }
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F5F1EA")
        isFakeBoldText = true
        textAlign = Paint.Align.CENTER
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#9C97A3")
        textAlign = Paint.Align.CENTER
    }
    private val centerLabelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#9C97A3")
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    fun refresh(
        tempC: Float?,
        cpuPercent: Int?,
        ramPercent: Int,
        storagePercent: Int
    ) {
        this.tempUnknown = tempC == null
        this.tempC = tempC ?: 0f
        this.cpuUnknown = cpuPercent == null
        this.cpuPercent = cpuPercent ?: 0
        this.ramPercent = ramPercent
        this.storagePercent = storagePercent
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val target = (168 * density).toInt()
        setMeasuredDimension(target, target)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val coreRadius = min(w, h) * 0.19f

        // Faceted octagon core, ember-to-graphite gradient like a cut gem.
        facetPaint.shader = LinearGradient(
            cx, cy - coreRadius, cx, cy + coreRadius,
            Color.parseColor("#2A1810"), Color.parseColor("#0A090C"),
            Shader.TileMode.CLAMP
        )
        val octagon = octagonPath(cx, cy, coreRadius)
        canvas.drawPath(octagon, facetPaint)
        canvas.drawPath(octagon, edgePaint)

        // Small solid center dot + "LIVE" micro-label, anchors the eye.
        corePaint.color = Color.parseColor("#FF6A2E")
        canvas.drawCircle(cx, cy, 3.2f * density, corePaint)
        centerLabelPaint.textSize = 8f * density
        canvas.drawText("XBOOST", cx, cy + coreRadius + 12f * density, centerLabelPaint)

        // Four corner readouts: Temp (top), RAM (right), Storage (bottom), CPU (left) —
        // matches the reference layout's north/east/south/west stat placement.
        val armLen = min(w, h) * 0.40f
        drawStat(canvas, cx, cy - armLen, if (tempUnknown) "—" else "%.0f°".format(tempC), "TEMP", thermalColor())
        drawStat(canvas, cx + armLen, cy, "$ramPercent%", "RAM", Color.parseColor("#3FC8FF"))
        drawStat(canvas, cx, cy + armLen, "$storagePercent%", "STORAGE", Color.parseColor("#B9FF4D"))
        drawStat(canvas, cx - armLen, cy, if (cpuUnknown) "—" else "$cpuPercent%", "CPU", Color.parseColor("#FF6A2E"))

        // Thin connecting spokes from core to each readout, faint circuit-trace look.
        edgePaint.alpha = 90
        canvas.drawLine(cx, cy, cx, cy - armLen + 14f * density, edgePaint)
        canvas.drawLine(cx, cy, cx + armLen - 14f * density, cy, edgePaint)
        canvas.drawLine(cx, cy, cx, cy + armLen - 14f * density, edgePaint)
        canvas.drawLine(cx, cy, cx - armLen + 14f * density, cy, edgePaint)
        edgePaint.alpha = 255
    }

    private fun thermalColor(): Int = when {
        tempUnknown -> Color.parseColor("#9C97A3")
        tempC >= 42f -> Color.parseColor("#FF6A2E")
        tempC >= 37f -> Color.parseColor("#FFC24D")
        else -> Color.parseColor("#B9FF4D")
    }

    private fun drawStat(canvas: Canvas, x: Float, y: Float, value: String, label: String, color: Int) {
        valuePaint.textSize = 14f * density
        valuePaint.color = color
        canvas.drawText(value, x, y - 2f * density, valuePaint)
        labelPaint.textSize = 8f * density
        canvas.drawText(label, x, y + 11f * density, labelPaint)
    }

    /** 8-point octagon path inscribed in the given radius, flat-topped facets. */
    private fun octagonPath(cx: Float, cy: Float, r: Float): Path {
        val path = Path()
        val k = r * 0.41f // inset for the flat facet corners
        val pts = listOf(
            cx - k to cy - r, cx + k to cy - r,
            cx + r to cy - k, cx + r to cy + k,
            cx + k to cy + r, cx - k to cy + r,
            cx - r to cy + k, cx - r to cy - k
        )
        pts.forEachIndexed { i, (px, py) ->
            if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        path.close()
        return path
    }
}
