package com.xboost.app.overlay

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.xboost.app.MainActivity
import com.xboost.app.R
import com.xboost.app.core.BoosterEngine
import com.xboost.app.core.DeviceCompat
import com.xboost.app.core.PreferencesManager
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

/**
 * The real "Auto Game Mode" engine. Before this, game detection only ran
 * inside BoostScreen's own polling loop — which is gated on XBoost's
 * Activity being in the foreground, i.e. exactly the moment a real game is
 * NOT what's on screen. So auto-detection silently never fired for an
 * actual play session. This service polls independently of XBoost's UI, so
 * it keeps working while you're actually in the game.
 *
 * What it does when a known game (BoosterEngine.KNOWN_GAMES) enters the
 * foreground:
 *  - applies the saved per-game DND profile (a real, system-wide toggle —
 *    unlike "Screen Awake", which only controls XBoost's own window and
 *    genuinely can't follow you into another app without root/Accessibility
 *    tricks this project deliberately avoids)
 *  - auto-shows the Floating Quick Panel edge handle (if the user hasn't already
 *    pinned it on permanently, and only if overlay permission is granted —
 *    never a silent no-op)
 * ...and auto-collapses/stops that same auto-shown panel a few seconds
 * after you leave the game, so it doesn't linger and cost battery.
 *
 * Started/stopped only from the Auto Game Mode switch (Modules screen /
 * Boost screen) — same explicit opt-in pattern as every other foreground
 * service in this app.
 */
class GameWatcherService : Service() {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var pollIntervalMs = 4000L
    private var trackedGamePkg: String? = null
    private var lastSeenGameAtMs: Long = 0L
    private val gracePeriodMs = 12_000L
    // Tracks whether THIS watcher is the one that turned DND on for the
    // current game, so onGameLeft() knows to turn it back off. Without this
    // flag, DND enabled via onGameEntered() never got switched off again —
    // it silently stayed on system-wide after the user left the game.
    private var dndAppliedByWatcher = false

    private val poller = object : Runnable {
        override fun run() {
            pollOnce()
            mainHandler.postDelayed(this, pollIntervalMs)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        // Deliberately more conservative than the in-app live-stats loop:
        // this runs constantly in the background for the whole session, on
        // every RAM tier from ~1GB up, so it should cost as little as
        // possible per wakeup.
        pollIntervalMs = maxOf(4000L, DeviceCompat.classify(applicationContext).pollingFloorMs * 3)
        startForeground(NOTIF_ID, buildNotification())
        mainHandler.post(poller)
    }

    override fun onDestroy() {
        mainHandler.removeCallbacks(poller)
        super.onDestroy()
    }

    private fun pollOnce() {
        val fg = runCatching { BoosterEngine.currentForegroundApp(applicationContext) }.getOrNull()
        val customGames = runCatching {
            runBlocking { PreferencesManager.customGames(applicationContext).first() }
        }.getOrDefault(emptySet())
        val isKnownGame = fg != null && (BoosterEngine.KNOWN_GAMES.containsKey(fg) || customGames.contains(fg))
        val now = System.currentTimeMillis()

        if (isKnownGame) {
            lastSeenGameAtMs = now
            if (fg != trackedGamePkg) {
                trackedGamePkg = fg
                onGameEntered(fg!!)
            }
        } else if (trackedGamePkg != null && now - lastSeenGameAtMs > gracePeriodMs) {
            onGameLeft()
            trackedGamePkg = null
        }
    }

    private fun onGameEntered(pkg: String) {
        val dndPkgs = runCatching {
            runBlocking { PreferencesManager.profileDndPackages(applicationContext).first() }
        }.getOrDefault(emptySet())
        if (dndPkgs.contains(pkg)) {
            BoosterEngine.setGameDnd(applicationContext, true)
            dndAppliedByWatcher = true
        }

        if (!com.xboost.app.core.PermissionManager.hasOverlayPermission(applicationContext)) return
        if (FloatingPanelService.isRunning()) {
            FloatingPanelService.notifyGameForeground(pkg)
        } else {
            val intent = Intent(applicationContext, FloatingPanelService::class.java)
                .putExtra(FloatingPanelService.EXTRA_AUTO_GAME_PKG, pkg)
            ContextCompat.startForegroundService(this, intent)
        }
    }

    private fun onGameLeft() {
        FloatingPanelService.notifyGameForeground(null)
        // Only ever stops a panel THIS watcher opened — a panel the user
        // pinned on permanently via the Floating Quick Panel switch is
        // never touched here.
        if (FloatingPanelService.isAutoLaunched()) {
            stopService(Intent(applicationContext, FloatingPanelService::class.java))
        }
        // Mirror image of onGameEntered(): only switch DND back off if THIS
        // watcher was the one that turned it on for this game. If the user
        // (or the manual Quick Panel DND tile) enabled DND independently,
        // leave it alone — this only undoes its own side effect.
        if (dndAppliedByWatcher) {
            BoosterEngine.setGameDnd(applicationContext, false)
            dndAppliedByWatcher = false
        }
    }

    private fun buildNotification(): android.app.Notification {
        val channelId = "xboost_game_watcher"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(channelId, "Auto Game Mode", NotificationManager.IMPORTANCE_MIN)
            )
        }
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Auto Game Mode watching")
            .setContentText("Panel will pop up automatically when a known game opens")
            .setSmallIcon(R.drawable.ic_xboost_logo)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
    }

    companion object {
        private const val NOTIF_ID = 4204
    }
}
