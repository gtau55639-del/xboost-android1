package com.xboost.app.core

/**
 * Mobile Legends: Bang Bang meta reference data for the Game AI Assistant's
 * "Meta ML" tab — ban priority, S-tier pick list, and a handful of real
 * counter-pick matchups with their measured win-rate edge.
 *
 * This is the same kind of thing as GameContentRepository: a static,
 * offline, on-device reference table. It does not read the game's memory,
 * automate drafting, or touch the match in any way — it's a tier list you
 * could otherwise look up in a browser, just reachable without leaving
 * XBoost while you're in the draft screen.
 *
 * DATA SOURCE & FRESHNESS — please read before editing:
 * The numbers below are a manual snapshot (win rate / ban rate / counter
 * edge in percentage points) pulled from public MLBB stat trackers for
 * Patch 2.1.95, Season 41 ("Scarlet Embers"), snapshot date 26 Aug 2026.
 * MLBB's meta shifts with nearly every patch, and these third-party sites
 * refresh daily — so unlike the rest of GameContentRepository (which is
 * evergreen strategy advice), this file WILL go stale. Re-check a stats
 * tracker each patch and update [PATCH_LABEL] plus the tables below —
 * there is no live network call here on purpose (same offline-only
 * philosophy as the rest of the assistant), so nothing updates itself.
 */
data class MetaHeroStat(
    val name: String,
    val role: String,
    val winRate: Double,
    val banRate: Double? = null
)

/** A single matchup: [opponent] is the hero being compared against; [edgePp] is the win-rate edge in percentage points. */
data class MetaMatchup(val opponent: String, val edgePp: Double, val note: String)

data class HeroCounterProfile(
    val heroName: String,
    /** Heroes with the highest measured win rate AGAINST heroName — i.e. what to ban/pick to beat them. */
    val beatenBy: List<MetaMatchup>,
    /** Heroes heroName performs best against — i.e. good targets to pick heroName into. */
    val beats: List<MetaMatchup>
)

object MetaHeroRepository {

    const val PATCH_LABEL = "Patch 2.1.95 · Season 41 — snapshot 26 Agu 2026"
    const val SOURCE_NOTE = "Data win rate/ban rate/counter dari tracker publik MLBB (ranked, All Ranks kecuali disebutkan lain). " +
        "Meta berubah tiap patch — anggap ini starter reference, bukan angka yang dijamin akurat detik ini."

    /** All-Ranks first-ban priority, highest ban rate first. */
    val banPriorityAllRanks: List<MetaHeroStat> = listOf(
        MetaHeroStat("Belerick", "Tank", winRate = 53.2, banRate = 58.7),
        MetaHeroStat("Paquito", "Fighter", winRate = 50.7, banRate = 54.0),
        MetaHeroStat("Eudora", "Mage", winRate = 52.3, banRate = 53.2),
        MetaHeroStat("Hirara", "Assassin", winRate = 52.2, banRate = 53.0),
        MetaHeroStat("Gloo", "Tank", winRate = 54.5, banRate = 48.5)
    )

    /** All-Ranks S-tier pick list, sorted by win rate. */
    val sTierAllRanks: List<MetaHeroStat> = listOf(
        MetaHeroStat("Marcel", "Support", 58.9, 32.5),
        MetaHeroStat("Rafaela", "Support", 57.8, null),
        MetaHeroStat("Masha", "Fighter", 56.9, null),
        MetaHeroStat("Melissa", "Marksman", 56.5, null),
        MetaHeroStat("Hanzo", "Assassin", 56.3, 31.5),
        MetaHeroStat("Khufra", "Tank", 54.6, null),
        MetaHeroStat("Gloo", "Tank", 54.4, 48.1),
        MetaHeroStat("Minotaur", "Tank", 54.2, null),
        MetaHeroStat("Floryn", "Support", 53.7, 19.0),
        MetaHeroStat("Estes", "Support", 53.5, 37.7),
        MetaHeroStat("Belerick", "Tank", 53.2, 58.4),
        MetaHeroStat("Sun", "Fighter", 53.2, 40.4),
        MetaHeroStat("Miya", "Marksman", 53.2, 17.4)
    )

    /**
     * Per-rank win rate for the two heroes we have full rank-bracket data
     * for (Belerick, Gloo) — shows how much the same hero's numbers swing
     * from Epic to Mythical Glory+, which is the honest answer to "beda gak
     * sih meta di rank aku sama rank orang lain".
     */
    val rankBrackets: List<String> = listOf("Epic", "Legend", "Mythic", "Mythical Honor", "Mythical Glory+")

    val winRateByRank: Map<String, Map<String, Double>> = mapOf(
        "Belerick" to mapOf(
            "Epic" to 56.07, "Legend" to 55.55, "Mythic" to 54.30,
            "Mythical Honor" to 53.26, "Mythical Glory+" to 51.82
        ),
        "Gloo" to mapOf(
            "Epic" to 55.21, "Legend" to 56.38, "Mythic" to 56.62,
            "Mythical Honor" to 55.44, "Mythical Glory+" to 53.28
        )
    )

    /** Real counter-matchup data (measured win-rate edge in pp) for the flagship bans of this patch. */
    val counterProfiles: Map<String, HeroCounterProfile> = mapOf(
        "Belerick" to HeroCounterProfile(
            heroName = "Belerick",
            beatenBy = listOf(
                MetaMatchup("Lesley", 3.2, "Unggul di late game — biarkan Belerick nge-tank, menang lewat scaling."),
                MetaMatchup("Beatrix", 3.2, "Dominan di early game — tekan sebelum Belerick sempat stack."),
                MetaMatchup("Brody", 3.1, "Dominan di early game — jangan kasih dia waktu buat scale."),
                MetaMatchup("Marcel", 2.8, "Dominan di early game lewat zoning dari Golden Hour."),
                MetaMatchup("Xavier", 2.2, "Serangan jarak jauh bikin Deadly Thorns Belerick gak kena.")
            ),
            beats = listOf(
                MetaMatchup("Miya", 2.8, "Belerick unggul early — kontrol tempo sebelum Miya scale."),
                MetaMatchup("Silvanna", 2.6, "Belerick unggul early game."),
                MetaMatchup("Zhask", 2.5, "Belerick unggul early game.")
            )
        ),
        "Gloo" to HeroCounterProfile(
            heroName = "Gloo",
            beatenBy = listOf(
                MetaMatchup("Faramis", 6.3, "Statistik matchup paling timpang buat lawan Gloo musim ini."),
                MetaMatchup("Moskov", 5.1, "Outscale Gloo di late game."),
                MetaMatchup("Alice", 4.1, "Durability + sustain Alice unggul sepanjang game."),
                MetaMatchup("Natan", 4.0, "Statistik matchup unggul lewat mobilitas & burst."),
                MetaMatchup("Ling", 4.0, "Outscale di late game, sulit di-attach karena mobile.")
            ),
            beats = listOf(
                MetaMatchup("Aamon", 4.7, "Gloo unggul telak — assassin burst rendah durability gampang di-attach."),
                MetaMatchup("Johnson", 3.8, "Gloo unggul early game."),
                MetaMatchup("Chang'e", 2.8, "Mage tanpa CC kuat gampang di-attach dan diarahkan Gloo.")
            )
        )
    )

    fun banPriorityFor(pkg: String): List<MetaHeroStat> = if (pkg == ML_PACKAGE) banPriorityAllRanks else emptyList()
    fun sTierFor(pkg: String): List<MetaHeroStat> = if (pkg == ML_PACKAGE) sTierAllRanks else emptyList()
    fun counterProfileFor(heroName: String): HeroCounterProfile? = counterProfiles[heroName]
    fun heroesWithCounterData(): List<String> = counterProfiles.keys.toList()

    /** Only Mobile Legends has this tab wired up for now — extend this map/const if another MOBA is added later. */
    const val ML_PACKAGE = "com.mobile.legends"
    fun isSupported(pkg: String): Boolean = pkg == ML_PACKAGE
}
