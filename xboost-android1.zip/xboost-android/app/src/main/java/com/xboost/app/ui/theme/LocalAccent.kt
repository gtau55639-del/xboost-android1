package com.xboost.app.ui.theme

import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color

data class AccentColors(val primary: Color, val secondary: Color)

val LocalAccent = compositionLocalOf { AccentColors(XRed, XCyan) }
