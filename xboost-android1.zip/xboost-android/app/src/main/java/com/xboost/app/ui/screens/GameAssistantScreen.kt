package com.xboost.app.ui.screens

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.xboost.app.core.BoosterEngine
import com.xboost.app.core.GameContentRepository
import com.xboost.app.core.MetaHeroRepository
import com.xboost.app.core.MetaHeroStat
import com.xboost.app.core.MetaMatchup
import com.xboost.app.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

private enum class AssistantTab { AI_TIPS, GUIDE, META }

private data class ChatLine(val fromUser: Boolean, val text: String)

/**
 * Two tabs:
 *  - AI Tips: a chat-style box where the user types a question and gets back
 *    the closest matching curated tip via a scored keyword lookup. Purely
 *    offline — this label is honest about what it is, same philosophy as
 *    the rest of XBoost.
 *  - Guide: always-visible structured tips for the selected game.
 *
 * Neither tab reads game memory, injects input, or automates play in any
 * way — that's permanently out of scope for XBoost by design (see README
 * and GameContentRepository). Nothing here can be turned into a cheat.
 */
@Composable
fun GameAssistantScreen(pkg: String, onBack: () -> Unit) {
    val gameName = BoosterEngine.KNOWN_GAMES[pkg] ?: "This game"
    var tab by remember { mutableStateOf(AssistantTab.AI_TIPS) }
    val accent = LocalAccent.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(GradientBgTop, BgDeep, GradientBgBottom)))
            .padding(horizontal = 20.dp, vertical = 20.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(30.dp)
                    .clip(CircleShape)
                    .background(PanelGlass)
                    .clickable { onBack() },
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Text1, modifier = Modifier.size(16.dp))
            }
            Spacer(Modifier.width(10.dp))
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(accent.primary, accent.secondary))),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.SmartToy, contentDescription = null, tint = Color.White, modifier = Modifier.size(17.dp))
            }
            Spacer(Modifier.width(10.dp))
            Column {
                Text("GAME AI ASSISTANT", color = Text2, fontSize = 10.sp, letterSpacing = 1.sp)
                Text(gameName, color = Text0, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            }
        }
        Spacer(Modifier.height(14.dp))

        val showMetaTab = MetaHeroRepository.isSupported(pkg)

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(PanelGlass, RoundedCornerShape(12.dp))
                .border(1.dp, LineSoft, RoundedCornerShape(12.dp))
                .padding(3.dp)
        ) {
            AssistantTabButton("AI Tips", Icons.Filled.SmartToy, tab == AssistantTab.AI_TIPS, Modifier.weight(1f)) { tab = AssistantTab.AI_TIPS }
            AssistantTabButton("Guide", Icons.Filled.MenuBook, tab == AssistantTab.GUIDE, Modifier.weight(1f)) { tab = AssistantTab.GUIDE }
            if (showMetaTab) {
                AssistantTabButton("Meta ML", Icons.Filled.Leaderboard, tab == AssistantTab.META, Modifier.weight(1f)) { tab = AssistantTab.META }
            }
        }
        Spacer(Modifier.height(14.dp))

        when (tab) {
            AssistantTab.AI_TIPS -> AiTipsTab(pkg)
            AssistantTab.GUIDE -> GuideTab(pkg)
            AssistantTab.META -> if (showMetaTab) MetaHeroTab(pkg) else GuideTab(pkg)
        }
    }
}

@Composable
private fun AssistantTabButton(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val accent = LocalAccent.current
    Row(
        modifier = modifier
            .background(
                if (selected) accent.primary.copy(alpha = 0.18f) else Color.Transparent,
                RoundedCornerShape(9.dp)
            )
            .clickable { onClick() }
            .padding(vertical = 9.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = if (selected) accent.primary else Text2, modifier = Modifier.size(15.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = if (selected) Text0 else Text2, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun AiTipsTab(pkg: String) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf<ChatLine>() }
    var isTyping by remember { mutableStateOf(false) }
    val suggestions = remember(pkg) { GameContentRepository.suggestedQuestions(pkg) }
    val listState = remember { LazyListState() }

    fun ask(question: String) {
        if (question.isBlank() || isTyping) return
        messages.add(ChatLine(fromUser = true, text = question))
        input = ""
        isTyping = true
        scope.launch {
            // Small artificial delay so the reply doesn't just teleport in —
            // purely cosmetic pacing, the lookup itself is instant and fully
            // on-device (no network round trip is actually happening here).
            delay(420)
            val ans = GameContentRepository.answer(pkg, question)
            messages.add(
                ChatLine(
                    fromUser = false,
                    text = ans ?: "Belum ada tips spesifik untuk itu di database offline XBoost — coba tab Guide buat tips umum, atau tanya dengan kata kunci lain."
                )
            )
            isTyping = false
            listState.animateScrollToItem((messages.size - 1).coerceAtLeast(0))
        }
    }

    // Voice input: hands off to the system speech recognizer (Google app or
    // OEM equivalent) via the standard RECOGNIZE_SPEECH intent — XBoost never
    // records audio itself, so no RECORD_AUDIO permission is needed here.
    val speechLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!spoken.isNullOrBlank()) ask(spoken)
        }
    }

    fun launchVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toString())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Tanya XBoost…")
        }
        // resolveActivity requires the <queries> entry in AndroidManifest.xml on
        // Android 11+ (package visibility) — without it this silently returns null
        // even when a speech recognizer IS installed.
        if (intent.resolveActivity(context.packageManager) != null) {
            runCatching { speechLauncher.launch(intent) }
                .onFailure { Toast.makeText(context, "Gak bisa buka voice input di device ini", Toast.LENGTH_SHORT).show() }
        } else {
            Toast.makeText(context, "Voice input gak tersedia — device ini gak punya speech recognizer terpasang", Toast.LENGTH_SHORT).show()
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(XCyanDim, RoundedCornerShape(10.dp))
                .padding(horizontal = 10.dp, vertical = 8.dp)
        ) {
            Icon(Icons.Filled.Info, contentDescription = null, tint = XCyan, modifier = Modifier.size(13.dp))
            Spacer(Modifier.width(6.dp))
            Text(
                "Offline tips lookup di HP kamu sendiri — bukan cloud AI, dan gak pernah main, aim, atau " +
                "otomatisasi apapun di dalam game buat kamu.",
                color = Text1, fontSize = 10.sp, lineHeight = 14.sp
            )
        }
        Spacer(Modifier.height(10.dp))

        if (messages.isEmpty()) {
            Text("Coba tanya:", color = Text2, fontSize = 10.sp, modifier = Modifier.padding(bottom = 6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(bottom = 10.dp)) {
                suggestions.forEach { s ->
                    SuggestionChip(
                        onClick = { ask(s) },
                        label = { Text(s, fontSize = 10.sp) },
                        colors = SuggestionChipDefaults.suggestionChipColors(containerColor = PanelGlass, labelColor = XCyan),
                        border = SuggestionChipDefaults.suggestionChipBorder(
                            enabled = true,
                            borderColor = XCyan.copy(alpha = 0.35f)
                        )
                    )
                }
            }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages) { line -> ChatBubble(line) }
            if (isTyping) {
                item { TypingBubble() }
            }
        }

        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Ketik atau tap mic…", fontSize = 12.sp) },
                singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 13.sp, color = Text0),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = XCyan, unfocusedBorderColor = LineSoft,
                    focusedTextColor = Text0, unfocusedTextColor = Text0
                )
            )
            Spacer(Modifier.width(8.dp))
            IconButton(
                onClick = { launchVoiceInput() },
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(PanelGlass)
            ) {
                Icon(Icons.Filled.Mic, contentDescription = "Voice input", tint = XCyan)
            }
            Spacer(Modifier.width(6.dp))
            IconButton(
                onClick = { ask(input.trim()) },
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(Brush.linearGradient(listOf(XCyan.copy(alpha = 0.35f), XCyanDim)))
            ) {
                Icon(Icons.Filled.Send, contentDescription = "Send", tint = XCyan)
            }
        }
    }
}

@Composable
private fun ChatBubble(line: ChatLine) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (line.fromUser) Arrangement.End else Arrangement.Start
    ) {
        if (!line.fromUser) {
            AssistantAvatar()
            Spacer(Modifier.width(6.dp))
        }
        Column(
            modifier = Modifier
                .background(
                    if (line.fromUser) Brush.linearGradient(listOf(XCyan.copy(alpha = 0.22f), XCyanDim))
                    else Brush.verticalGradient(listOf(PanelGlassHi, PanelGlass)),
                    RoundedCornerShape(14.dp)
                )
                .border(1.dp, if (line.fromUser) XCyan.copy(alpha = 0.4f) else LineSoft, RoundedCornerShape(14.dp))
                .widthIn(max = 250.dp)
                .padding(10.dp)
        ) {
            if (!line.fromUser) {
                Text("XBoost Tips", color = XCyan, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 3.dp))
            }
            Text(line.text, color = Text0, fontSize = 12.sp, lineHeight = 16.sp)
        }
    }
}

@Composable
private fun AssistantAvatar() {
    val accent = LocalAccent.current
    Box(
        modifier = Modifier
            .size(22.dp)
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(accent.primary, accent.secondary))),
        contentAlignment = Alignment.Center
    ) {
        Icon(Icons.Filled.SmartToy, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
    }
}

/** Three-dot "typing…" indicator, shown briefly while the offline lookup "thinks". */
@Composable
private fun TypingBubble() {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
        AssistantAvatar()
        Spacer(Modifier.width(6.dp))
        Row(
            modifier = Modifier
                .background(PanelGlass, RoundedCornerShape(14.dp))
                .border(1.dp, LineSoft, RoundedCornerShape(14.dp))
                .padding(horizontal = 14.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val transition = rememberInfiniteTransition(label = "typing")
            repeat(3) { i ->
                val delayMs = i * 140
                val alpha by transition.animateFloat(
                    initialValue = 0.25f,
                    targetValue = 1f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(600, delayMillis = delayMs, easing = FastOutSlowInEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "dot$i"
                )
                Box(
                    modifier = Modifier
                        .size(5.dp)
                        .clip(CircleShape)
                        .background(XCyan.copy(alpha = alpha))
                )
            }
        }
    }
}

/**
 * "Meta ML" tab — ban priority, S-tier pick list, and a couple of real
 * counter-pick matchups, sourced from MetaHeroRepository (see that file's
 * header for exactly where the numbers come from and how stale they can
 * get). Purely a reference lookup: nothing here reads or automates the
 * actual draft screen, same offline-only rule as the AI Tips/Guide tabs.
 */
@Composable
private fun MetaHeroTab(pkg: String) {
    var subTab by remember { mutableStateOf(0) } // 0 = Ban/Pick, 1 = Counter Lookup
    val scroll = rememberScrollState()

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(PanelGlassHi, RoundedCornerShape(10.dp))
                .border(1.dp, LineSoft, RoundedCornerShape(10.dp))
                .padding(10.dp)
        ) {
            Icon(Icons.Filled.Info, contentDescription = null, tint = XCyan, modifier = Modifier.size(13.dp))
            Spacer(Modifier.width(6.dp))
            Column {
                Text(MetaHeroRepository.PATCH_LABEL, color = Text0, fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold)
                Text(MetaHeroRepository.SOURCE_NOTE, color = Text2, fontSize = 9.5.sp, lineHeight = 13.sp)
            }
        }
        Spacer(Modifier.height(10.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetaSubTabChip("Ban & Pick", subTab == 0) { subTab = 0 }
            MetaSubTabChip("Cek Counter", subTab == 1) { subTab = 1 }
        }
        Spacer(Modifier.height(12.dp))

        Column(modifier = Modifier.weight(1f).verticalScroll(scroll)) {
            if (subTab == 0) {
                MetaHeroSection(
                    title = "Prioritas Ban (All Ranks)",
                    icon = Icons.Filled.Block,
                    accent = XRed,
                    heroes = MetaHeroRepository.banPriorityFor(pkg),
                    showBanRate = true
                )
                Spacer(Modifier.height(14.dp))
                MetaHeroSection(
                    title = "S-Tier Pick (All Ranks)",
                    icon = Icons.Filled.Star,
                    accent = XCyan,
                    heroes = MetaHeroRepository.sTierFor(pkg),
                    showBanRate = false
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "Angka win rate bisa geser beberapa poin tergantung rank kamu — makin tinggi rank, makin penting counter-pick dibanding cuma ikut tier list.",
                    color = Text2, fontSize = 10.sp, lineHeight = 14.sp
                )
            } else {
                CounterLookupSection()
            }
            Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
private fun MetaSubTabChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val accent = LocalAccent.current
    Box(
        modifier = Modifier
            .background(if (selected) accent.primary.copy(alpha = 0.18f) else PanelGlass, RoundedCornerShape(20.dp))
            .border(1.dp, if (selected) accent.primary.copy(alpha = 0.5f) else LineSoft, RoundedCornerShape(20.dp))
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(label, color = if (selected) Text0 else Text2, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun MetaHeroSection(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accent: Color,
    heroes: List<MetaHeroStat>,
    showBanRate: Boolean
) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(6.dp))
            Text(title, color = Text0, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        }
        Spacer(Modifier.height(8.dp))
        heroes.forEachIndexed { index, hero ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(PanelGlass, RoundedCornerShape(10.dp))
                    .border(1.dp, LineSoft, RoundedCornerShape(10.dp))
                    .padding(horizontal = 12.dp, vertical = 9.dp)
                    .then(if (index > 0) Modifier.padding(top = 0.dp) else Modifier),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("#${index + 1}", color = Text2, fontSize = 10.sp, modifier = Modifier.width(22.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(hero.name, color = Text0, fontSize = 12.5.sp, fontWeight = FontWeight.Medium)
                    Text(hero.role, color = Text2, fontSize = 9.5.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("${hero.winRate}% WR", color = XCyan, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    if (showBanRate && hero.banRate != null) {
                        Text("${hero.banRate}% ban", color = XRed, fontSize = 9.5.sp)
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
        }
    }
}

@Composable
private fun CounterLookupSection() {
    val heroNames = remember { MetaHeroRepository.heroesWithCounterData() }
    var selected by remember { mutableStateOf(heroNames.firstOrNull()) }
    val profile = remember(selected) { selected?.let { MetaHeroRepository.counterProfileFor(it) } }

    Text("Pilih hero yang mau di-cek:", color = Text2, fontSize = 10.5.sp, modifier = Modifier.padding(bottom = 8.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        heroNames.forEach { name ->
            MetaSubTabChip(name, selected == name) { selected = name }
        }
    }
    Spacer(Modifier.height(14.dp))

    if (profile == null) {
        Text(
            "Belum ada data counter offline buat hero ini. Database di XBoost baru nyimpen matchup buat hero yang paling sering di-ban musim ini — bakal nambah tiap update.",
            color = Text2, fontSize = 11.sp, lineHeight = 15.sp
        )
        return
    }

    MatchupList(
        heading = "Cara ngalahin ${profile.heroName}",
        subheading = "Hero dengan win rate tertinggi saat lawan ${profile.heroName} — ban atau pick ini buat keunggulan statistik.",
        accent = XCyan,
        matchups = profile.beatenBy
    )
    Spacer(Modifier.height(16.dp))
    MatchupList(
        heading = "${profile.heroName} kuat lawan siapa",
        subheading = "Pertimbangkan pick ${profile.heroName} kalau musuh draft salah satu dari ini.",
        accent = XRed,
        matchups = profile.beats
    )
}

@Composable
private fun MatchupList(heading: String, subheading: String, accent: Color, matchups: List<MetaMatchup>) {
    Text(heading, color = Text0, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    Text(subheading, color = Text2, fontSize = 10.5.sp, lineHeight = 14.sp, modifier = Modifier.padding(top = 2.dp, bottom = 8.dp))
    matchups.forEach { m ->
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(PanelGlass, RoundedCornerShape(10.dp))
                .border(1.dp, LineSoft, RoundedCornerShape(10.dp))
                .padding(horizontal = 12.dp, vertical = 9.dp)
                .padding(bottom = 6.dp),
            verticalAlignment = Alignment.Top
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(m.opponent, color = Text0, fontSize = 12.5.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.width(8.dp))
                    Text("+${m.edgePp}pp", color = accent, fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold)
                }
                Text(m.note, color = Text2, fontSize = 10.5.sp, lineHeight = 14.sp, modifier = Modifier.padding(top = 2.dp))
            }
        }
        Spacer(Modifier.height(6.dp))
    }
}

@Composable
private fun GuideTab(pkg: String) {
    val sections = remember(pkg) { GameContentRepository.guideFor(pkg) }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(sections) { section ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(PanelGlassHi, PanelGlass)), RoundedCornerShape(16.dp))
                    .border(1.dp, LineSoft, RoundedCornerShape(16.dp))
                    .padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(XCyanDim),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Filled.MenuBook, contentDescription = null, tint = XCyan, modifier = Modifier.size(13.dp))
                    }
                    Spacer(Modifier.width(8.dp))
                    Text(section.heading, color = Text0, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                }
                Spacer(Modifier.height(8.dp))
                section.points.forEach { point ->
                    Row(modifier = Modifier.padding(bottom = 6.dp)) {
                        Text("•  ", color = XCyan, fontSize = 12.sp)
                        Text(point, color = Text1, fontSize = 12.sp, lineHeight = 16.sp)
                    }
                }
            }
        }
    }
}
