package com.xboost.app.core

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.WindowManager

/**
 * Honest reality check on "120Hz unlock" for a non-root app:
 *  - There IS a real public API (Display.Mode / preferredDisplayModeId) that
 *    lets an app request a higher refresh rate — but it only affects THAT
 *    app's own window while it's in the foreground. A third-party app has
 *    no public API to force a *different* app (a game) into a higher
 *    refresh rate system-wide — that's controlled by
 *    Settings.System.PEAK_REFRESH_RATE / min_refresh_rate, which requires
 *    WRITE_SECURE_SETTINGS, a permission normal apps cannot be granted
 *    (only via ADB). Any app that claims to "unlock 120Hz in your games"
 *    without root/ADB is not telling the truth about how Android works.
 *
 * What this module actually, honestly does:
 *  1. Reports the real refresh rates your hardware + current OS setting support.
 *  2. Requests the highest available mode for XBoost's own window (so XBoost
 *     itself renders smooth if the device supports it).
 *  3. Deep-links straight to the system Display settings screen, where the
 *     user can flip the actual system-wide refresh rate toggle in two taps.
 */
data class RefreshRateInfo(
    val supportedRates: List<Float>,
    val currentRate: Float,
    val maxRate: Float,
    val highRefreshAvailable: Boolean
)

object DisplayRefreshManager {

    fun currentInfo(context: Context): RefreshRateInfo {
        val display = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            context.display
        } else {
            @Suppress("DEPRECATION")
            (context.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay
        }

        if (display == null) {
            return RefreshRateInfo(emptyList(), 60f, 60f, false)
        }

        val rates = display.supportedModes.map { it.refreshRate }.distinct().sortedDescending()
        val current = display.refreshRate
        val max = rates.maxOrNull() ?: current
        return RefreshRateInfo(rates, current, max, max > 60.5f)
    }

    /** Requests the highest mode for THIS app's window only — real, but scoped. Returns what it actually asked for. */
    fun requestHighRefreshForThisWindow(activity: Activity): Float? {
        val display = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) activity.display
            else @Suppress("DEPRECATION") activity.windowManager.defaultDisplay
        val bestMode = display?.supportedModes?.maxByOrNull { it.refreshRate } ?: return null

        val params = activity.window.attributes
        params.preferredDisplayModeId = bestMode.modeId
        activity.window.attributes = params
        return bestMode.refreshRate
    }

    fun openSystemDisplaySettings(context: Context) {
        val intent = Intent(Settings.ACTION_DISPLAY_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }
}
