package com.xboost.app.lock

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.xboost.app.MainActivity
import com.xboost.app.R
import com.xboost.app.core.BoosterEngine

/**
 * Polls the foreground app every 500ms using the same UsageStatsManager
 * approach as Auto Game Mode. This is the same technique real (non-root)
 * app-lockers use on modern Android — there's no public API that fires an
 * instant "app opened" callback without an AccessibilityService, which
 * carries far broader privacy permissions than App Lock needs. Trade-off:
 * up to ~0.5s delay before the PIN screen appears, and OEMs with aggressive
 * battery management may kill this service — documented in Settings, not
 * hidden.
 */
class LockGuardService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var lockedPackages: Set<String> = emptySet()
    private var running = false

    private val pollRunnable = object : Runnable {
        override fun run() {
            if (!running) return
            val fg = BoosterEngine.currentForegroundApp(applicationContext)
            UnlockSession.onForegroundChanged(fg)
            if (fg != null && lockedPackages.contains(fg) && !UnlockSession.isUnlocked(fg)) {
                val lockIntent = Intent(applicationContext, LockScreenActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    putExtra(LockScreenActivity.EXTRA_TARGET_PKG, fg)
                }
                startActivity(lockIntent)
            }
            handler.postDelayed(this, 500)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        lockedPackages = intent?.getStringArrayListExtra(EXTRA_LOCKED_PKGS)?.toSet() ?: lockedPackages
        return START_STICKY
    }

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIF_ID, buildNotification())
        running = true
        handler.post(pollRunnable)
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(pollRunnable)
        super.onDestroy()
    }

    private fun buildNotification(): android.app.Notification {
        val channelId = "xboost_app_lock"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(channelId, "App Lock", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("XBoost App Lock active")
            .setContentText("Guarding your locked apps")
            .setSmallIcon(R.drawable.ic_xboost_logo)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val EXTRA_LOCKED_PKGS = "locked_pkgs"
        private const val NOTIF_ID = 4202
    }
}
