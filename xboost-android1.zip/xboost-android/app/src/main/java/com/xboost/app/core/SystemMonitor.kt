package com.xboost.app.core

import android.app.ActivityManager
import android.content.Context
import java.io.RandomAccessFile
import kotlin.math.roundToInt

/**
 * Reads real, live device stats. No simulated/fake values.
 *
 * RAM: ActivityManager.MemoryInfo is a public, no-permission API — accurate on all devices.
 * CPU: /proc/stat is readable without root on most OEM skins, but some manufacturers
 *      (e.g. some MIUI / ColorOS builds) restrict it via SELinux. When that happens
 *      cpuUsagePercent() returns null — the UI must show "Unavailable", never a fake number.
 */
data class RamInfo(
    val usedMb: Long,
    val totalMb: Long,
    val percentUsed: Int,
    val isLowMemory: Boolean
)

object SystemMonitor {

    fun getRamInfo(context: Context): RamInfo {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)

        val totalMb = info.totalMem / (1024 * 1024)
        val availMb = info.availMem / (1024 * 1024)
        val usedMb = totalMb - availMb
        val percent = if (totalMb > 0) ((usedMb.toDouble() / totalMb) * 100).roundToInt() else 0

        return RamInfo(
            usedMb = usedMb,
            totalMb = totalMb,
            percentUsed = percent,
            isLowMemory = info.lowMemory
        )
    }

    /**
     * Real CPU usage sampled by reading /proc/stat twice with a short delay
     * and computing the delta. Returns null if the file isn't readable
     * (some OEMs block it) — caller must handle that honestly.
     */
    fun cpuUsagePercent(sampleDelayMs: Long = 360): Int? {
        val first = readCpuTicks() ?: return null
        Thread.sleep(sampleDelayMs)
        val second = readCpuTicks() ?: return null

        val idleDelta = second.idle - first.idle
        val totalDelta = second.total - first.total
        if (totalDelta <= 0) return null

        val usage = 100.0 * (totalDelta - idleDelta) / totalDelta
        return usage.roundToInt().coerceIn(0, 100)
    }

    private data class CpuTicks(val idle: Long, val total: Long)

    private fun readCpuTicks(): CpuTicks? {
        return try {
            RandomAccessFile("/proc/stat", "r").use { reader ->
                val load = reader.readLine() // "cpu  user nice system idle iowait irq softirq ..."
                val toks = load.split(Regex("\\s+")).drop(1).filter { it.isNotBlank() }
                val nums = toks.map { it.toLong() }
                val idle = nums.getOrElse(3) { 0L }
                val total = nums.sum()
                CpuTicks(idle, total)
            }
        } catch (e: Exception) {
            null // not readable on this OEM build — be honest, don't fabricate
        }
    }

    /** Simple, real latency check against a public host. Not a gimmick number. */
    suspend fun pingMs(host: String = "8.8.8.8"): Long? {
        return try {
            val start = System.currentTimeMillis()
            val reachable = java.net.InetAddress.getByName(host).isReachable(1500)
            if (!reachable) return null
            System.currentTimeMillis() - start
        } catch (e: Exception) {
            null
        }
    }
}
