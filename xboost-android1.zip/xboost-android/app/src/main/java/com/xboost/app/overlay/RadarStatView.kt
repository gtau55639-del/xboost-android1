package com.xboost.app.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * 5-axis "headroom" radar, the same idea as RedMagic/ROG's performance-profile
 * pentagon, but every axis is a real, honestly-derived score instead of a
 * marketing number:
 *
 *  - Thermal   : 100 at a cool battery temp, scaled down toward hot
 *  - Memory    : 100 = lots of free RAM
 *  - CPU       : 100 = CPU mostly idle right now
 *  - Storage   : 100 = lots of free internal storage
 *  - Network   : 100 = low ping to a public host, 0 if unreachable
 *
 * If a given source is unavailable (e.g. /proc/stat blocked, no network),
 * the caller passes a neutral midpoint (50) for that axis instead of a real
 * reading — a flat 0 would visually read as "worst possible", which is just
 * as misleading as fabricating a number. Same honesty rule as the ring
 * gauges elsewhere in XBoost, adapted for a chart shape that has no natural
 * "—" state. See FloatingPanelService.computeRadarScores() for exactly
 * which axes can hit that neutral fallback and why.
 */
class RadarStatView(context: Context) : View(context) {

    data class Scores(
        val thermal: Int,
        val memory: Int,
        val cpu: Int,
        val storage: Int,
        val network: Int
    )

    private var scores = Scores(0, 0, 0, 0, 0)
    private val density = context.resources.displayMetrics.density
    private val labels = listOf("THERMAL", "MEMORY", "CPU", "STORAGE", "NETWORK")

    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1f * density
        color = Color.parseColor("#2C2732")
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#66FF6A2E")
    }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.6f * density
        color = Color.parseColor("#FF6A2E")
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.parseColor("#FF6A2E")
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#9C97A3")
        textAlign = Paint.Align.CENTER
        textSize = 8f * context.resources.displayMetrics.density
    }

    fun setScores(scores: Scores) {
        this.scores = scores
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = View.MeasureSpec.getSize(widthMeasureSpec)
        val target = if (w > 0) w else (260 * density).toInt()
        setMeasuredDimension(target, (target * 0.62f).toInt())
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f + 4f * density
        val radius = min(width * 0.30f, height * 0.62f)

        // Grid rings (25/50/75/100%)
        for (step in 1..4) {
            canvas.drawPath(polygon(cx, cy, radius * (step / 4f)), gridPaint)
        }
        // Spokes
        for (i in labels.indices) {
            val (x, y) = point(cx, cy, radius, i, 1f)
            canvas.drawLine(cx, cy, x, y, gridPaint)
        }

        // Data polygon
        val values = listOf(scores.thermal, scores.memory, scores.cpu, scores.storage, scores.network)
        val dataPath = Path()
        values.forEachIndexed { i, v ->
            val (x, y) = point(cx, cy, radius, i, (v.coerceIn(0, 100) / 100f))
            if (i == 0) dataPath.moveTo(x, y) else dataPath.lineTo(x, y)
        }
        dataPath.close()
        canvas.drawPath(dataPath, fillPaint)
        canvas.drawPath(dataPath, strokePaint)
        values.forEachIndexed { i, v ->
            val (x, y) = point(cx, cy, radius, i, (v.coerceIn(0, 100) / 100f))
            canvas.drawCircle(x, y, 2.4f * density, dotPaint)
        }

        // Axis labels
        labels.forEachIndexed { i, label ->
            val (x, y) = point(cx, cy, radius * 1.24f, i, 1f)
            canvas.drawText(label, x, y, labelPaint)
        }
    }

    private fun polygon(cx: Float, cy: Float, radius: Float): Path {
        val path = Path()
        for (i in labels.indices) {
            val (x, y) = point(cx, cy, radius, i, 1f)
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        return path
    }

    private fun point(cx: Float, cy: Float, radius: Float, index: Int, scale: Float): Pair<Float, Float> {
        val angle = (-Math.PI / 2) + (2 * Math.PI / labels.size) * index
        val x = cx + (radius * scale * cos(angle)).toFloat()
        val y = cy + (radius * scale * sin(angle)).toFloat()
        return x to y
    }
}
