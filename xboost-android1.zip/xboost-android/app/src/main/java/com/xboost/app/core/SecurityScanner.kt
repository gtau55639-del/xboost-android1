package com.xboost.app.core

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings

/**
 * Honest scope, stated up front: a non-root, non-system app on Android
 * cannot read another app's files, cannot compute file-hash virus
 * signatures against a cloud database the way a real desktop AV engine
 * does, and cannot see what code actually *runs* at runtime. Nothing here
 * pretends otherwise.
 *
 * What XBoost *can* legitimately check, with the public PackageManager API,
 * is exactly what a careful user would check by hand: where an app was
 * installed from, and which sensitive permission/component combinations it
 * declared. Those are real, well-documented signals real security tools
 * use too (unknown install source + accessibility-service binding +
 * SMS access is the textbook banking-trojan shape). This is a permission
 * & install-source risk scan, not a signature-based antivirus — and the UI
 * says so, rather than claiming a "virus database".
 */
enum class RiskLevel { SAFE, LOW, MEDIUM, HIGH }

data class AppRisk(
    val packageName: String,
    val label: String,
    val riskLevel: RiskLevel,
    val reasons: List<String>,
    val isSideloaded: Boolean,
    val installerLabel: String
)

data class ScanSummary(
    val scannedCount: Int,
    val high: List<AppRisk>,
    val medium: List<AppRisk>,
    val low: List<AppRisk>,
    val playProtectOn: Boolean?
)

object SecurityScanner {

    // Known trusted installer package names. Anything else (or null, which
    // means "installed via adb / a file manager / a browser download") is
    // treated as sideloaded — a real, checkable fact, not a guess.
    private val TRUSTED_INSTALLERS = setOf(
        "com.android.vending",       // Google Play
        "com.amazon.venezia",        // Amazon Appstore
        "com.sec.android.app.samsungapps", // Galaxy Store
        "com.huawei.appmarket",
        "com.xiaomi.market",
        "com.oppo.market",
        "com.heytap.market",
        "com.miui.packageinstaller"  // MIUI's own OTA/system installer path
    )

    private val SMS_PERMISSIONS = setOf(
        "android.permission.READ_SMS",
        "android.permission.RECEIVE_SMS",
        "android.permission.SEND_SMS"
    )

    private val DANGEROUS_PERMISSIONS = setOf(
        "android.permission.READ_SMS", "android.permission.RECEIVE_SMS", "android.permission.SEND_SMS",
        "android.permission.READ_CONTACTS", "android.permission.READ_CALL_LOG", "android.permission.CALL_PHONE",
        "android.permission.READ_PHONE_STATE", "android.permission.PROCESS_OUTGOING_CALLS",
        "android.permission.RECORD_AUDIO", "android.permission.CAMERA",
        "android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_BACKGROUND_LOCATION",
        "android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE",
        "android.permission.SYSTEM_ALERT_WINDOW", "android.permission.REQUEST_INSTALL_PACKAGES",
        "android.permission.BIND_DEVICE_ADMIN", "android.permission.RECEIVE_BOOT_COMPLETED"
    )

    /**
     * Scans installed, non-system apps (your own app is always excluded).
     * Runs synchronously — callers should invoke this off the main thread,
     * same rule as SystemMonitor.cpuUsagePercent(), since PackageManager
     * lookups across every installed app aren't free on a large device.
     */
    fun scanInstalledApps(context: Context): ScanSummary {
        val pm = context.packageManager
        val apps = runCatching {
            pm.getInstalledApplications(PackageManager.GET_META_DATA)
        }.getOrDefault(emptyList())

        val results = apps
            .filter { it.packageName != context.packageName && (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
            .mapNotNull { app -> runCatching { evaluate(context, app) }.getOrNull() }
            .filter { it.riskLevel != RiskLevel.SAFE }
            .sortedWith(compareByDescending<AppRisk> { it.riskLevel.ordinal }.thenBy { it.label.lowercase() })

        return ScanSummary(
            scannedCount = apps.count { it.packageName != context.packageName && (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 },
            high = results.filter { it.riskLevel == RiskLevel.HIGH },
            medium = results.filter { it.riskLevel == RiskLevel.MEDIUM },
            low = results.filter { it.riskLevel == RiskLevel.LOW },
            playProtectOn = playProtectStatus(context)
        )
    }

    private fun evaluate(context: Context, app: ApplicationInfo): AppRisk {
        val pm = context.packageManager
        val pkg = app.packageName
        val label = runCatching { pm.getApplicationLabel(app).toString() }.getOrDefault(pkg)

        val installerLabel: String
        val sideloaded: Boolean
        val installer = getInstaller(context, pkg)
        if (installer == null) {
            installerLabel = "Unknown (sideloaded)"
            sideloaded = true
        } else if (installer in TRUSTED_INSTALLERS) {
            installerLabel = storeLabel(installer)
            sideloaded = false
        } else {
            installerLabel = "Unrecognized installer: $installer"
            sideloaded = true
        }

        val permissions = runCatching {
            pm.getPackageInfo(pkg, PackageManager.GET_PERMISSIONS).requestedPermissions?.toList()
        }.getOrNull() ?: emptyList()

        val hasAccessibilityService = runCatching { declaresBoundComponent(pm, pkg, "android.permission.BIND_ACCESSIBILITY_SERVICE") }.getOrDefault(false)
        val hasDeviceAdmin = permissions.contains("android.permission.BIND_DEVICE_ADMIN") ||
            runCatching { declaresBoundComponent(pm, pkg, "android.permission.BIND_DEVICE_ADMIN") }.getOrDefault(false)
        val hasOverlay = permissions.contains("android.permission.SYSTEM_ALERT_WINDOW")
        val hasInstallOthers = permissions.contains("android.permission.REQUEST_INSTALL_PACKAGES")
        val smsCount = permissions.count { it in SMS_PERMISSIONS }
        val dangerousCount = permissions.count { it in DANGEROUS_PERMISSIONS }

        var score = 0
        val reasons = mutableListOf<String>()

        if (sideloaded) {
            score += 2
            reasons += "Installed from an unrecognized source, not a known app store"
        }
        if (hasAccessibilityService) {
            score += if (sideloaded) 4 else 2
            reasons += "Can bind an Accessibility Service (can read screen content & simulate taps)"
        }
        if (hasDeviceAdmin) {
            score += 2
            reasons += "Requests Device Admin access (harder for you to uninstall)"
        }
        if (smsCount > 0) {
            score += if (sideloaded) 3 else 1
            reasons += "Reads or sends SMS messages"
        }
        if (hasOverlay && hasInstallOthers) {
            score += 2
            reasons += "Can draw over other apps AND install additional apps"
        } else if (hasOverlay && sideloaded) {
            score += 1
            reasons += "Can draw over other apps (overlay/phishing risk)"
        }
        if (dangerousCount >= 8) {
            score += 1
            reasons += "Requests an unusually large number of sensitive permissions ($dangerousCount)"
        }

        val level = when {
            score >= 6 -> RiskLevel.HIGH
            score >= 3 -> RiskLevel.MEDIUM
            score >= 1 -> RiskLevel.LOW
            else -> RiskLevel.SAFE
        }

        return AppRisk(pkg, label, level, reasons, sideloaded, installerLabel)
    }

    /** True if this package declares a service/receiver that binds the given signature permission. */
    private fun declaresBoundComponent(pm: PackageManager, pkg: String, permission: String): Boolean {
        val info = pm.getPackageInfo(
            pkg,
            PackageManager.GET_SERVICES or PackageManager.GET_RECEIVERS
        )
        val services = info.services?.any { it.permission == permission } ?: false
        val receivers = info.receivers?.any { it.permission == permission } ?: false
        return services || receivers
    }

    private fun getInstaller(context: Context, pkg: String): String? {
        val pm = context.packageManager
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                pm.getInstallSourceInfo(pkg).installingPackageName
            } else {
                @Suppress("DEPRECATION")
                pm.getInstallerPackageName(pkg)
            }
        }.getOrNull()
    }

    private fun storeLabel(installer: String) = when (installer) {
        "com.android.vending" -> "Google Play"
        "com.amazon.venezia" -> "Amazon Appstore"
        "com.sec.android.app.samsungapps" -> "Galaxy Store"
        "com.huawei.appmarket" -> "Huawei AppGallery"
        "com.xiaomi.market" -> "Xiaomi GetApps"
        "com.oppo.market", "com.heytap.market" -> "OPPO/Heytap Store"
        "com.miui.packageinstaller" -> "System installer"
        else -> installer
    }

    /**
     * Best-effort, read-only check of the system's global "verify apps over
     * USB/sideload" setting. Returns null (never a fake true/false) when the
     * OEM build doesn't expose it — the UI must show "Unknown" honestly.
     */
    private fun playProtectStatus(context: Context): Boolean? = runCatching {
        Settings.Global.getInt(context.contentResolver, "package_verifier_enable") == 1
    }.getOrNull()
}
