package com.xboost.app.ui.screens

import android.content.Context
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.xboost.app.core.DisplayRefreshManager
import com.xboost.app.core.SystemMonitor
import com.xboost.app.core.ThermalGuardManager
import com.xboost.app.core.ThermalLevel
import com.xboost.app.ui.theme.*
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * A single axis of the "System Vitals" radar — score is always derived from
 * a real reading (never a placeholder). `raw` is the human-readable value
 * shown under the label, `score` (0-100) is what actually places the point
 * on the chart.
 */
private data class VitalAxis(val label: String, val score: Int, val raw: String, val color: Color)

@Composable
fun MetricsScreen() {
    val context = LocalContext.current
    val ramHistory = remember { mutableStateListOf<Int>() }
    val cpuHistory = remember { mutableStateListOf<Int>() }

    var ramPct by remember { mutableStateOf(0) }
    var cpuPct by remember { mutableStateOf<Int?>(null) }
    var pingMs by remember { mutableStateOf<Long?>(null) }
    var battPct by remember { mutableStateOf(batteryPercent(context)) }
    var thermal by remember { mutableStateOf(ThermalLevel.COOL) }
    val refreshInfo = remember { DisplayRefreshManager.currentInfo(context) }

    LaunchedEffect(Unit) {
        while (true) {
            val ram = SystemMonitor.getRamInfo(context)
            val cpu = SystemMonitor.cpuUsagePercent()
            ramPct = ram.percentUsed
            cpuPct = cpu
            ramHistory.add(ram.percentUsed)
            cpuHistory.add(cpu ?: 0)
            if (ramHistory.size > 40) ramHistory.removeAt(0)
            if (cpuHistory.size > 40) cpuHistory.removeAt(0)

            battPct = batteryPercent(context)
            val temp = ThermalGuardManager.currentBatteryTempCelsius(context)
            thermal = ThermalGuardManager.levelFor(temp)
            pingMs = SystemMonitor.pingMs()

            delay(1000)
        }
    }

    // Every axis maps straight to a real reading above — nothing here is invented.
    val vitals = remember(ramPct, cpuPct, pingMs, battPct, thermal, refreshInfo) {
        val systemScore = (100 - (((cpuPct ?: ramPct) + ramPct) / 2)).coerceIn(0, 100)
        val thermalScore = when (thermal) {
            ThermalLevel.COOL -> 100
            ThermalLevel.WARM -> 60
            ThermalLevel.HOT -> 25
        }
        val networkScore = when {
            pingMs == null -> 0
            pingMs!! <= 40 -> 100
            pingMs!! >= 300 -> 10
            else -> (100 - ((pingMs!! - 40) * 90 / 260)).toInt().coerceIn(10, 100)
        }
        val refreshScore = if (refreshInfo.maxRate > 0)
            ((refreshInfo.currentRate / refreshInfo.maxRate) * 100).toInt().coerceIn(0, 100) else 0

        listOf(
            VitalAxis("System", systemScore, if (cpuPct != null) "CPU ${cpuPct}% · RAM $ramPct%" else "RAM $ramPct%", XCyan),
            VitalAxis("Battery", battPct, "$battPct%", XGreen),
            VitalAxis("Refresh", refreshScore, "${refreshInfo.currentRate.toInt()}Hz / ${refreshInfo.maxRate.toInt()}Hz", XBlue),
            VitalAxis("Network", networkScore, if (pingMs != null) "${pingMs}ms" else "Unavailable", XPurple),
            VitalAxis("Cooling", thermalScore, thermal.name.lowercase().replaceFirstChar { it.uppercase() }, XRed),
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(GradientBgTop, BgDeep, GradientBgBottom)))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 24.dp)
        ) {
            Text("METRICS", color = Text0, fontWeight = FontWeight.Bold, fontSize = 19.sp)
            Text("Rolling 40-second live history, sampled every second", color = Text2, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp, bottom = 18.dp))

            SystemVitalsCard(vitals)
            Spacer(Modifier.height(12.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                Box(modifier = Modifier.weight(1f)) { MetricGraphCard("RAM usage", ramHistory, XRed) }
                Box(modifier = Modifier.weight(1f)) { MetricGraphCard("CPU usage", cpuHistory, XCyan) }
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                Box(modifier = Modifier.weight(1f)) { StorageCard() }
                Box(modifier = Modifier.weight(1f)) { DeviceInfoCard(context) }
            }
        }
    }
}

/**
 * "System Vitals" — a 5-axis radar summary in the spirit of ROG's Game Genie
 * performance dial, but every point on the pentagon is a real derived score
 * (system load, battery, actual display refresh rate, live ping, thermal
 * level) rather than decoration. Below the chart, each axis also shows its
 * real underlying reading so the shape is never the only source of truth.
 */
@Composable
private fun SystemVitalsCard(vitals: List<VitalAxis>) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(PanelGlassHi, PanelGlass)), RoundedCornerShape(16.dp))
            .border(1.dp, LineSoft, RoundedCornerShape(16.dp))
            .padding(16.dp)
    ) {
        Text("SYSTEM VITALS", color = Text1, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.sp)
        Spacer(Modifier.height(8.dp))

        Box(modifier = Modifier.fillMaxWidth().height(200.dp), contentAlignment = Alignment.Center) {
            RadarChart(vitals, modifier = Modifier.size(200.dp))
        }

        Spacer(Modifier.height(4.dp))
        Column(verticalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            vitals.chunked(2).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    row.forEach { v -> Box(modifier = Modifier.weight(1f)) { VitalRow(v) } }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun VitalRow(v: VitalAxis) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .size(7.dp)
                .background(v.color, androidx.compose.foundation.shape.CircleShape)
        )
        Spacer(Modifier.width(6.dp))
        Column {
            Text(v.label, color = Text1, fontSize = 10.sp)
            Text(v.raw, color = Text0, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun RadarChart(vitals: List<VitalAxis>, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val n = vitals.size
        if (n < 3) return@Canvas
        val center = Offset(size.width / 2f, size.height / 2f)
        val maxRadius = min(size.width, size.height) / 2f * 0.78f

        fun pointAt(index: Int, fraction: Float): Offset {
            val angle = Math.toRadians((-90 + (360.0 / n) * index))
            val r = maxRadius * fraction
            return Offset(
                center.x + (r * cos(angle)).toFloat(),
                center.y + (r * sin(angle)).toFloat()
            )
        }

        // Background grid rings (25/50/75/100%)
        listOf(0.25f, 0.5f, 0.75f, 1f).forEach { frac ->
            val ring = Path()
            for (i in 0 until n) {
                val p = pointAt(i, frac)
                if (i == 0) ring.moveTo(p.x, p.y) else ring.lineTo(p.x, p.y)
            }
            ring.close()
            drawPath(ring, color = LineSoft, style = Stroke(width = 1.dp.toPx()))
        }
        // Spokes
        for (i in 0 until n) {
            drawLine(LineSoft, center, pointAt(i, 1f), strokeWidth = 1.dp.toPx())
        }

        // Data polygon
        val dataPath = Path()
        for (i in 0 until n) {
            val p = pointAt(i, vitals[i].score / 100f)
            if (i == 0) dataPath.moveTo(p.x, p.y) else dataPath.lineTo(p.x, p.y)
        }
        dataPath.close()
        drawPath(dataPath, color = XCyan.copy(alpha = 0.20f))
        drawPath(dataPath, color = XCyan, style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round))
        for (i in 0 until n) {
            drawCircle(vitals[i].color, radius = 3.dp.toPx(), center = pointAt(i, vitals[i].score / 100f))
        }
    }
}

@Composable
private fun StorageCard() {
    val stat = remember { StatFs(Environment.getDataDirectory().path) }
    val totalGb = (stat.totalBytes / (1024.0 * 1024 * 1024))
    val freeGb = (stat.availableBytes / (1024.0 * 1024 * 1024))
    val usedPercent = (((totalGb - freeGb) / totalGb) * 100).toInt().coerceIn(0, 100)

    Column(
        modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).border(1.dp, Line, RoundedCornerShape(14.dp)).padding(16.dp)
    ) {
        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text("Storage", color = Text0, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text("$usedPercent% used", color = XAmber, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "%.1f GB free of %.1f GB".format(freeGb, totalGb),
            color = Text2, fontSize = 11.sp
        )
    }
}

@Composable
private fun MetricGraphCard(title: String, history: List<Int>, color: androidx.compose.ui.graphics.Color) {
    Column(
        modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).border(1.dp, Line, RoundedCornerShape(14.dp)).padding(16.dp)
    ) {
        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text(title, color = Text0, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text("${history.lastOrNull() ?: 0}%", color = color, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        Spacer(Modifier.height(10.dp))
        Canvas(modifier = Modifier.fillMaxWidth().height(70.dp)) {
            if (history.size < 2) return@Canvas
            val stepX = size.width / (40 - 1).toFloat()
            val path = Path()
            history.forEachIndexed { i, v ->
                val x = i * stepX
                val y = size.height - (v / 100f) * size.height
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, color = color, style = Stroke(width = 2.dp.toPx()))
        }
    }
}

@Composable
private fun DeviceInfoCard(context: Context) {
    val batteryPct = remember { batteryPercent(context) }
    val uptime = remember { uptimeString() }

    Column(
        modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).border(1.dp, Line, RoundedCornerShape(14.dp)).padding(16.dp)
    ) {
        Text("DEVICE", color = Text1, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        InfoRow("Battery", "$batteryPct%")
        InfoRow("Device uptime", uptime)
        InfoRow("Android version", android.os.Build.VERSION.RELEASE)
        InfoRow("Model", "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}")
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Text2, fontSize = 12.sp)
        Text(value, color = Text0, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

private fun batteryPercent(context: Context): Int {
    val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
}

private fun uptimeString(): String {
    val ms = SystemClock.elapsedRealtime()
    val hours = ms / (1000 * 60 * 60)
    val minutes = (ms / (1000 * 60)) % 60
    return "${hours}h ${minutes}m"
}
