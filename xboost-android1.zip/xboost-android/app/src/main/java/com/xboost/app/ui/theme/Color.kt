package com.xboost.app.ui.theme

import androidx.compose.ui.graphics.Color

val Bg0 = Color(0xFF07070B)
val Bg1 = Color(0xFF0D0E15)
val Panel = Color(0xFF15161F)
val Line = Color(0xFF23242F)

val XRed = Color(0xFFFF2B45)
val XRedDim = Color(0x33FF2B45)
val XCyan = Color(0xFF26F0D0)
val XCyanDim = Color(0x3326F0D0)
val XAmber = Color(0xFFFFB020)

val Text0 = Color(0xFFF2F3F7)
val Text1 = Color(0xFF9497A8)
val Text2 = Color(0xFF5C5F70)

// --- Revisi ke-12: token tambahan buat UI yang lebih "premium game booster" ---
// Semua ini murni tambahan (additive) — token lama di atas TIDAK diganti/dihapus
// supaya layar lain yang masih pakai Bg0/Panel/Line/Text0-2 tetap jalan normal.

// Latar belakang berlapis untuk efek "glass panel" + glow radial ala
// GFX Tool / Game Space, tanpa perlu shader/RenderEffect (aman di API rendah).
val BgDeep = Color(0xFF030305)
val PanelGlass = Color(0xCC12131C)          // panel semi-transparan (dipakai di atas gradient bg)
val PanelGlassHi = Color(0xE6191A26)        // varian sedikit lebih terang, untuk kartu yang di-highlight
val PanelElevated = Color(0xFF1B1C28)
val LineSoft = Color(0x1FFFFFFF)
val LineGlow = Color(0x66FF2B45)

// Status/aksen tambahan
val XGreen = Color(0xFF33E27A)
val XGreenDim = Color(0x3333E27A)
val XPurple = Color(0xFFB463FF)
val XPurpleDim = Color(0x33B463FF)
val XBlue = Color(0xFF3E9CFF)

// Gradient stops siap pakai untuk background & tombol boost utama
val GradientBgTop = Color(0xFF120A10)
val GradientBgBottom = Color(0xFF05050A)
val GradientCoreStart = Color(0xFF1C1220)
val GradientCoreEnd = Color(0xFF07070C)
