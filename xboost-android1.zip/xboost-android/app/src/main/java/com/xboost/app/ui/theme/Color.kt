package com.xboost.app.ui.theme

import androidx.compose.ui.graphics.Color

// =====================================================================
// XBoost — "Circuit Ember" design system
// Total UI redesign: moved off the stock red/black/cyan "gamer neon"
// look (the default nearly every AI-generated booster-app mock lands
// on) toward a warm graphite-chassis palette with a single confident
// ember accent + a cool signal-blue for data/telemetry. Reads like a
// piece of tuned hardware under low light, not a stock HUD skin.
// Token NAMES are kept 1:1 with the old palette so every screen that
// already references Bg0/Panel/XRed/Text0/etc. repaints automatically
// — no screen files needed to change for this pass.
// =====================================================================

// --- Base surfaces: warm-neutral graphite instead of blue-black ---
val Bg0 = Color(0xFF0B0A0E)      // root ink
val Bg1 = Color(0xFF121016)      // nav rail / secondary ink
val Panel = Color(0xFF18151C)    // card surface
val Line = Color(0xFF2C2732)     // hairline border

// --- Signature accents ---
// Ember replaces the old neon red as the app's default "energy" color.
val XRed = Color(0xFFFF6A2E)
val XRedDim = Color(0x33FF6A2E)
// Signal replaces the old teal-cyan — a cooler, less saturated blue used
// for telemetry/data readouts, the counterpoint to Ember.
val XCyan = Color(0xFF3FC8FF)
val XCyanDim = Color(0x333FC8FF)
// Warm amber kept for thermal/warning states, tuned to sit next to Ember
// without visually competing with it.
val XAmber = Color(0xFFFFC24D)

// --- Text ---
val Text0 = Color(0xFFF5F1EA)    // warm-white, pairs with the ember base
val Text1 = Color(0xFF9C97A3)
val Text2 = Color(0xFF5C5865)

// --- Revisi ke-13: "Circuit Ember" identity layer ---
// Additive glass/glow tokens used for the premium panel + radial-glow
// treatment. Old token names kept so nothing downstream breaks; values
// re-tuned to the new warm-graphite + ember/signal palette.

val BgDeep = Color(0xFF040305)
val PanelGlass = Color(0xCC17141B)          // semi-transparent panel over gradient bg
val PanelGlassHi = Color(0xE61E1A23)        // highlighted-card variant
val PanelElevated = Color(0xFF201C25)
val LineSoft = Color(0x1FFFFFFF)
val LineGlow = Color(0x66FF6A2E)            // ember glow line

// Status/aksen tambahan — refined jewel tones, distinct hue family from
// Ember/Signal so the 4-way accent picker in Settings stays legible.
val XGreen = Color(0xFFB9FF4D)              // "Volt" — lime-charge green
val XGreenDim = Color(0x33B9FF4D)
val XPurple = Color(0xFFA463F2)             // "Violet"
val XPurpleDim = Color(0x33A463F2)
val XBlue = Color(0xFF4D8CFF)

// Gradient stops for background + primary boost control, warm-ember cast
// instead of the old crimson-black combo.
val GradientBgTop = Color(0xFF1B1109)
val GradientBgBottom = Color(0xFF07070A)
val GradientCoreStart = Color(0xFF241408)
val GradientCoreEnd = Color(0xFF08070A)
