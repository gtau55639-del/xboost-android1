package com.xboost.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.xboost.app.core.AccentColor
import com.xboost.app.core.PreferencesManager
import com.xboost.app.ui.nav.XBoostApp
import com.xboost.app.ui.theme.XBoostTheme

class MainActivity : ComponentActivity() {

    // Android 13+ only — on 9-12 this permission doesn't exist and the
    // launcher is simply never triggered, so this is a no-op there.
    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* result ignored: services run either way, see manifest comment */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        // Must be called before super.onCreate() / setContentView per the
        // core-splashscreen contract. Manifest sets Theme.XBoost.Splash as
        // this activity's theme so the branded splash shows immediately on
        // cold start; postSplashScreenTheme swaps it back to Theme.XBoost
        // automatically once the first frame is drawn.
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        // If launched from the Floating Quick Panel's "Guide" button, jump straight
        // to the requested screen (e.g. a specific game's AI Assistant & Guide tab)
        // instead of always landing back on Boost.
        val pendingRoute = intent?.getStringExtra(EXTRA_NAV_ROUTE)
        setContent {
            val accent by PreferencesManager.accentColor(this).collectAsState(initial = AccentColor.RED)
            XBoostTheme(accent = accent) {
                XBoostApp(pendingRoute = pendingRoute)
            }
        }
    }

    companion object {
        const val EXTRA_NAV_ROUTE = "xboost_nav_route"
    }
}
