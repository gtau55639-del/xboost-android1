package com.xboost.app.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.xboost.app.ui.theme.*
import kotlinx.coroutines.launch

private data class OnboardPage(
    val icon: ImageVector,
    val title: String,
    val body: String,
    val accent: Color
)

// Kept honest and specific to what XBoost actually does — same tone as the
// rest of the app (no "unlock 120Hz"/"double your FPS" style overclaiming).
private val PAGES = listOf(
    OnboardPage(
        icon = Icons.Filled.Bolt,
        title = "Selamat datang di XBoost",
        body = "Panduan singkat ini cuma tampil sekali, sekarang. Setelah ini selesai, XBoost langsung " +
            "kebuka normal — panduan ini gak akan muncul lagi.",
        accent = XRed
    ),
    OnboardPage(
        icon = Icons.Filled.RocketLaunch,
        title = "Tab Boost",
        body = "Pilih mode Performance / Balance / Battery Save, lalu tekan tombol heksagon untuk boost. " +
            "Di bawahnya ada Quick Functions (Clear Cache, Game DND, Screen Awake, dll) — semuanya aksi " +
            "nyata, bisa dinyalakan satu-satu sesuai kebutuhan.",
        accent = XCyan
    ),
    OnboardPage(
        icon = Icons.Filled.AutoAwesome,
        title = "Auto Game Mode & Panel Melayang",
        body = "Aktifkan Auto Game Mode di Boost supaya XBoost otomatis kenal saat kamu buka game. " +
            "Nyalakan juga 'Floating Quick Panel' di Modules — bubble kecil yang menampilkan suhu, RAM, " +
            "dan CPU langsung di atas game, tanpa perlu keluar dulu.",
        accent = XPurple
    ),
    OnboardPage(
        icon = Icons.Filled.SportsEsports,
        title = "Game Library & AI Assistant",
        body = "Tab Games menyimpan daftar game kamu dan tips per-game (offline, gak perlu internet). " +
            "Bisa tambah game manual lewat tombol '+ Add Game' kalau game kamu belum otomatis terdeteksi.",
        accent = XGreen
    ),
    OnboardPage(
        icon = Icons.Filled.Insights,
        title = "Network & Metrics",
        body = "Tab Network buat cek ping asli ke internet. Tab Metrics nampilin System Vitals dan grafik " +
            "RAM/CPU real-time, jadi kamu tahu persis kondisi HP saat main, bukan angka kira-kira.",
        accent = XBlue
    ),
    OnboardPage(
        icon = Icons.Filled.Shield,
        title = "Izin yang bakal diminta",
        body = "Beberapa fitur butuh izin khusus (Usage Access, Notification Access, Modify System Settings, " +
            "Tampil di atas aplikasi lain) — semua diminta jelas di Boost/Modules saat kamu nyalakan fitur " +
            "terkait, bukan diam-diam. Boleh ditolak, fitur itu saja yang nonaktif, sisanya tetap jalan.",
        accent = XAmber
    ),
)

/**
 * Full-screen, one-shot tutorial shown on first launch only. `onFinish` is
 * called once — from XBoostApp, which persists PreferencesManager's
 * onboarding-seen flag right after, so this composable itself never needs
 * to know about DataStore.
 */
@Composable
fun OnboardingScreen(onFinish: () -> Unit) {
    val pagerState = rememberPagerState(pageCount = { PAGES.size })
    val scope = rememberCoroutineScope()
    val lastPage = PAGES.size - 1

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(GradientBgTop, BgDeep, GradientBgBottom)))
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 20.dp, end = 20.dp),
                horizontalArrangement = Arrangement.End
            ) {
                if (pagerState.currentPage != lastPage) {
                    Text(
                        "Lewati",
                        color = Text2,
                        fontSize = 13.sp,
                        modifier = Modifier.clickable { onFinish() }.padding(8.dp)
                    )
                }
            }

            HorizontalPager(
                state = pagerState,
                modifier = Modifier.weight(1f)
            ) { page ->
                OnboardPageContent(PAGES[page])
            }

            // Dots indicator
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 18.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                PAGES.indices.forEach { i ->
                    val selected = pagerState.currentPage == i
                    val width by animateFloatAsState(if (selected) 22f else 7f, label = "dotWidth")
                    Box(
                        modifier = Modifier
                            .padding(horizontal = 3.dp)
                            .height(7.dp)
                            .width(width.dp)
                            .clip(RoundedCornerShape(50))
                            .background(if (selected) PAGES[pagerState.currentPage].accent else LineSoft)
                    )
                }
            }

            Button(
                onClick = {
                    if (pagerState.currentPage == lastPage) {
                        onFinish()
                    } else {
                        scope.launch { pagerState.animateScrollToPage(pagerState.currentPage + 1) }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = PAGES[pagerState.currentPage].accent, contentColor = Color.Black),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .padding(bottom = 28.dp)
                    .height(52.dp)
            ) {
                Text(
                    if (pagerState.currentPage == lastPage) "Mulai Pakai XBoost" else "Lanjut",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }
        }
    }
}

@Composable
private fun OnboardPageContent(page: OnboardPage) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(96.dp)
                .clip(CircleShape)
                .background(Brush.radialGradient(listOf(page.accent.copy(alpha = 0.28f), Color.Transparent))),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(Brush.verticalGradient(listOf(PanelGlassHi, PanelGlass))),
                contentAlignment = Alignment.Center
            ) {
                Icon(page.icon, contentDescription = null, tint = page.accent, modifier = Modifier.size(34.dp))
            }
        }
        Spacer(Modifier.height(28.dp))
        Text(
            page.title,
            color = Text0,
            fontWeight = FontWeight.Bold,
            fontSize = 21.sp,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(12.dp))
        Text(
            page.body,
            color = Text1,
            fontSize = 14.sp,
            lineHeight = 21.sp,
            textAlign = TextAlign.Center
        )
    }
}
