package com.xboost.app.core

/**
 * Content for the two per-game modules (Modules screen → "Game AI Assistant & Guide"):
 *
 *  - AI Tips Assistant: the user types (or speaks) a question, XBoost scores it against a
 *    curated keyword→answer table for that game and returns the best match. This is an
 *    OFFLINE, on-device lookup — not a cloud model, and it never reads, controls, or
 *    injects input into the game itself. Framed honestly, same as every other module in
 *    this app: it's a smarter searchable tips book, not a bot that plays for you.
 *  - Guide: a structured, always-visible list of general strategy/settings tips per game.
 *
 * All content here is original, general gameplay/settings advice (sensitivity, loadouts,
 * rotations, team comps) — nothing that reads memory, automates input, aims for the player,
 * or gives an unfair advantage over other players. That kind of tool (an actual game hack /
 * cheat engine) is permanently out of scope for XBoost by design, regardless of how the
 * request for it is phrased.
 */
data class AssistantEntry(
    val keywords: List<String>,
    val answer: String,
    /** Short, natural-language version of the question this entry answers — shown as a tappable suggestion chip. */
    val sampleQuestion: String = keywords.first()
)
data class GuideSection(val heading: String, val points: List<String>)

object GameContentRepository {

    private val genericAssistant = listOf(
        AssistantEntry(
            keywords = listOf("lag", "fps", "stutter", "patah", "nge-lag", "lemot", "nge-drop", "turun"),
            answer = "Coba mode Performance di tab Boost dulu (trim background + polling lebih ringan), " +
                "lalu cek FPS Boost Overlay di Modules buat lihat angka FPS asli saat main.",
            sampleQuestion = "Kenapa game aku lag/fps drop?"
        ),
        AssistantEntry(
            keywords = listOf("panas", "hot", "suhu", "thermal", "overheat", "gerah"),
            answer = "Aktifkan Thermal Guard di Modules buat pantau suhu baterai real-time. XBoost sudah tidak lagi " +
                "menaikkan kecerahan layar otomatis di mode Performance — itu justru bikin HP tambah panas, jadi fitur itu dihapus.",
            sampleQuestion = "HP kok cepat panas pas main?"
        ),
        AssistantEntry(
            keywords = listOf("baterai", "battery", "boros", "hemat", "ngedrop"),
            answer = "Pindah ke mode Battery Save di tab Boost — timeout layar dipercepat, " +
                "dan trim background di-skip biar gak nambah beban CPU. Turunkan kecerahan manual dari HP kalau mau lebih hemat lagi.",
            sampleQuestion = "Cara hemat baterai pas main game?"
        ),
        AssistantEntry(
            keywords = listOf("dc", "putus", "connection", "koneksi", "ping", "disconnect"),
            answer = "Cek tab Network buat ping real ke internet. Kalau ping tinggi terus, itu biasanya jaringan/router, " +
                "bukan sesuatu yang bisa XBoost benerin dari sisi HP.",
            sampleQuestion = "Kenapa sering ke-DC / ping tinggi?"
        ),
        AssistantEntry(
            keywords = listOf("cheat", "hack", "aimbot", "wallhack", "cheater", "exploit", "mod menu"),
            answer = "XBoost sengaja gak nyediain aimbot/wallhack/mod menu atau apapun yang baca-tulis memori game — " +
                "itu di luar cakupan aplikasi ini dan biasanya melanggar TOS game (bisa kena ban). Yang bisa XBoost bantu: " +
                "performa device (FPS, panas, koneksi) dan tips strategi legal di tab Guide.",
            sampleQuestion = "Ada fitur cheat/hack gak?"
        ),
        AssistantEntry(
            keywords = listOf("notif", "notifikasi", "chat masuk", "whatsapp"),
            answer = "Nyalain Game DND di tab Boost (atau otomatis lewat Auto Game Mode) biar notifikasi gak numpuk " +
                "muncul di tengah pertandingan.",
            sampleQuestion = "Cara biar notif gak ganggu pas mabar?"
        )
    )

    private val genericGuide = listOf(
        GuideSection(
            "Sebelum mulai main",
            listOf(
                "Set profile game di tab Games: DND otomatis + layar tetap nyala.",
                "Nyalain Auto Game Mode biar profile itu jalan sendiri begitu game dibuka.",
                "Kalau device kerasa panas, cek Thermal Guard dulu sebelum sesi panjang."
            )
        ),
        GuideSection(
            "Setelan umum yang sering kepake",
            listOf(
                "Sensitivitas kamera: mulai dari default, naikkan sedikit-sedikit sambil latihan di mode latihan/bot match.",
                "Grafis: kalau FPS drop, turunkan satu tingkat dulu sebelum ganti resolusi — biasanya paling kerasa efeknya.",
                "Kontrol/tombol: custom layout HUD sesuai ukuran tangan, jangan ikut-ikutan layout orang lain."
            )
        )
    )

    private val perGame: Map<String, Pair<List<AssistantEntry>, List<GuideSection>>> = mapOf(
        "com.tencent.ig" to (
            listOf(
                AssistantEntry(
                    keywords = listOf("drop", "landing", "mendarat"),
                    answer = "Drop di pinggir map rame kalau mau farming loot aman, drop tengah map kalau mau latihan fight lebih sering.",
                    sampleQuestion = "Enaknya drop di mana?"
                ),
                AssistantEntry(
                    keywords = listOf("loot", "senjata", "weapon"),
                    answer = "Prioritas awal: body armor + weapon apa aja buat jaga-jaga, baru upgrade ke senjata & attachment pilihan setelah aman.",
                    sampleQuestion = "Prioritas loot awal apa aja?"
                ),
                AssistantEntry(
                    keywords = listOf("zona", "circle", "rotasi", "rotate"),
                    answer = "Selalu cek arah zona berikutnya dari early game, jangan nunggu zona nutup baru rotasi — itu yang paling sering bikin kena damage zona.",
                    sampleQuestion = "Kapan waktu terbaik buat rotasi zona?"
                )
            ) to listOf(
                GuideSection("Awal permainan", listOf(
                    "Drop sesuai gaya main: aman di pinggir, agresif di tengah.",
                    "Ambil armor & healing dulu sebelum grinding attachment."
                )),
                GuideSection("Rotasi & zona", listOf(
                    "Rotasi lebih awal daripada telat — jalan kaki di akhir zona sangat berisiko.",
                    "Manfaatkan kendaraan buat rotasi jarak jauh, tapi matikan suara mesin di area rame."
                ))
            )
        ),
        "com.mobile.legends" to (
            listOf(
                AssistantEntry(
                    keywords = listOf("jungle", "hutan", "buff"),
                    answer = "Ambil buff merah dulu di awal buat sustain, prioritaskan buff biru buat role mage/mana-hungry.",
                    sampleQuestion = "Urutan ambil buff jungle gimana?"
                ),
                AssistantEntry(
                    keywords = listOf("rotasi", "gank", "roam"),
                    answer = "Rotasi ke lane yang push duluan atau lagi low HP — gank yang telat lebih sering rugi daripada untung.",
                    sampleQuestion = "Kapan waktu gank yang bagus?"
                ),
                AssistantEntry(
                    keywords = listOf("build", "item", "emblem"),
                    answer = "Sesuaikan build sama komposisi musuh tiap match, jangan pakai build fix dari awal ke awal.",
                    sampleQuestion = "Build item ngikutin apa?"
                )
            ) to listOf(
                GuideSection("Role dasar", listOf(
                    "Jungle: fokus farm + objective (turtle/lord), bukan ngejar kill terus.",
                    "Roam: sediakan vision & save carry, bukan cuma jalan bareng carry."
                )),
                GuideSection("Draft pick", listOf(
                    "Ban hero yang paling sering nge-carry di rank kamu, bukan cuma yang kamu benci.",
                    "Pick counter di akhir draft kalau posisinya memungkinkan."
                ))
            )
        ),
        "com.miHoYo.GenshinImpact" to (
            listOf(
                AssistantEntry(
                    keywords = listOf("elemental", "reaction", "reaksi"),
                    answer = "Reaksi Vaporize/Melt biasanya damage paling gede, tapi Electro-Charged/Superconduct berguna buat clear grup musuh.",
                    sampleQuestion = "Reaksi elemen apa yang paling damage?"
                ),
                AssistantEntry(
                    keywords = listOf("stamina", "sprint", "climb"),
                    answer = "Bawa food buff stamina buat eksplorasi panjang, dan cek Waypoint biar gak habis stamina di climbing sia-sia.",
                    sampleQuestion = "Cara hemat stamina pas eksplorasi?"
                ),
                AssistantEntry(
                    keywords = listOf("team", "party", "comp"),
                    answer = "Susun party sekitar 1 main DPS + 1 sub-DPS + 1 support elemental + 1 healer/shielder buat kebanyakan konten.",
                    sampleQuestion = "Susunan party yang ideal gimana?"
                )
            ) to listOf(
                GuideSection("Team building", listOf(
                    "Cek elemen party — hindari overlap elemen yang gak saling sinergi.",
                    "Sisipkan minimal 1 support buat energy recharge kalau ultimate jadi andalan."
                )),
                GuideSection("Eksplorasi", listOf(
                    "Buka Waypoint duluan sebelum eksplorasi jauh biar gampang fast-travel balik.",
                    "Simpan resin buat domain/boss yang lagi kamu kejar, jangan asal pakai."
                ))
            )
        ),
        "com.activision.callofduty.shooter" to (
            listOf(
                AssistantEntry(
                    keywords = listOf("loadout", "class", "attachment"),
                    answer = "Sesuaikan attachment sama range map: mobility buat map sempit, range/stability buat map terbuka.",
                    sampleQuestion = "Attachment loadout enaknya apa?"
                ),
                AssistantEntry(
                    keywords = listOf("sensitivity", "aim", "sensi"),
                    answer = "Naikkan sensitivitas ADS pelan-pelan, jangan langsung tinggi — konsistensi lebih penting dari kecepatan mentah.",
                    sampleQuestion = "Sensitivitas aim yang pas berapa?"
                )
            ) to listOf(
                GuideSection("Loadout", listOf(
                    "Punya minimal 2 loadout: 1 buat map sempit (SMG/mobility), 1 buat map terbuka (AR/sniper).",
                    "Cek perk yang cocok sama gaya main (aggressive vs objective-holder)."
                ))
            )
        ),
        "com.dts.freefireth" to (
            listOf(
                AssistantEntry(
                    keywords = listOf("drop", "landing", "mendarat"),
                    answer = "Drop di pojok map buat farming aman, drop dekat pesawat kalau mau latihan early fight.",
                    sampleQuestion = "Enaknya drop di mana?"
                ),
                AssistantEntry(
                    keywords = listOf("zona", "rotasi"),
                    answer = "Karena map lebih kecil dari game battle royale lain, rotasi lebih cepat penting — jangan nunggu zona final buat gerak.",
                    sampleQuestion = "Rotasi zona idealnya kapan?"
                )
            ) to listOf(
                GuideSection("Awal permainan", listOf(
                    "Prioritaskan gloo wall & healing item di early game buat survive rotasi.",
                    "Perhatikan karakter/skill combo yang dipakai — sesuaikan sama gaya main solo/squad."
                ))
            )
        )
    )

    fun guideFor(pkg: String): List<GuideSection> =
        (perGame[pkg]?.second ?: emptyList()) + genericGuide

    private fun assistantEntriesFor(pkg: String): List<AssistantEntry> =
        (perGame[pkg]?.first ?: emptyList()) + genericAssistant

    /**
     * Splits free text into lowercase word tokens for scoring — deliberately
     * simple (no stemming/NLP model) since everything runs on-device with
     * zero dependencies and needs to work identically on a 1GB phone.
     */
    private fun tokenize(text: String): List<String> =
        text.lowercase().split(Regex("[^a-z0-9]+")).filter { it.isNotBlank() }

    /**
     * Scored keyword match instead of "first entry that contains a substring":
     * every keyword the query touches adds to that entry's score, so a
     * question that mentions two relevant words beats one that only
     * half-matches, and a keyword matching a whole word scores higher than
     * a keyword that's merely a substring of a longer, unrelated word.
     * Still 100% offline lookup — no network call, no model weights, no
     * gameplay automation of any kind.
     */
    fun answer(pkg: String, query: String): String? {
        val q = query.lowercase().trim()
        if (q.isBlank()) return null
        val queryTokens = tokenize(q)
        val entries = assistantEntriesFor(pkg)

        var best: AssistantEntry? = null
        var bestScore = 0
        for (entry in entries) {
            var score = 0
            for (keyword in entry.keywords) {
                if (queryTokens.contains(keyword)) {
                    score += 3 // exact word match — strong signal
                } else if (q.contains(keyword)) {
                    score += 1 // substring match — weaker, e.g. plural/prefix
                }
            }
            if (score > bestScore) {
                bestScore = score
                best = entry
            }
        }
        return best?.answer
    }

    /** Natural-language sample questions for the suggestion chips, not raw keywords. */
    fun suggestedQuestions(pkg: String): List<String> =
        assistantEntriesFor(pkg).take(4).map { it.sampleQuestion }
}
