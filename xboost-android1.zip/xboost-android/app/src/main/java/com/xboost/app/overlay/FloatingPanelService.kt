package com.xboost.app.overlay

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.GridLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.xboost.app.MainActivity
import com.xboost.app.R
import com.xboost.app.core.BoostMode
import com.xboost.app.core.BoosterEngine
import com.xboost.app.core.DeviceCompat
import com.xboost.app.core.DeviceTier
import com.xboost.app.core.PerformanceModuleManager
import com.xboost.app.core.PreferencesManager
import com.xboost.app.core.SplitScreenManager
import com.xboost.app.core.SystemMonitor
import com.xboost.app.core.ThermalGuardManager
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlin.math.abs

/**
 * A small draggable bubble that expands into a real "Game Mode" style quick
 * panel — the same pattern as Samsung Game Booster / RedMagic's in-game
 * overlay: live temperature, module toggles, and a shortcut into the
 * per-game AI Assistant & Guide. Every action here calls the same real
 * BoosterEngine / PreferencesManager functions used elsewhere in the app —
 * a different entry point to real actions, not new placebo buttons.
 *
 * Can start two ways:
 *  - Manually pinned via the "Floating Quick Panel" switch in Modules
 *    (plain `startForegroundService`, no extra) — stays until switched off.
 *  - Auto-launched by GameWatcherService the moment a known game opens
 *    (`EXTRA_AUTO_GAME_PKG` set) — briefly greets you with the game's name,
 *    then collapses to just the bubble, and GameWatcherService will stop it
 *    on its own once you leave the game. isAutoLaunched() is how that
 *    watcher knows it's safe to do that without touching a manually pinned
 *    panel.
 */
class FloatingPanelService : Service() {

    private lateinit var windowManager: WindowManager
    private var bubbleView: View? = null
    private var panelView: View? = null
    private var tempLabel: TextView? = null
    private var headerLabel: TextView? = null
    private var fpsButton: TextView? = null
    private var rotateTile: TextView? = null
    private var crystalGauge: CrystalGaugeView? = null
    private var radarView: RadarStatView? = null
    private var profileButtons: Map<BoostMode, TextView> = emptyMap()
    private var brightnessBar: SeekBar? = null
    private var expanded = false
    private var fpsRunning = false
    private var rotateLocked = false
    private var isAutoLaunch = false
    private var currentGamePkg: String? = null
    private var autoCollapseRunnable: Runnable? = null
    private var cpuSampleInFlight = false
    private var pingSampleInFlight = false
    private var lastPingMs: Long? = null
    private var currentMode: BoostMode = BoostMode.BALANCE

    private val mainHandler = Handler(Looper.getMainLooper())
    // Device-aware tick interval: never faster than DeviceCompat's polling
    // floor for this RAM tier, so a 1-2GB phone isn't paying for a 3s wakeup
    // loop it can't spare while a game is running. Same real numbers already
    // used for the live-stat polling elsewhere (DeviceCompat.classify).
    private var tempTickIntervalMs = 3000L
    private val tempTicker = object : Runnable {
        override fun run() {
            tempLabel?.text = tempDisplayText()
            updateGauges()
            mainHandler.postDelayed(this, tempTickIntervalMs)
        }
    }

    // Radar's network axis needs a real ping round-trip (up to ~1.5s timeout),
    // so it ticks on its own slower cadence — sampling it as often as the
    // crystal gauge would mean a ping in flight almost constantly.
    private var radarTickIntervalMs = 6000L
    private val radarTicker = object : Runnable {
        override fun run() {
            updateRadar()
            mainHandler.postDelayed(this, radarTickIntervalMs)
        }
    }

    private var lastTempC: Float? = null
    private var lastCpuPercent: Int? = null

    /**
     * Refreshes the crystal gauge — Temp/RAM come straight from
     * ThermalGuardManager/SystemMonitor (already-open synchronous, fast
     * reads). CPU requires SystemMonitor.cpuUsagePercent()'s ~360ms /proc/stat
     * double-sample, so it always runs off the main thread and posts back —
     * never blocks the overlay, never fakes a number while it's mid-sample.
     */
    private fun updateGauges() {
        val c = ThermalGuardManager.currentBatteryTempCelsius(applicationContext)
        lastTempC = c
        val ram = SystemMonitor.getRamInfo(applicationContext)
        val storagePct = runCatching { SystemMonitor.storagePercentUsed() }.getOrDefault(0)

        crystalGauge?.refresh(
            tempC = c,
            cpuPercent = lastCpuPercent,
            ramPercent = ram.percentUsed,
            storagePercent = storagePct
        )

        if (!cpuSampleInFlight) {
            cpuSampleInFlight = true
            Thread {
                val cpu = runCatching { SystemMonitor.cpuUsagePercent() }.getOrNull()
                mainHandler.post {
                    cpuSampleInFlight = false
                    lastCpuPercent = cpu
                    crystalGauge?.refresh(
                        tempC = lastTempC,
                        cpuPercent = cpu,
                        ramPercent = ram.percentUsed,
                        storagePercent = storagePct
                    )
                }
            }.start()
        }
    }

    /**
     * Recomputes the 5-axis radar. Thermal/Memory/Storage are synchronous
     * real reads; CPU reuses whatever the crystal gauge last sampled instead
     * of triggering a second /proc/stat double-read every tick. Network is
     * the one genuinely async piece — a real ping via SystemMonitor.pingMs,
     * sampled off the main thread so a slow/unreachable network can't freeze
     * the panel while it waits out the timeout.
     */
    private fun updateRadar() {
        val c = lastTempC
        val thermalScore = if (c == null) 50 else {
            // 25°C -> 100 (cool), 48°C+ -> 0 (hot). Linear in between.
            (((48f - c) / (48f - 25f)) * 100f).toInt().coerceIn(0, 100)
        }
        val ram = SystemMonitor.getRamInfo(applicationContext)
        val memoryScore = (100 - ram.percentUsed).coerceIn(0, 100)
        val cpuScore = lastCpuPercent?.let { (100 - it).coerceIn(0, 100) } ?: 50
        val storageScore = (100 - runCatching { SystemMonitor.storagePercentUsed() }.getOrDefault(50)).coerceIn(0, 100)

        radarView?.setScores(
            RadarStatView.Scores(
                thermal = thermalScore,
                memory = memoryScore,
                cpu = cpuScore,
                storage = storageScore,
                network = 50 // placeholder until the async ping sample below resolves
            )
        )

        if (!pingSampleInFlight) {
            pingSampleInFlight = true
            Thread {
                val ping = runCatching {
                    kotlinx.coroutines.runBlocking { SystemMonitor.pingMs() }
                }.getOrNull()
                mainHandler.post {
                    pingSampleInFlight = false
                    lastPingMs = ping
                    // 0ms -> 100, 300ms+ -> 0, unreachable -> 0 (honestly bad, not unknown —
                    // a real ping attempt either succeeds within the timeout or it doesn't).
                    val networkScore = if (ping == null) 0 else
                        (100 - (ping.toFloat() / 300f * 100f)).toInt().coerceIn(0, 100)
                    radarView?.setScores(
                        RadarStatView.Scores(
                            thermal = thermalScore,
                            memory = memoryScore,
                            cpu = cpuScore,
                            storage = storageScore,
                            network = networkScore
                        )
                    )
                }
            }.start()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        tempTickIntervalMs = maxOf(3000L, DeviceCompat.classify(applicationContext).pollingFloorMs * 2)
        startForeground(NOTIF_ID, buildNotification())
        fpsRunning = runCatching {
            runBlocking { PreferencesManager.fpsOverlayOn(applicationContext).first() }
        }.getOrDefault(false)
        rotateLocked = runCatching {
            Settings.System.getInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION) == 0
        }.getOrDefault(false)
        currentMode = runCatching {
            runBlocking { PreferencesManager.mode(applicationContext).first() }
        }.getOrDefault(BoostMode.BALANCE)
        addBubble()
        instance = this
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val gamePkg = intent?.getStringExtra(EXTRA_AUTO_GAME_PKG)
        if (gamePkg != null) {
            isAutoLaunch = true
            onGameForegroundChanged(gamePkg)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        mainHandler.removeCallbacks(tempTicker)
        mainHandler.removeCallbacks(radarTicker)
        autoCollapseRunnable?.let { mainHandler.removeCallbacks(it) }
        bubbleView?.let { runCatching { windowManager.removeView(it) } }
        panelView?.let { runCatching { windowManager.removeView(it) } }
        super.onDestroy()
    }

    /**
     * Called by GameWatcherService whenever the detected foreground game
     * changes (new game / left the game -> null). Greets with a brief
     * auto-expand + header showing the game name, then auto-collapses back
     * to just the bubble a few seconds later so it doesn't sit in the way.
     */
    fun onGameForegroundChanged(pkg: String?) {
        currentGamePkg = pkg
        mainHandler.post {
            headerLabel?.text = headerText()
            if (pkg != null && !expanded) {
                toggleExpanded()
                scheduleAutoCollapse()
            } else if (pkg != null && expanded) {
                scheduleAutoCollapse()
            }
        }
    }

    private fun scheduleAutoCollapse() {
        autoCollapseRunnable?.let { mainHandler.removeCallbacks(it) }
        val r = Runnable { if (expanded) toggleExpanded() }
        autoCollapseRunnable = r
        mainHandler.postDelayed(r, 4500)
    }

    private fun headerText(): String {
        val pkg = currentGamePkg
        return if (pkg != null) {
            val name = BoosterEngine.KNOWN_GAMES[pkg] ?: SplitScreenManager.label(applicationContext, pkg)
            "▶ $name detected"
        } else {
            "XBoost Quick Panel"
        }
    }

    private fun tempDisplayText(): String {
        val c = ThermalGuardManager.currentBatteryTempCelsius(applicationContext) ?: return "--°C"
        val level = ThermalGuardManager.levelFor(c)
        val tag = level.name.take(1) // C / W / H
        return "%.1f°C·%s".format(c, tag)
    }

    private fun overlayType() =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    // ---------- visual helpers (rounded, bordered, no more flat rectangles) ----------

    private fun pillDrawable(fillColor: Int, strokeColor: Int? = null, radiusDp: Float = 18f): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusDp * resources.displayMetrics.density
            setColor(fillColor)
            strokeColor?.let { setStroke((1.5f * resources.displayMetrics.density).toInt(), it) }
        }

    private fun circleDrawable(fillColor: Int, strokeColor: Int): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(fillColor)
            setStroke((2f * resources.displayMetrics.density).toInt(), strokeColor)
        }

    private fun addBubble() {
        val bubble = TextView(this).apply {
            text = "X"
            setTextColor(Color.WHITE)
            background = circleDrawable(Color.parseColor("#FF6A2E"), Color.parseColor("#3FC8FF"))
            textSize = 16f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
            val pad = (18 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad, pad, pad)
            elevation = 8f * resources.displayMetrics.density
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 300
        }

        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        bubble.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = params.x; startY = params.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (abs(dx) > 8 || abs(dy) > 8) moved = true
                    params.x = startX + dx
                    params.y = startY + dy
                    runCatching { windowManager.updateViewLayout(v, params) }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) toggleExpanded()
                    true
                }
                else -> false
            }
        }

        windowManager.addView(bubble, params)
        bubbleView = bubble
    }

    private fun toggleExpanded() {
        expanded = !expanded
        if (expanded) addPanel() else removePanel()
    }

    private fun addPanel() {
        val density = resources.displayMetrics.density
        // RedMagic Game Space-style shell: darker panel, brighter gradient-ish
        // edge (red stroke over a cyan-tinted fill reads as the same red/cyan
        // duotone as the rest of the app), bigger radius, roomier padding.
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = pillDrawable(Color.parseColor("#F50B0A0E"), Color.parseColor("#66FF6A2E"), radiusDp = 20f)
            elevation = 14f * density
            setPadding((16 * density).toInt(), (14 * density).toInt(), (16 * density).toInt(), (12 * density).toInt())
        }

        // Header row — game name/status on the left, a small live pill on the
        // right, mirroring the "● LIVE" strip RedMagic's overlay keeps pinned
        // at the top of its panel.
        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(2, 0, 2, (10 * density).toInt())
        }
        val header = TextView(this).apply {
            text = headerText()
            setTextColor(Color.parseColor("#F5F1EA"))
            textSize = 12.5f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        headerLabel = header
        headerRow.addView(header)
        headerRow.addView(TextView(this).apply {
            text = "●"
            setTextColor(Color.parseColor("#FF6A2E"))
            textSize = 10f
            setPadding((6 * density).toInt(), 0, 0, 0)
        })
        column.addView(headerRow)

        // Crystal gauge — Temp/RAM/Storage/CPU around a faceted octagon core,
        // ticking every device-aware interval while the panel is open.
        val gaugeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, (4 * density).toInt())
        }
        val crystal = CrystalGaugeView(this)
        crystalGauge = crystal
        gaugeRow.addView(crystal)
        column.addView(gaugeRow)

        // 5-axis radar underneath — Thermal/Memory/CPU/Storage/Network
        // headroom, same "profile shape" idea as ROG's Game Genie panel,
        // built from XBoost's own real reads (see updateRadar()).
        val radar = RadarStatView(this)
        radarView = radar
        column.addView(radar)

        // Performance-profile switcher — the radar's shape is meant to shift
        // when you change modes, same relationship ROG's X Mode/Dynamic/Ultra
        // Durable buttons have to their radar. Reuses the exact same 3 modes
        // (and PerformanceModuleManager.applyProfile) as Boost screen/Settings
        // — a different entry point to the same real profiles, not a
        // parallel fake one.
        column.addView(profileSwitcherRow())

        // Kept for anything still reading the plain-text readout (auto-collapse
        // greeting, notification), just no longer shown as its own line.
        tempLabel = TextView(this).apply { text = tempDisplayText() }
        mainHandler.post(tempTicker)
        mainHandler.post(radarTicker)

        // Live brightness slider — a direct, real-time Settings.System.SCREEN_BRIGHTNESS
        // write, completely separate from the Boost screen's Performance Module
        // brightness (which only fires when a mode is explicitly applied there).
        // Dragging this never writes any XBoost preference and never touches
        // BoostMode/PerformanceProfile, so switching modes in Booster can't
        // silently override what you set here, and this slider can't silently
        // change what Booster's own mode brightness will apply next time either
        // — the two are intentionally independent, not synced.
        column.addView(brightnessRow())

        // Icon-tile grid — the core quick toggles as square tiles (icon glyph
        // over label) in a 3-column grid, the same "grid of glanceable
        // controls" layout RedMagic's Game Space panel uses instead of a
        // single scrolling button row.
        val grid = GridLayout(this).apply {
            columnCount = 3
            setPadding(0, 0, 0, (10 * density).toInt())
        }
        grid.addView(iconTile("⚡", "Boost") { runQuickBoost() })
        grid.addView(iconTile("🌙", "DND") {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            val turningOn = nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_PRIORITY
            BoosterEngine.setGameDnd(applicationContext, turningOn)
        })
        val fpsTile = iconTile(if (fpsRunning) "📈" else "📊", fpsLabel()) { toggleFpsOverlay() }
        fpsButton = fpsTile.getChildAt(1) as TextView
        grid.addView(fpsTile)
        grid.addView(iconTile("🧹", "Trim") { runQuickTrim() })
        val rotate = iconTile(if (rotateLocked) "🔒" else "🔄", rotateLabel()) { toggleRotateLock() }
        rotateTile = rotate.getChildAt(1) as TextView
        grid.addView(rotate)
        grid.addView(iconTile("✂️", "Split") { launchSplitPair() })
        grid.addView(iconTile("➕", "Add Game") { addForegroundAppAsGame() })
        grid.addView(iconTile("🎮", "Guide") { openGuideForForegroundGame() })
        column.addView(grid)

        // Floating favorite apps — up to PreferencesManager.FLOATING_FAVORITES_MAX
        // quick-launch shortcuts chosen in Modules → Split Screen & Floating
        // Apps. This is the "floating, hovering app" launcher: one tap opens
        // the app on top of whatever game/app is currently running, no need
        // to leave it first — and it supports several apps, not just a pair,
        // so it doubles as a lightweight "other apps float over the booster"
        // shortcut bar.
        val favorites = runCatching {
            runBlocking { PreferencesManager.floatingFavorites(applicationContext).first() }
        }.getOrDefault(emptySet())
        // Cap at 2 icons on a LOW-tier (~1-3GB) device instead of the full
        // list: fewer overlay child views to inflate/measure over an
        // already-running game. MID/HIGH devices (up to 12GB+) get all of
        // them, scrollable if there are more than fit on screen.
        val tier = DeviceCompat.classify(applicationContext).tier
        val favoriteLimit = if (tier == DeviceTier.LOW) 2 else PreferencesManager.FLOATING_FAVORITES_MAX
        if (favorites.isNotEmpty()) {
            val favRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, 0, 0, (8 * density).toInt())
            }
            favorites.take(favoriteLimit).forEach { pkg ->
                favRow.addView(actionButton(SplitScreenManager.label(applicationContext, pkg).take(8), filled = false) {
                    SplitScreenManager.launchPrimary(applicationContext, pkg)
                })
            }
            val favScroller = HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                addView(favRow)
            }
            column.addView(favScroller)
        }

        // Thin divider between stats/favorites and the action row.
        column.addView(View(this).apply {
            setBackgroundColor(Color.parseColor("#3FC8FF"))
            alpha = 0.18f
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, (1 * density).toInt()
            ).apply { bottomMargin = (8 * density).toInt() }
        })

        // Secondary action bar — less-frequent actions stay as a horizontally
        // scrolling pill row under the icon grid, instead of crowding the
        // 3-column grid above with items you tap once per session.
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        row.addView(actionButton("Open") {
            val openIntent = Intent(applicationContext, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(openIntent)
        })
        row.addView(actionButton("Close", filled = true, accentColor = Color.parseColor("#FF6A2E")) {
            stopSelf()
        })

        val scroller = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(row)
        }
        column.addView(scroller)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 320
            width = (282 * density).toInt()
        }

        windowManager.addView(column, params)
        panelView = column
        updateGauges()

        // Simple fade+rise entrance instead of an abrupt pop-in — cheap on
        // every RAM tier (one alpha + translationY animator, no Compose).
        column.alpha = 0f
        column.translationY = 12 * density
        column.animate().alpha(1f).translationY(0f).setDuration(160).start()
    }

    private fun removePanel() {
        mainHandler.removeCallbacks(tempTicker)
        mainHandler.removeCallbacks(radarTicker)
        autoCollapseRunnable?.let { mainHandler.removeCallbacks(it) }
        tempLabel = null
        headerLabel = null
        fpsButton = null
        rotateTile = null
        crystalGauge = null
        radarView = null
        profileButtons = emptyMap()
        brightnessBar = null
        panelView?.let { runCatching { windowManager.removeView(it) } }
        panelView = null
    }

    private fun rotateLabel() = if (rotateLocked) "Locked" else "Rotate"

    /**
     * Auto-rotation lock — a genuine Settings.System write (ACCELEROMETER_ROTATION),
     * the same permission family WRITE_SETTINGS already covers for Performance
     * Modules. If the user hasn't granted "Modify system settings" yet, this
     * opens that exact settings screen instead of silently no-opping.
     */
    private fun toggleRotateLock() {
        if (!Settings.System.canWrite(applicationContext)) {
            val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            runCatching { startActivity(intent) }
            return
        }
        rotateLocked = !rotateLocked
        runCatching {
            Settings.System.putInt(
                contentResolver,
                Settings.System.ACCELEROMETER_ROTATION,
                if (rotateLocked) 0 else 1
            )
        }
        rotateTile?.text = rotateLabel()
    }

    /**
     * One-tap "Boost" tile — calls the exact same BoosterEngine.runFullBoost
     * used by the Boost screen's main button (background trim + Game DND),
     * just reachable without leaving the game. Flashes the real result count
     * in the header for 2s, then reverts — no separate toast permission needed.
     */
    private fun runQuickBoost() {
        val result = BoosterEngine.runFullBoost(applicationContext, dnd = true)
        headerLabel?.text = result.message
        mainHandler.postDelayed({ headerLabel?.text = headerText() }, 2000)
    }

    private fun runQuickTrim() {
        val killed = BoosterEngine.trimBackgroundProcesses(applicationContext)
        headerLabel?.text = if (killed > 0) "Trimmed $killed app(s)" else "Already lean"
        mainHandler.postDelayed({ headerLabel?.text = headerText() }, 2000)
    }

    /**
     * Live brightness slider. Reads the current real SCREEN_BRIGHTNESS value
     * (0-255) into a 0-100 bar, and on every drag writes it straight back via
     * Settings.System — the exact same setting the OS brightness slider in
     * Quick Settings controls. Deliberately does NOT read/write anything in
     * PreferencesManager or PerformanceProfile: this is a direct hardware
     * control, not a "mode", so it can never fight with — or be silently
     * overwritten by — the Boost screen's Performance Module, and dragging it
     * never changes what Balance/Performance/Battery Save will set next time
     * you pick one of those there.
     */
    private fun brightnessRow(): LinearLayout {
        val density = resources.displayMetrics.density
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, (12 * density).toInt())
        }
        row.addView(TextView(this).apply {
            text = "🔆"
            textSize = 13f
            setPadding(0, 0, (8 * density).toInt(), 0)
        })
        val currentPct = runCatching {
            (Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f * 100).toInt()
        }.getOrDefault(50).coerceIn(0, 100)

        val bar = SeekBar(this).apply {
            max = 100
            progress = currentPct
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    if (!Settings.System.canWrite(applicationContext)) return
                    runCatching {
                        Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                        Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, (value / 100f * 255).toInt().coerceIn(1, 255))
                    }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
            setOnTouchListener { v, event ->
                // Consume the touch stream here so it doesn't fall through to
                // the panel's own drag/dismiss handling — this bar has to win
                // every drag gesture that starts on it.
                v.parent?.requestDisallowInterceptTouchEvent(true)
                false
            }
        }
        brightnessBar = bar

        if (!Settings.System.canWrite(applicationContext)) {
            row.addView(TextView(this).apply {
                text = "Tap to allow brightness control"
                setTextColor(Color.parseColor("#9C97A3"))
                textSize = 10f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener {
                    val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    runCatching { startActivity(intent) }
                }
            })
        } else {
            row.addView(bar)
        }
        return row
    }

    /**
     * "+ Add Game" tile — adds whichever app is currently in the foreground
     * (usually the game you're playing right now) to XBoost's Game Library
     * as a custom entry, via the exact same PreferencesManager set the
     * Game Library screen's "Add Game" picker writes to. Requires Usage
     * Access (same permission Auto Game Mode already needs) to know what's
     * foreground; falls back to opening the manual picker if that's not
     * granted or nothing's detected, instead of silently doing nothing.
     */
    private fun addForegroundAppAsGame() {
        val fg = runCatching { BoosterEngine.currentForegroundApp(applicationContext) }.getOrNull()
        if (fg == null || fg == packageName) {
            val openIntent = Intent(applicationContext, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                putExtra(MainActivity.EXTRA_NAV_ROUTE, "games")
            }
            startActivity(openIntent)
            return
        }
        runCatching { runBlocking { PreferencesManager.setCustomGame(applicationContext, fg, true) } }
        val label = SplitScreenManager.label(applicationContext, fg)
        headerLabel?.text = "Added $label to Game Library"
        mainHandler.postDelayed({ headerLabel?.text = headerText() }, 2000)
    }

    /**
     * Three-way profile switcher under the radar — Performance / Balance /
     * Battery Saver, i.e. the same BoostMode enum and PerformanceModuleManager
     * the Boost screen and Settings already drive. Tapping a pill here calls
     * the real applyProfile() (screen timeout, background trim, DND/screen-awake
     * defaults) and persists the choice, so switching mode from the overlay
     * and switching it from the main app stay in sync either direction.
     */
    private fun profileSwitcherRow(): LinearLayout {
        val density = resources.displayMetrics.density
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, (10 * density).toInt(), 0, (10 * density).toInt())
        }
        val modes = listOf(
            BoostMode.PERFORMANCE to "Performance",
            BoostMode.BALANCE to "Balance",
            BoostMode.BATTERY_SAVE to "Battery Saver"
        )
        val buttons = mutableMapOf<BoostMode, TextView>()
        modes.forEach { (mode, label) ->
            val btn = TextView(this).apply {
                text = label
                textSize = 9.5f
                gravity = Gravity.CENTER
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setPadding((10 * density).toInt(), (8 * density).toInt(), (10 * density).toInt(), (8 * density).toInt())
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                lp.marginEnd = if (mode != BoostMode.BATTERY_SAVE) (6 * density).toInt() else 0
                layoutParams = lp
                setOnClickListener { applyModeFromPanel(mode) }
            }
            buttons[mode] = btn
            row.addView(btn)
        }
        profileButtons = buttons
        styleProfileButtons()
        return row
    }

    /** Repaints the 3 profile pills so the active one is filled/ember and the rest are outlined. */
    private fun styleProfileButtons() {
        profileButtons.forEach { (mode, btn) ->
            val active = mode == currentMode
            btn.setTextColor(if (active) Color.WHITE else Color.parseColor("#9C97A3"))
            btn.background = if (active) {
                pillDrawable(Color.parseColor("#FF6A2E"), radiusDp = 12f)
            } else {
                pillDrawable(Color.parseColor("#18151C"), Color.parseColor("#2C2732"), radiusDp = 12f)
            }
        }
    }

    /**
     * Applies a profile tapped from the overlay's switcher — same real effects
     * as Settings > Performance Module (see PerformanceModuleManager.applyProfile):
     * screen timeout, background trim, DND/screen-awake defaults. Persists the
     * mode via PreferencesManager so the Boost screen reflects the change next
     * time it's opened, then briefly shows what actually happened in the header
     * instead of a generic "Applied" toast.
     */
    private fun applyModeFromPanel(mode: BoostMode) {
        currentMode = mode
        styleProfileButtons()
        runCatching { runBlocking { PreferencesManager.setMode(applicationContext, mode) } }
        val result = runCatching { PerformanceModuleManager.applyProfile(applicationContext, mode) }.getOrNull()
        headerLabel?.text = result?.summary?.take(48) ?: "${mode.name} applied"
        mainHandler.postDelayed({ headerLabel?.text = headerText() }, 2500)
    }

    /** Ring gauge + small caption label, stacked vertically, used for Temp/RAM/CPU. */
    private fun ringWithCaption(caption: String, color: Int, capture: (RingGaugeView) -> Unit): LinearLayout {
        val density = resources.displayMetrics.density
        val ring = RingGaugeView(this).apply { ringColor = color }
        capture(ring)
        val stack = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            addView(ring)
            addView(TextView(this@FloatingPanelService).apply {
                text = caption
                setTextColor(Color.parseColor("#9C97A3"))
                textSize = 9.5f
                gravity = Gravity.CENTER
                setPadding(0, (3 * density).toInt(), 0, 0)
            })
        }
        return stack
    }

    /** Square icon tile (glyph over label) used by the 3-column quick-toggle grid. */
    private fun iconTile(icon: String, label: String, onClick: () -> Unit): LinearLayout {
        val density = resources.displayMetrics.density
        val size = (78 * density).toInt()
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = pillDrawable(Color.parseColor("#18151C"), Color.parseColor("#22FF6A2E"), radiusDp = 12f)
            val lp = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED, 1f), GridLayout.spec(GridLayout.UNDEFINED, 1f))
            lp.width = size
            lp.height = (size * 0.86f).toInt()
            lp.setMargins((3 * density).toInt(), (3 * density).toInt(), (3 * density).toInt(), (3 * density).toInt())
            layoutParams = lp
            setOnClickListener { onClick() }
        }
        tile.addView(TextView(this).apply {
            text = icon
            textSize = 18f
            gravity = Gravity.CENTER
        })
        tile.addView(TextView(this).apply {
            text = label
            setTextColor(Color.parseColor("#F5F1EA"))
            textSize = 9.5f
            gravity = Gravity.CENTER
            setPadding(0, (2 * density).toInt(), 0, 0)
        })
        return tile
    }

    private fun fpsLabel() = if (fpsRunning) "FPS✓" else "FPS"

    private fun toggleFpsOverlay() {
        fpsRunning = !fpsRunning
        val intent = Intent(applicationContext, FpsOverlayService::class.java)
        if (fpsRunning) startForegroundService(intent) else stopService(intent)
        runCatching { runBlocking { PreferencesManager.setFpsOverlayOn(applicationContext, fpsRunning) } }
        fpsButton?.text = fpsLabel()
    }

    /**
     * Opens XBoost straight into the AI Assistant & Guide tab for whichever
     * known game is currently in the foreground (needs Usage Access, same
     * permission Auto Game Mode already relies on). Falls back to the Game
     * Library if no known game is detected right now, instead of guessing.
     */
    private fun openGuideForForegroundGame() {
        val fg = runCatching { BoosterEngine.currentForegroundApp(applicationContext) }.getOrNull()
        val customGames = runCatching {
            runBlocking { PreferencesManager.customGames(applicationContext).first() }
        }.getOrDefault(emptySet())
        val route = if (fg != null && (BoosterEngine.KNOWN_GAMES.containsKey(fg) || customGames.contains(fg))) "game_assistant/$fg" else "games"
        val openIntent = Intent(applicationContext, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
            putExtra(MainActivity.EXTRA_NAV_ROUTE, route)
        }
        startActivity(openIntent)
    }

    /**
     * Uses the App A / App B pair saved in Split Screen & Floating Apps.
     * Real behavior, same as the Split Screen screen's "Launch Split"
     * button — see SplitScreenManager for exactly what the adjacent-launch
     * flag can and can't do on a non-root device.
     */
    private fun launchSplitPair() {
        val (a, b) = runCatching {
            runBlocking { PreferencesManager.splitApps(applicationContext).first() }
        }.getOrDefault(null to null)
        if (a != null && b != null) {
            SplitScreenManager.launchPair(applicationContext, a, b)
        } else {
            val openIntent = Intent(applicationContext, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                putExtra(MainActivity.EXTRA_NAV_ROUTE, "split_screen")
            }
            startActivity(openIntent)
        }
    }

    private fun actionButton(
        label: String,
        filled: Boolean = false,
        accentColor: Int = Color.parseColor("#3FC8FF"),
        onClick: () -> Unit
    ): TextView {
        val density = resources.displayMetrics.density
        return TextView(this).apply {
            text = label
            setTextColor(if (filled) Color.WHITE else accentColor)
            background = if (filled) pillDrawable(accentColor, radiusDp = 14f) else pillDrawable(Color.parseColor("#1A3FC8FF"), accentColor, radiusDp = 14f)
            textSize = 11f
            setPadding((16 * density).toInt(), (9 * density).toInt(), (16 * density).toInt(), (9 * density).toInt())
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.marginEnd = (6 * density).toInt()
            layoutParams = lp
            setOnClickListener { onClick() }
        }
    }

    private fun buildNotification(): android.app.Notification {
        val channelId = "xboost_floating_panel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(channelId, "Floating Panel", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("XBoost floating panel active")
            .setContentText("Tap the bubble for quick actions")
            .setSmallIcon(R.drawable.ic_xboost_logo)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val NOTIF_ID = 4203
        const val EXTRA_AUTO_GAME_PKG = "auto_game_pkg"

        @Volatile private var instance: FloatingPanelService? = null

        fun isRunning(): Boolean = instance != null

        /** True only if the currently running panel was opened by GameWatcherService, not manually pinned. */
        fun isAutoLaunched(): Boolean = instance?.isAutoLaunch == true

        /** GameWatcherService calls this to update/greet an already-running panel without restarting it. */
        fun notifyGameForeground(pkg: String?) {
            instance?.onGameForegroundChanged(pkg)
        }
    }
}
