package com.xboost.app.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// "Circuit Ember" type system. Two roles instead of one flat sans: a wide,
// heavily-tracked display face for headers/labels (reads like a panel
// readout, uppercase-friendly) and FontFamily.Monospace reserved for any
// live numeric telemetry (temps, %, FPS, ms) so stats feel measured
// rather than decorative. No bundled .ttf needed — system families only,
// so the project keeps building with zero extra font assets.
val XBoostTypography = Typography(
    headlineMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Black,
        fontSize = 22.sp,
        letterSpacing = 1.6.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp,
        letterSpacing = 1.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        letterSpacing = 0.1.sp
    ),
    labelSmall = TextStyle(
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.Bold,
        fontSize = 10.sp,
        letterSpacing = 1.2.sp
    )
)

// Reserved for live numeric readouts (RAM/CPU/temp/FPS values) — screens
// can opt in with `style = XBoostMonoNumeral` to get the instrumentation
// look without needing a new dependency or font file.
val XBoostMonoNumeral = TextStyle(
    fontFamily = FontFamily.Monospace,
    fontWeight = FontWeight.Bold,
    letterSpacing = 0.sp
)
