package com.xboost.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.xboost.app.core.AccentColor
import com.xboost.app.core.BoostMode
import com.xboost.app.core.DeviceCompat
import com.xboost.app.core.PerformanceModuleManager
import com.xboost.app.core.PermissionManager
import com.xboost.app.core.PreferencesManager
import com.xboost.app.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    onOpenModules: () -> Unit,
    onOpenSupport: () -> Unit,
    onOpenSecurity: () -> Unit,
    onOpenOnboarding: () -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val lifecycleOwner = LocalLifecycleOwner.current

    var usageGranted by remember { mutableStateOf(PermissionManager.hasUsageAccess(context)) }
    var notifGranted by remember { mutableStateOf(PermissionManager.hasNotificationAccess(context)) }
    var overlayGranted by remember { mutableStateOf(PermissionManager.hasOverlayPermission(context)) }
    var writeSettingsGranted by remember { mutableStateOf(PermissionManager.hasWriteSettings(context)) }

    val accent by PreferencesManager.accentColor(context).collectAsState(initial = AccentColor.RED)

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                usageGranted = PermissionManager.hasUsageAccess(context)
                notifGranted = PermissionManager.hasNotificationAccess(context)
                overlayGranted = PermissionManager.hasOverlayPermission(context)
                writeSettingsGranted = PermissionManager.hasWriteSettings(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    Column(
        modifier = Modifier.fillMaxSize().background(Bg0).verticalScrollFix().padding(horizontal = 20.dp, vertical = 24.dp)
    ) {
        Text("SETTINGS", color = Text0, fontWeight = FontWeight.Bold, fontSize = 19.sp)
        Spacer(Modifier.height(18.dp))

        Text("PERMISSIONS", color = Text1, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Spacer(Modifier.height(10.dp))
        SettingsRow(Icons.Filled.Visibility, "Usage Access", if (usageGranted) "Granted" else "Not granted — tap to open Settings", usageGranted) {
            PermissionManager.openUsageAccessSettings(context)
        }
        Spacer(Modifier.height(8.dp))
        SettingsRow(Icons.Filled.Notifications, "Notification Access", if (notifGranted) "Granted" else "Not granted — tap to open Settings", notifGranted) {
            PermissionManager.openNotificationAccessSettings(context)
        }
        Spacer(Modifier.height(8.dp))
        SettingsRow(Icons.Filled.PictureInPicture, "Display Over Other Apps", if (overlayGranted) "Granted" else "Needed for FPS overlay & App Lock", overlayGranted) {
            PermissionManager.openOverlaySettings(context)
        }
        Spacer(Modifier.height(8.dp))
        SettingsRow(Icons.Filled.Tune, "Modify System Settings", if (writeSettingsGranted) "Granted" else "Needed for the Performance Module", writeSettingsGranted) {
            PermissionManager.openWriteSettings(context)
        }

        Spacer(Modifier.height(24.dp))
        Text("MODULES", color = Text1, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Spacer(Modifier.height(10.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Panel, RoundedCornerShape(14.dp))
                .border(1.dp, XCyan.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                .clickable { onOpenModules() }
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Icon(Icons.Filled.Extension, contentDescription = null, tint = XCyan, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Manage Modules", color = Text0, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        "11 modules: Background Trim, Game DND, Screen Awake, Auto Game Mode, FPS Overlay, App Lock, Floating Panel, Game AI Assistant & Guide, High Refresh Rate, Thermal Guard, Background Persistence",
                        color = Text2, fontSize = 10.sp, lineHeight = 14.sp, modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
            Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = Text2)
        }

        Spacer(Modifier.height(24.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Panel, RoundedCornerShape(14.dp))
                .border(1.dp, Line, RoundedCornerShape(14.dp))
                .clickable { onOpenOnboarding() }
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Icon(Icons.Filled.MenuBook, contentDescription = null, tint = Text1, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Lihat Panduan Awal Lagi", color = Text0, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        "Panduan yang muncul otomatis saat instal pertama kali — buka lagi manual kapan saja",
                        color = Text2, fontSize = 10.sp, lineHeight = 14.sp, modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
            Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = Text2)
        }

        Spacer(Modifier.height(24.dp))
        Text("SECURITY", color = Text1, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Spacer(Modifier.height(10.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Panel, RoundedCornerShape(14.dp))
                .border(1.dp, XRed.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                .clickable { onOpenSecurity() }
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Icon(Icons.Filled.Shield, contentDescription = null, tint = XRed, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Security Scan", color = Text0, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text("Check installed apps for risky permissions & install sources", color = Text2, fontSize = 10.sp)
                }
            }
            Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = Text2)
        }

        Spacer(Modifier.height(24.dp))
        Text("DEVICE COMPATIBILITY", color = Text1, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Spacer(Modifier.height(10.dp))
        Column(
            modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).border(1.dp, Line, RoundedCornerShape(14.dp)).padding(16.dp)
        ) {
            val device = remember(context) { DeviceCompat.classify(context) }
            Text(DeviceCompat.tierLabel(device), color = Text0, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            Text(
                "RAM: ${if (device.totalRamMb > 0) "${device.totalRamMb}MB" else "unknown"} · " +
                "Android API ${device.sdkInt} · Polling floor: ${device.pollingFloorMs}ms",
                color = Text2, fontSize = 10.sp, modifier = Modifier.padding(top = 2.dp)
            )
            Text(
                "This is the real detected profile for this specific device — modes below are clamped to it automatically, " +
                "so a budget device never gets forced into a polling rate it can't sustain.",
                color = Text2, fontSize = 9.5.sp, lineHeight = 13.sp, modifier = Modifier.padding(top = 6.dp)
            )
            Text(
                "XBoost is built to run from ~1GB RAM budget phones up through 12GB+ flagships — the same app, " +
                "just with polling speed, animation detail, and floating-bubble icon count auto-scaled to what your device can spare.",
                color = XCyan, fontSize = 9.5.sp, lineHeight = 13.sp, modifier = Modifier.padding(top = 6.dp)
            )
        }

        Spacer(Modifier.height(24.dp))
        Text("PERFORMANCE MODULE", color = Text1, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Spacer(Modifier.height(10.dp))
        Column(
            modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).border(1.dp, Line, RoundedCornerShape(14.dp)).padding(16.dp)
        ) {
            listOf(BoostMode.PERFORMANCE, BoostMode.BALANCE, BoostMode.BATTERY_SAVE).forEach { mode ->
                val p = PerformanceModuleManager.profileFor(mode)
                val effectiveMs = PerformanceModuleManager.effectivePollingMs(context, mode)
                Text(p.label, color = Text0, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                Text(
                    "Timeout: ${p.screenTimeoutSeconds?.let { "${it}s" } ?: "default"} · " +
                    "Monitor: every ${effectiveMs}ms${if (effectiveMs != p.pollingIntervalMs) " (adjusted for this device)" else ""} · Trim: ${if (p.trimBackground) "on" else "off"} · " +
                    "DND: ${if (p.autoGameDndDefault) "on" else "off"} · Screen Awake: ${if (p.keepScreenOnDefault) "on" else "off"} · Brightness: not touched",
                    color = Text2, fontSize = 10.sp, modifier = Modifier.padding(top = 2.dp, bottom = 10.dp)
                )
            }
        }

        Spacer(Modifier.height(24.dp))
        Text("ACCENT COLOR", color = Text1, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            AccentSwatch(AccentColor.RED, Color(0xFFFF2B45), accent) { scope.launch { PreferencesManager.setAccentColor(context, it) } }
            AccentSwatch(AccentColor.CYAN, Color(0xFF26F0D0), accent) { scope.launch { PreferencesManager.setAccentColor(context, it) } }
            AccentSwatch(AccentColor.PURPLE, Color(0xFFB463FF), accent) { scope.launch { PreferencesManager.setAccentColor(context, it) } }
            AccentSwatch(AccentColor.GREEN, Color(0xFF3DFFA0), accent) { scope.launch { PreferencesManager.setAccentColor(context, it) } }
        }
        Text(
            "Applies to the Boost dial and headers now; full-app recolor is on the roadmap.",
            color = Text2, fontSize = 10.sp, modifier = Modifier.padding(top = 8.dp)
        )

        Spacer(Modifier.height(24.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Panel, RoundedCornerShape(14.dp))
                .border(1.dp, XRed.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                .clickable { onOpenSupport() }
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Icon(Icons.Filled.Favorite, contentDescription = null, tint = XRed, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Support Developer", color = Text0, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text("Donate, rate, share, or send feedback", color = Text2, fontSize = 10.sp)
                }
            }
            Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = Text2)
        }

        Spacer(Modifier.height(24.dp))
        Text("ABOUT", color = Text1, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Spacer(Modifier.height(10.dp))
        Column(
            modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).border(1.dp, Line, RoundedCornerShape(14.dp)).padding(16.dp)
        ) {
            Text("XBoost", color = Text0, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text("v1.2.0", color = Text2, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp))
            Spacer(Modifier.height(10.dp))
            Text(
                "Every stat and action in this app reflects real device state. No overclocking, " +
                "no fake RAM-freeing, no placebo numbers.",
                color = Text2, fontSize = 11.sp, lineHeight = 16.sp
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun Modifier.verticalScrollFix(): Modifier {
    val scrollState = rememberScrollState()
    return this.verticalScroll(scrollState)
}

@Composable
private fun AccentSwatch(value: AccentColor, color: Color, current: AccentColor, onSelect: (AccentColor) -> Unit) {
    val selected = current == value
    Box(
        modifier = Modifier
            .size(40.dp)
            .background(color, CircleShape)
            .border(if (selected) 3.dp else 0.dp, Color.White, CircleShape)
            .clickable { onSelect(value) }
    )
}

@Composable
private fun SettingsRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    granted: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Panel, RoundedCornerShape(14.dp))
            .border(1.dp, if (granted) XCyan.copy(alpha = 0.4f) else Line, RoundedCornerShape(14.dp))
            .clickable(enabled = !granted) { onClick() }
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = if (granted) XCyan else Text1, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = Text0, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Text(subtitle, color = if (granted) XCyan else Text2, fontSize = 10.sp)
        }
        if (!granted) {
            Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = Text2)
        }
    }
}
