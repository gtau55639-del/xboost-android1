package com.xboost.app.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import kotlin.math.min

/**
 * Small circular arc gauge used by the redesigned Quick Panel to show live
 * device stats (temperature / RAM / CPU) the way RedMagic's Game Space
 * dashboard does — a ring that fills proportionally to a real 0-100 value,
 * with the number printed in the middle. Pure canvas drawing, no extra
 * libraries, cheap enough to redraw every tick on a LOW-tier device.
 *
 * `percent` drives the fill. `unknown` (used when SystemMonitor can't read a
 * value on a locked-down OEM build) draws a flat dim ring + "—" instead of
 * faking a number — same honesty rule as the rest of the codebase.
 */
class RingGaugeView(context: Context) : View(context) {

    var percent: Int = 0
        set(value) { field = value.coerceIn(0, 100); invalidate() }

    var unknown: Boolean = false
        set(value) { field = value; invalidate() }

    var ringColor: Int = Color.parseColor("#FF6A2E")
        set(value) { field = value; invalidate() }

    var centerText: String = ""
        set(value) { field = value; invalidate() }

    private val density = context.resources.displayMetrics.density
    private val strokeWidth = 3.2f * density

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = this@RingGaugeView.strokeWidth
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#2C2732")
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = this@RingGaugeView.strokeWidth
        strokeCap = Paint.Cap.ROUND
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    private val rect = RectF()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val size = min(width, height).toFloat()
        val pad = strokeWidth
        rect.set(pad, pad, size - pad, size - pad)

        canvas.drawArc(rect, -90f, 360f, false, trackPaint)

        if (!unknown) {
            fillPaint.color = ringColor
            val sweep = 360f * (percent / 100f)
            canvas.drawArc(rect, -90f, sweep, false, fillPaint)
        }

        textPaint.textSize = size * 0.24f
        val label = if (unknown) "—" else centerText
        val fm = textPaint.fontMetrics
        val ty = size / 2f - (fm.ascent + fm.descent) / 2f
        canvas.drawText(label, size / 2f, ty, textPaint)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val target = (46 * density).toInt()
        setMeasuredDimension(target, target)
    }
}
