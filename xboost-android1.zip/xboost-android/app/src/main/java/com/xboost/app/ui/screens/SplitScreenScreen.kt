package com.xboost.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.xboost.app.core.PermissionManager
import com.xboost.app.core.PreferencesManager
import com.xboost.app.core.SplitScreenManager
import com.xboost.app.ui.theme.*
import kotlinx.coroutines.launch

/**
 * Two things live here, both real, both wired to what Android actually
 * allows a non-root app to do:
 *
 * 1. Split Screen pair — pick App A / App B, one tap opens App A then App B
 *    "adjacent" (see SplitScreenManager for why this only lands in a real
 *    split view once you're already in multi-window — Android's rule, not
 *    a limitation XBoost invented).
 * 2. Floating favorites — up to 4 apps shown as quick-launch icons inside
 *    the swipe-out floating panel, so a "floating, hovering" launcher for your
 *    split pair (or any app) is one swipe away over a game, no need to
 *    back out to the home screen first.
 */
@Composable
fun SplitScreenScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val splitOn by PreferencesManager.splitScreenOn(context).collectAsState(initial = false)
    val splitAppsState by PreferencesManager.splitApps(context).collectAsState(initial = null to null)
    val (appA, appB) = splitAppsState
    val favorites by PreferencesManager.floatingFavorites(context).collectAsState(initial = emptySet())
    var overlayGranted by remember { mutableStateOf(PermissionManager.hasOverlayPermission(context)) }
    var pickingFor by remember { mutableStateOf<PickTarget?>(null) }

    val installedApps = remember {
        context.packageManager.getInstalledApplications(0)
            .filter { it.packageName != context.packageName && (it.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) == 0 }
            .sortedBy { context.packageManager.getApplicationLabel(it).toString() }
            .take(80)
    }

    Column(modifier = Modifier.fillMaxSize().background(Bg0).padding(horizontal = 20.dp, vertical = 24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Text1, modifier = Modifier.clickable {
                if (pickingFor != null) pickingFor = null else onBack()
            })
            Spacer(Modifier.width(10.dp))
            Text(
                if (pickingFor != null) "CHOOSE APP" else "SPLIT SCREEN & FLOATING APPS",
                color = Text0, fontWeight = FontWeight.Bold, fontSize = 17.sp
            )
        }

        if (pickingFor != null) {
            Spacer(Modifier.height(16.dp))
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(installedApps) { app ->
                    val pkg = app.packageName
                    val label = context.packageManager.getApplicationLabel(app).toString()
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                scope.launch {
                                    when (val target = pickingFor) {
                                        PickTarget.A -> PreferencesManager.setSplitAppA(context, pkg)
                                        PickTarget.B -> PreferencesManager.setSplitAppB(context, pkg)
                                        PickTarget.FAVORITE -> PreferencesManager.setFloatingFavorite(context, pkg, true)
                                        null -> {}
                                    }
                                }
                                pickingFor = null
                            }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Apps, contentDescription = null, tint = Text2, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(10.dp))
                        Text(label, color = Text0, fontSize = 13.sp)
                    }
                }
            }
            return@Column
        }

        Text(
            "Real capabilities only: XBoost can't force a phone into split view — no non-root app can, that's an Android platform rule. What it does do below is real.",
            color = Text2, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp, bottom = 18.dp), lineHeight = 15.sp
        )

        // ---- Split pair picker ----
        Column(
            modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).border(1.dp, Line, RoundedCornerShape(14.dp)).padding(14.dp)
        ) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.VerticalSplit, contentDescription = null, tint = if (splitOn) XCyan else Text1, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("Split Screen Pair", color = Text0, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        Text("2 apps, 1 tap to open both", color = Text2, fontSize = 10.sp)
                    }
                }
                Switch(
                    checked = splitOn,
                    onCheckedChange = { on -> scope.launch { PreferencesManager.setSplitScreenOn(context, on) } },
                    colors = SwitchDefaults.colors(checkedThumbColor = XCyan, checkedTrackColor = XCyanDim)
                )
            }

            Spacer(Modifier.height(12.dp))
            AppSlot(label = "App A", pkg = appA, context = context, accent = XRed) { pickingFor = PickTarget.A }
            Spacer(Modifier.height(8.dp))
            AppSlot(label = "App B (opens adjacent)", pkg = appB, context = context, accent = XCyan) { pickingFor = PickTarget.B }

            Spacer(Modifier.height(12.dp))
            Button(
                enabled = appA != null && appB != null,
                onClick = { SplitScreenManager.launchPair(context, appA!!, appB!!) },
                colors = ButtonDefaults.buttonColors(containerColor = XRed),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Launch Split", fontSize = 12.sp) }

            Spacer(Modifier.height(8.dp))
            Text(
                "First time: open Recents, long-press either app's icon, tap \"Split screen\" once to enter multi-window. " +
                    "After that, Launch Split correctly opens App B into the second pane instead of covering App A.",
                color = Text2, fontSize = 9.5.sp, lineHeight = 13.sp
            )
        }

        Spacer(Modifier.height(14.dp))

        // ---- Floating favorites ----
        Column(
            modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).border(1.dp, Line, RoundedCornerShape(14.dp)).padding(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.PictureInPictureAlt, contentDescription = null, tint = if (favorites.isNotEmpty()) XCyan else Text1, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("Floating Panel Favorites", color = Text0, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Text("Up to ${PreferencesManager.FLOATING_FAVORITES_MAX} apps launchable from the floating panel", color = Text2, fontSize = 10.sp)
                }
            }
            if (!overlayGranted) {
                Spacer(Modifier.height(10.dp))
                Text("Grant \"Display over other apps\" first (Modules screen) so the panel can appear.", color = XAmber, fontSize = 10.sp)
            }
            Spacer(Modifier.height(10.dp))
            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                favorites.forEach { pkg ->
                    FavoriteChip(label = SplitScreenManager.label(context, pkg)) {
                        scope.launch { PreferencesManager.setFloatingFavorite(context, pkg, false) }
                    }
                }
                if (favorites.size < PreferencesManager.FLOATING_FAVORITES_MAX) {
                    Box(
                        modifier = Modifier
                            .background(Bg1, RoundedCornerShape(10.dp))
                            .border(1.dp, Line, RoundedCornerShape(10.dp))
                            .clickable { pickingFor = PickTarget.FAVORITE }
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = "Add favorite", tint = XCyan, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }

        Spacer(Modifier.height(24.dp))
    }
}

private enum class PickTarget { A, B, FAVORITE }

@Composable
private fun AppSlot(label: String, pkg: String?, context: android.content.Context, accent: androidx.compose.ui.graphics.Color, onPick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Bg1, RoundedCornerShape(10.dp))
            .clickable { onPick() }
            .padding(10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(label, color = Text2, fontSize = 9.5.sp)
            Text(
                pkg?.let { SplitScreenManager.label(context, it) } ?: "Tap to choose",
                color = if (pkg != null) accent else Text1, fontSize = 12.sp, fontWeight = FontWeight.Medium
            )
        }
        Icon(Icons.Filled.ChevronRight, contentDescription = null, tint = Text2)
    }
}

@Composable
private fun FavoriteChip(label: String, onRemove: () -> Unit) {
    Row(
        modifier = Modifier
            .background(Bg1, RoundedCornerShape(10.dp))
            .border(1.dp, XCyanDim, RoundedCornerShape(10.dp))
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label.take(10), color = Text0, fontSize = 11.sp)
        Spacer(Modifier.width(6.dp))
        Icon(
            Icons.Filled.Close, contentDescription = "Remove", tint = Text2,
            modifier = Modifier.size(12.dp).clickable { onRemove() }
        )
    }
}
