package com.xboost.app.ui.screens

import android.app.Activity
import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.xboost.app.core.*
import com.xboost.app.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

data class LiveStats(
    val ramPercent: Int,
    val ramUsedMb: Long,
    val ramTotalMb: Long,
    val cpuPercent: Int?,
    val pingMs: Long?,
    val tempCelsius: Float?,
    val thermalLevel: ThermalLevel = ThermalLevel.COOL
)

private data class QuickFn(
    val id: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val label: String
)

// Only functions with a real, verifiable effect behind them.
private val QUICK_FUNCTIONS = listOf(
    QuickFn("clear_cache", Icons.Filled.CleaningServices, "Clear Cache"),
    QuickFn("game_dnd", Icons.Filled.DoNotDisturbOn, "Game DND"),
    QuickFn("keep_screen_on", Icons.Filled.Visibility, "Screen Awake"),
    QuickFn("ping_check", Icons.Filled.NetworkCheck, "Ping Check"),
    QuickFn("power_saver", Icons.Filled.BatterySaver, "Power Saver"),
    QuickFn("auto_game_mode", Icons.Filled.AutoAwesome, "Auto Game Mode"),
)

@Composable
fun BoostScreen() {
    val context = LocalContext.current
    val activity = context as? Activity
    val scope = rememberCoroutineScope()
    val lifecycleOwner = LocalLifecycleOwner.current

    var stats by remember { mutableStateOf(LiveStats(0, 0, 0, null, null, null)) }
    var boosted by remember { mutableStateOf(false) }
    var boostMessage by remember { mutableStateOf("") }
    var appInForeground by remember { mutableStateOf(true) }
    var autoGameToast by remember { mutableStateOf<String?>(null) }

    var usageGranted by remember { mutableStateOf(PermissionManager.hasUsageAccess(context)) }
    var notifGranted by remember { mutableStateOf(PermissionManager.hasNotificationAccess(context)) }
    var writeSettingsGranted by remember { mutableStateOf(PermissionManager.hasWriteSettings(context)) }

    val savedMode by PreferencesManager.mode(context).collectAsState(initial = BoostMode.BALANCE)
    val enabledFns by PreferencesManager.enabledFunctions(context)
        .collectAsState(initial = setOf("clear_cache", "game_dnd"))
    val autoGameMode by PreferencesManager.autoGameMode(context).collectAsState(initial = false)
    val profileDndPkgs by PreferencesManager.profileDndPackages(context).collectAsState(initial = emptySet())
    val profileScreenPkgs by PreferencesManager.profileScreenPackages(context).collectAsState(initial = emptySet())

    // Track real foreground/background so the hex ring animation actually stops spending
    // battery when the app isn't visible, instead of running invisibly forever.
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> {
                    appInForeground = true
                    usageGranted = PermissionManager.hasUsageAccess(context)
                    notifGranted = PermissionManager.hasNotificationAccess(context)
                    writeSettingsGranted = PermissionManager.hasWriteSettings(context)
                }
                Lifecycle.Event.ON_PAUSE -> appInForeground = false
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Real-time polling loop — reads actual device stats, at a rate that
    // itself differs per mode (Performance polls faster/more responsive,
    // Battery Save polls slower to reduce this app's own wake-ups).
    LaunchedEffect(savedMode) {
        while (true) {
            if (appInForeground) {
                val ram = SystemMonitor.getRamInfo(context)
                val cpu = SystemMonitor.cpuUsagePercent()
                val ping = SystemMonitor.pingMs()
                val temp = ThermalGuardManager.currentBatteryTempCelsius(context)
                stats = LiveStats(ram.percentUsed, ram.usedMb, ram.totalMb, cpu, ping, temp, ThermalGuardManager.levelFor(temp))

                // GameWatcherService (started from the Auto Game Mode switch) is the
                // real detector — it runs independently of whether XBoost's own
                // screen is open, which is what actually matters since a game
                // being foreground means XBoost is NOT what you're looking at.
                // This in-app check only catches the split-second transition
                // right as you switch away, so Screen Awake (window-bound, can't
                // follow you into another app) at least applies for that instant.
                if (autoGameMode) {
                    val fg = BoosterEngine.currentForegroundApp(context)
                    if (fg != null && BoosterEngine.KNOWN_GAMES.containsKey(fg)) {
                        val gameName = BoosterEngine.KNOWN_GAMES[fg]
                        if (profileDndPkgs.contains(fg)) BoosterEngine.setGameDnd(context, true)
                        if (profileScreenPkgs.contains(fg)) activity?.window?.let { BoosterEngine.setKeepScreenOn(it, true) }
                        if (profileDndPkgs.contains(fg) || profileScreenPkgs.contains(fg)) {
                            autoGameToast = "Auto Game Mode: profile applied for $gameName"
                        }
                    }
                }
            }
            delay(PerformanceModuleManager.effectivePollingMs(context, savedMode))
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(GradientBgTop, BgDeep, GradientBgBottom)))
    ) {
        // Soft ambient glow blobs — cheap radial gradients, no RenderEffect/blur
        // needed, so this stays safe on API 24+ and on LOW-tier devices (a single
        // static Brush costs nothing extra per frame, unlike a Canvas redraw).
        Box(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .size(260.dp)
                .offset(x = 60.dp, y = (-60).dp)
                .background(
                    Brush.radialGradient(listOf(LocalAccent.current.primary.copy(alpha = 0.16f), Color.Transparent))
                )
        )
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .size(220.dp)
                .offset(x = (-50).dp, y = 50.dp)
                .background(
                    Brush.radialGradient(listOf(LocalAccent.current.secondary.copy(alpha = 0.12f), Color.Transparent))
                )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScrollFix()
                .padding(horizontal = 16.dp)
        ) {
            Spacer(Modifier.height(14.dp))
            HeaderRow()
            Spacer(Modifier.height(10.dp))
            StatusStrip(boosted = boosted, mode = savedMode, thermalLevel = stats.thermalLevel)
            Spacer(Modifier.height(12.dp))

            AnimatedVisibility(visible = !usageGranted || !notifGranted || !writeSettingsGranted) {
                PermissionCard(
                    usageGranted = usageGranted,
                    notifGranted = notifGranted,
                    writeSettingsGranted = writeSettingsGranted,
                    onGrantUsage = { PermissionManager.openUsageAccessSettings(context) },
                    onGrantNotif = { PermissionManager.openNotificationAccessSettings(context) },
                    onGrantWriteSettings = { PermissionManager.openWriteSettings(context) }
                )
            }

            // Landscape 2-column layout: left = the boost dial + mode switcher
            // (the part you glance at), right = live numbers + quick toggles
            // (the part you scan). Avoids one long vertical scroll on a screen
            // that's wide but short.
            Row(modifier = Modifier.fillMaxWidth()) {
                Column(
                    modifier = Modifier.weight(1f).padding(end = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    GlassPanel {
                        HexBoostButton(
                            active = boosted,
                            spinning = appInForeground,
                            onToggle = {
                                boosted = !boosted
                                if (boosted) {
                                    val result = BoosterEngine.runFullBoost(context, dnd = enabledFns.contains("game_dnd"))
                                    boostMessage = result.message
                                } else {
                                    if (enabledFns.contains("game_dnd")) BoosterEngine.setGameDnd(context, false)
                                    boostMessage = ""
                                }
                            }
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = if (boosted) "STATUS: BOOSTED" else "STATUS: STANDBY",
                            color = if (boosted) XCyan else Text1,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp
                        )
                        if (boostMessage.isNotBlank()) {
                            Text(
                                text = boostMessage, color = Text2, fontSize = 10.sp, textAlign = TextAlign.Center,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                        autoGameToast?.let {
                            Text(it, color = XAmber, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 2.dp))
                        }
                    }

                    Spacer(Modifier.height(14.dp))
                    SectionLabel("PERFORMANCE MODULE")
                    Spacer(Modifier.height(8.dp))
                    ModeRow(current = savedMode) { mode ->
                        scope.launch {
                            PreferencesManager.setMode(context, mode)
                            val result = PerformanceModuleManager.applyProfile(context, mode)
                            PreferencesManager.toggleFunction(context, "game_dnd", result.profile.autoGameDndDefault)
                            PreferencesManager.toggleFunction(context, "keep_screen_on", result.profile.keepScreenOnDefault)
                            activity?.window?.let { BoosterEngine.setKeepScreenOn(it, result.profile.keepScreenOnDefault) }
                            boostMessage = result.summary
                        }
                    }
                }

                Column(modifier = Modifier.weight(1f).padding(start = 10.dp)) {
                    SectionLabel("SYSTEM MONITOR — LIVE")
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        GaugeCard(
                            Modifier.weight(1f), "RAM", stats.ramPercent, XRed, "${stats.ramUsedMb}/${stats.ramTotalMb}MB",
                            icon = Icons.Filled.Memory
                        )
                        GaugeCard(
                            Modifier.weight(1f), "CPU", stats.cpuPercent ?: 0, XCyan, stats.cpuPercent?.let { "$it% load" } ?: "N/A",
                            icon = Icons.Filled.Speed
                        )
                        GaugeCard(
                            Modifier.weight(1f), "PING",
                            stats.pingMs?.let { min(100, (it / 2).toInt()) } ?: 0,
                            XAmber, stats.pingMs?.let { "${it}ms" } ?: "No signal",
                            icon = Icons.Filled.NetworkCheck
                        )
                        val tempColor = when (stats.thermalLevel) {
                            ThermalLevel.HOT -> XRed
                            ThermalLevel.WARM -> XAmber
                            ThermalLevel.COOL -> XCyan
                        }
                        GaugeCard(
                            Modifier.weight(1f), "TEMP",
                            stats.tempCelsius?.let { min(100, ((it - 20f) / 0.35f).toInt().coerceIn(0, 100)) } ?: 0,
                            tempColor,
                            stats.tempCelsius?.let { "%.1f°C".format(it) } ?: "N/A",
                            icon = Icons.Filled.Thermostat
                        )
                    }

                    Spacer(Modifier.height(16.dp))
                    SectionLabel("QUICK FUNCTIONS")
                    Spacer(Modifier.height(8.dp))
                    FunctionGrid(
                        enabled = enabledFns,
                        onToggle = { fn, isOn ->
                            scope.launch { PreferencesManager.toggleFunction(context, fn.id, isOn) }
                            when (fn.id) {
                                "keep_screen_on" -> activity?.window?.let { BoosterEngine.setKeepScreenOn(it, isOn) }
                                "game_dnd" -> BoosterEngine.setGameDnd(context, isOn)
                                "auto_game_mode" -> {
                                    scope.launch { PreferencesManager.setAutoGameMode(context, isOn) }
                                    val watcherIntent = Intent(context, com.xboost.app.overlay.GameWatcherService::class.java)
                                    if (isOn) context.startForegroundService(watcherIntent) else context.stopService(watcherIntent)
                                }
                                "clear_cache" -> if (isOn) BoosterEngine.trimBackgroundProcesses(context)
                            }
                        },
                        onPingCheckTap = {
                            scope.launch {
                                val ms = SystemMonitor.pingMs()
                                boostMessage = ms?.let { "Ping: $it ms to 8.8.8.8" } ?: "No network reachable"
                            }
                        },
                        onPowerSaverTap = {
                            boostMessage = if (BoosterEngine.isPowerSaveMode(context)) "Battery Saver is ON" else "Battery Saver is OFF — tap to open settings"
                            if (!BoosterEngine.isPowerSaveMode(context)) PermissionManager.openBatterySettings(context)
                        }
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}

// Compose's Modifier.verticalScroll needs the foundation import; kept as a tiny
// helper so this file stays self-contained without extra top-level imports drift.
@Composable
private fun Modifier.verticalScrollFix(): Modifier {
    val scrollState = rememberScrollState()
    return this.verticalScroll(scrollState)
}

/**
 * A frosted/"glass" wrapper used around the hero boost dial — a translucent
 * panel with a soft gradient border, the kind of treatment most mainstream
 * game-booster apps (Game Space, GFX Tool-style dashboards) use for their
 * primary action card instead of a flat rectangle.
 */
@Composable
private fun GlassPanel(content: @Composable ColumnScope.() -> Unit) {
    val accent = LocalAccent.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(listOf(PanelGlassHi, PanelGlass)),
                RoundedCornerShape(20.dp)
            )
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(listOf(accent.primary.copy(alpha = 0.35f), LineSoft)),
                shape = RoundedCornerShape(20.dp)
            )
            .padding(vertical = 16.dp, horizontal = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        content = content
    )
}

/** Slim status strip up top, the "at a glance" summary common to game boosters. */
@Composable
private fun StatusStrip(boosted: Boolean, mode: BoostMode, thermalLevel: ThermalLevel) {
    val modeLabel = when (mode) {
        BoostMode.BALANCE -> "Balance"
        BoostMode.PERFORMANCE -> "Performance"
        BoostMode.BATTERY_SAVE -> "Battery Save"
    }
    val thermalColor = when (thermalLevel) {
        ThermalLevel.HOT -> XRed
        ThermalLevel.WARM -> XAmber
        ThermalLevel.COOL -> XGreen
    }
    val thermalLabel = when (thermalLevel) {
        ThermalLevel.HOT -> "Hot"
        ThermalLevel.WARM -> "Warm"
        ThermalLevel.COOL -> "Cool"
    }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(PanelGlass, RoundedCornerShape(14.dp))
            .border(1.dp, LineSoft, RoundedCornerShape(14.dp))
            .padding(horizontal = 12.dp, vertical = 9.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        StatusPill(
            dotColor = if (boosted) XGreen else Text2,
            label = if (boosted) "Engine: Active" else "Engine: Standby"
        )
        StatusPill(dotColor = LocalAccent.current.primary, label = "Mode: $modeLabel")
        StatusPill(dotColor = thermalColor, label = "Thermal: $thermalLabel")
        DeviceTierBadge()
    }
}

@Composable
private fun StatusPill(dotColor: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(dotColor)
        )
        Spacer(Modifier.width(6.dp))
        Text(label, color = Text1, fontSize = 10.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun DeviceTierBadge() {
    val profile = LocalDeviceProfile.current
    val (label, color) = when (profile.tier) {
        DeviceTier.LOW -> "LOW" to XAmber
        DeviceTier.MID -> "MID" to XCyan
        DeviceTier.HIGH -> "HIGH" to XGreen
    }
    Box(
        modifier = Modifier
            .background(color.copy(alpha = 0.16f), RoundedCornerShape(8.dp))
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(label, color = color, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
    }
}

@Composable
private fun PermissionCard(
    usageGranted: Boolean,
    notifGranted: Boolean,
    writeSettingsGranted: Boolean,
    onGrantUsage: () -> Unit,
    onGrantNotif: () -> Unit,
    onGrantWriteSettings: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp)
            .background(PanelGlass, RoundedCornerShape(16.dp))
            .border(1.dp, XAmber.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(22.dp)
                    .clip(CircleShape)
                    .background(XAmber.copy(alpha = 0.18f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Filled.Info, contentDescription = null, tint = XAmber, modifier = Modifier.size(13.dp))
            }
            Spacer(Modifier.width(8.dp))
            Text("Setup needed for full features", color = Text0, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
        }
        Spacer(Modifier.height(10.dp))
        if (!usageGranted) {
            PermissionRow("Usage Access", "Needed to detect which game is running", onGrantUsage)
            Spacer(Modifier.height(8.dp))
        }
        if (!notifGranted) {
            PermissionRow("Notification Access", "Needed for Game DND", onGrantNotif)
            Spacer(Modifier.height(8.dp))
        }
        if (!writeSettingsGranted) {
            PermissionRow("Modify System Settings", "Needed for the Performance Module (screen timeout per mode)", onGrantWriteSettings)
        }
    }
}

@Composable
private fun PermissionRow(title: String, desc: String, onGrant: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = Text0, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Text(desc, color = Text2, fontSize = 10.sp)
        }
        Spacer(Modifier.width(8.dp))
        Button(
            onClick = onGrant,
            colors = ButtonDefaults.buttonColors(containerColor = XRed),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            shape = RoundedCornerShape(10.dp)
        ) {
            Text("Grant", fontSize = 11.sp)
        }
    }
}

@Composable
private fun HeaderRow() {
    val accent = LocalAccent.current
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(GenericShape { size, _ ->
                        moveTo(size.width * 0.3f, 0f)
                        lineTo(size.width, 0f)
                        lineTo(size.width * 0.7f, size.height)
                        lineTo(0f, size.height)
                        close()
                    })
                    .background(Brush.linearGradient(listOf(accent.primary, Color(0xFFA30017)))),
                contentAlignment = Alignment.Center
            ) {
                Text("X", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
            Spacer(Modifier.width(10.dp))
            Text("X", color = Text0, fontWeight = FontWeight.Bold, fontSize = 19.sp)
            Text("BOOST", color = accent.primary, fontWeight = FontWeight.Bold, fontSize = 19.sp)
        }
        Icon(
            Icons.Filled.SportsEsports,
            contentDescription = null,
            tint = accent.primary.copy(alpha = 0.7f),
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
private fun SectionLabel(text: String) {
    val accent = LocalAccent.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(3.dp, 14.dp)
                .background(Brush.verticalGradient(listOf(accent.primary, accent.secondary)))
        )
        Spacer(Modifier.width(8.dp))
        Text(text, color = Text1, fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.5.sp)
    }
}

@Composable
private fun ModeRow(current: BoostMode, onSelect: (BoostMode) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(PanelGlass, RoundedCornerShape(12.dp))
            .border(1.dp, LineSoft, RoundedCornerShape(12.dp))
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        ModeChip("BALANCE", Icons.Filled.Tune, current == BoostMode.BALANCE, Modifier.weight(1f)) { onSelect(BoostMode.BALANCE) }
        ModeChip("PERFORMANCE", Icons.Filled.RocketLaunch, current == BoostMode.PERFORMANCE, Modifier.weight(1f)) { onSelect(BoostMode.PERFORMANCE) }
        ModeChip("BATTERY", Icons.Filled.BatteryChargingFull, current == BoostMode.BATTERY_SAVE, Modifier.weight(1f)) { onSelect(BoostMode.BATTERY_SAVE) }
    }
}

@Composable
private fun ModeChip(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    on: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val accent = LocalAccent.current
    Column(
        modifier = modifier
            .background(
                if (on) Brush.verticalGradient(listOf(accent.primary.copy(alpha = 0.28f), accent.primary.copy(alpha = 0.08f)))
                else Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent)),
                RoundedCornerShape(9.dp)
            )
            .border(1.dp, if (on) accent.primary else Color.Transparent, RoundedCornerShape(9.dp))
            .clickable { onClick() }
            .padding(vertical = 9.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = label, tint = if (on) accent.primary else Text2, modifier = Modifier.size(14.dp))
        Spacer(Modifier.height(3.dp))
        Text(label, color = if (on) Text0 else Text1, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.3.sp)
    }
}

@Composable
private fun HexBoostButton(active: Boolean, spinning: Boolean, onToggle: () -> Unit) {
    val accent = LocalAccent.current
    val deviceProfile = LocalDeviceProfile.current
    // On a 1-3GB budget device, a continuous per-frame Canvas rotation is a
    // real (if small) chunk of the CPU/battery budget being spent on chrome
    // instead of the game XBoost is boosting. Slower tween + dropping the
    // second counter-rotating ring roughly halves the redraw work per frame
    // on LOW tier; MID/HIGH devices (up to 12GB+) keep the full effect.
    val lowEnd = deviceProfile.tier == com.xboost.app.core.DeviceTier.LOW
    val ringDurationMs = if (lowEnd) 11000 else 6000
    val infinite = rememberInfiniteTransition(label = "ring")
    // Target equals initial (0f) when not spinning, so the ring genuinely
    // stops consuming animation frames while the app is backgrounded.
    val rotation by infinite.animateFloat(
        initialValue = 0f,
        targetValue = if (spinning) 360f else 0f,
        animationSpec = infiniteRepeatable(tween(ringDurationMs, easing = LinearEasing)),
        label = "rot"
    )
    // Gentle breathing pulse on the outer glow when active — cheap (single
    // float animation, no extra Canvas passes) but reads as "alive" the way
    // stock OEM game-boost dashboards do.
    val pulse by infinite.animateFloat(
        initialValue = 0.85f,
        targetValue = if (active) 1.08f else 0.85f,
        animationSpec = infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    val glow by animateFloatAsState(if (active) 1f else 0f, tween(300), label = "glow")

    Box(modifier = Modifier.fillMaxWidth().height(196.dp), contentAlignment = Alignment.Center) {
        // Outer ambient glow — only when boosted, skipped visually (alpha 0) otherwise.
        Box(
            modifier = Modifier
                .size(190.dp)
                .graphicsLayer { scaleX = pulse; scaleY = pulse }
                .background(
                    Brush.radialGradient(
                        listOf(accent.secondary.copy(alpha = 0.22f * glow), Color.Transparent)
                    )
                )
        )

        Canvas(modifier = Modifier.size(168.dp)) {
            val center = Rect(Offset.Zero, size).center
            rotate(rotation, pivot = center) {
                drawPath(
                    path = hexagonPath(center, size.minDimension / 2.1f),
                    color = accent.primary.copy(alpha = 0.55f + 0.35f * glow),
                    style = Stroke(width = 3.dp.toPx())
                )
            }
            if (!lowEnd) {
                rotate(-rotation * 0.8f, pivot = center) {
                    drawPath(
                        path = hexagonPath(center, size.minDimension / 2.6f),
                        color = accent.secondary.copy(alpha = 0.35f + 0.25f * glow),
                        style = Stroke(width = 2.dp.toPx())
                    )
                }
                // Third, tighter ring only on non-budget devices — extra visual
                // polish without touching the LOW-tier draw budget at all.
                drawPath(
                    path = hexagonPath(center, size.minDimension / 3.2f),
                    color = accent.primary.copy(alpha = 0.18f + 0.18f * glow),
                    style = Stroke(width = 1.dp.toPx())
                )
            }
        }

        Box(
            modifier = Modifier
                .size(124.dp)
                .clip(hexagonShape())
                .background(
                    Brush.linearGradient(
                        if (active) listOf(Color(0xFF23131A), Color(0xFF0A0A10))
                        else listOf(Color(0xFF191A24), Color(0xFF0A0A10))
                    )
                )
                .border(
                    width = 1.dp,
                    brush = Brush.linearGradient(listOf(accent.primary.copy(alpha = 0.5f), Color.Transparent)),
                    shape = hexagonShape()
                )
                .clickable { onToggle() },
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = if (active) Icons.Filled.RocketLaunch else Icons.Filled.Bolt,
                    contentDescription = null,
                    tint = if (active) accent.secondary else accent.primary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(Modifier.height(4.dp))
                Text(if (active) "ACTIVE" else "BOOST", color = Text0, fontWeight = FontWeight.Bold, fontSize = 14.sp, letterSpacing = 1.sp)
                Text(if (active) "BOOSTED" else "TAP TO START", color = Text1, fontSize = 8.sp, letterSpacing = 0.5.sp)
            }
        }
    }
}

private fun hexagonPath(center: Offset, radius: Float): Path {
    val path = Path()
    for (i in 0..5) {
        val angle = Math.toRadians((60 * i - 90).toDouble())
        val x = center.x + radius * cos(angle).toFloat()
        val y = center.y + radius * sin(angle).toFloat()
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    return path
}

private fun hexagonShape() = GenericShape { size, _ ->
    val center = Offset(size.width / 2f, size.height / 2f)
    val radius = size.minDimension / 2f
    for (i in 0..5) {
        val angle = Math.toRadians((60 * i - 90).toDouble())
        val x = center.x + radius * cos(angle).toFloat()
        val y = center.y + radius * sin(angle).toFloat()
        if (i == 0) moveTo(x, y) else lineTo(x, y)
    }
    close()
}

@Composable
fun GaugeCard(
    modifier: Modifier = Modifier,
    label: String,
    percent: Int,
    color: Color,
    sub: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector? = null
) {
    Column(
        modifier = modifier
            .background(
                Brush.verticalGradient(listOf(PanelGlassHi, PanelGlass)),
                RoundedCornerShape(14.dp)
            )
            .border(1.dp, color.copy(alpha = 0.28f), RoundedCornerShape(14.dp))
            .padding(vertical = 12.dp, horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(modifier = Modifier.size(52.dp), contentAlignment = Alignment.Center) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val stroke = 5.dp.toPx()
                drawArc(color = Line, startAngle = -90f, sweepAngle = 360f, useCenter = false, style = Stroke(stroke, cap = StrokeCap.Round))
                drawArc(
                    brush = Brush.sweepGradient(listOf(color.copy(alpha = 0.4f), color)),
                    startAngle = -90f,
                    sweepAngle = 3.6f * percent.coerceIn(0, 100),
                    useCenter = false,
                    style = Stroke(stroke, cap = StrokeCap.Round)
                )
            }
            if (icon != null) {
                Icon(icon, contentDescription = null, tint = color.copy(alpha = 0.85f), modifier = Modifier.size(14.dp).align(Alignment.TopEnd))
            }
            Text("$percent%", color = Text0, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
        Spacer(Modifier.height(6.dp))
        Text(label, color = Text1, fontSize = 10.sp, letterSpacing = 1.sp)
        Text(sub, color = Text2, fontSize = 9.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun FunctionGrid(
    enabled: Set<String>,
    onToggle: (QuickFn, Boolean) -> Unit,
    onPingCheckTap: () -> Unit,
    onPowerSaverTap: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        QUICK_FUNCTIONS.chunked(3).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { fn ->
                    val on = enabled.contains(fn.id)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(
                                if (on) Brush.verticalGradient(listOf(XCyanDim, Color.Transparent)) else Brush.verticalGradient(listOf(PanelGlass, PanelGlass)),
                                RoundedCornerShape(12.dp)
                            )
                            .border(1.dp, if (on) XCyan else LineSoft, RoundedCornerShape(12.dp))
                            .clickable {
                                when (fn.id) {
                                    "ping_check" -> onPingCheckTap()
                                    "power_saver" -> onPowerSaverTap()
                                    else -> onToggle(fn, !on)
                                }
                            }
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(if (on) XCyan.copy(alpha = 0.18f) else PanelElevated),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(fn.icon, contentDescription = fn.label, tint = if (on) XCyan else Text1, modifier = Modifier.size(15.dp))
                            }
                            Spacer(Modifier.height(6.dp))
                            Text(fn.label, color = if (on) Text0 else Text1, fontSize = 9.sp, textAlign = TextAlign.Center)
                        }
                        if (on) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(5.dp)
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(XCyan)
                            )
                        }
                    }
                }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}
