package com.xboost.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import com.xboost.app.core.AccentColor
import com.xboost.app.core.DeviceCompat

private fun schemeFor(accent: AccentColor) = when (accent) {
    AccentColor.RED -> XRed to XCyan
    AccentColor.CYAN -> XCyan to XRed
    AccentColor.PURPLE -> Color(0xFFB463FF) to XCyan
    AccentColor.GREEN -> Color(0xFF3DFFA0) to XRed
}

@Composable
fun XBoostTheme(accent: AccentColor = AccentColor.RED, content: @Composable () -> Unit) {
    val (primary, secondary) = schemeFor(accent)
    val scheme = darkColorScheme(
        primary = primary,
        secondary = secondary,
        tertiary = XAmber,
        background = Bg0,
        surface = Panel,
        onBackground = Text0,
        onSurface = Text0,
        outline = Line
    )
    // Classified once per process (RAM total doesn't change at runtime), then
    // handed down so any screen can scale animation/draw cost to real hardware
    // — the same profile the Modules screen already shows under "Device
    // Compatibility", now actually driving visuals too, not just a label.
    val context = LocalContext.current
    val deviceProfile = remember { DeviceCompat.classify(context) }

    CompositionLocalProvider(
        LocalAccent provides AccentColors(primary, secondary),
        LocalDeviceProfile provides deviceProfile
    ) {
        MaterialTheme(
            colorScheme = scheme,
            typography = XBoostTypography,
            content = content
        )
    }
}
