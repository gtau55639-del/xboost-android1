package com.xboost.app.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.xboost.app.core.AppRisk
import com.xboost.app.core.RiskLevel
import com.xboost.app.core.ScanSummary
import com.xboost.app.core.SecurityScanner
import com.xboost.app.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class ScanState { IDLE, SCANNING, DONE }

/**
 * Security Scan — a permission & install-source risk checker, not a
 * signature-based antivirus (see SecurityScanner's doc comment for exactly
 * why a non-root app can't do the latter honestly). Real PackageManager
 * data in, real risk reasons out, an "Uninstall" shortcut that opens the
 * genuine system uninstall dialog — no placebo "cleaning" animation.
 */
@Composable
fun SecurityScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var state by remember { mutableStateOf(ScanState.IDLE) }
    var summary by remember { mutableStateOf<ScanSummary?>(null) }

    fun runScan() {
        state = ScanState.SCANNING
        scope.launch {
            val result = withContext(Dispatchers.Default) { SecurityScanner.scanInstalledApps(context) }
            summary = result
            state = ScanState.DONE
        }
    }

    LaunchedEffect(Unit) { runScan() }

    Column(modifier = Modifier.fillMaxSize().background(Bg0).padding(horizontal = 20.dp, vertical = 24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Text1, modifier = Modifier.clickable { onBack() })
            Spacer(Modifier.width(10.dp))
            Text("SECURITY SCAN", color = Text0, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
            Icon(
                Icons.Filled.Refresh, contentDescription = "Rescan", tint = if (state == ScanState.SCANNING) Text2 else XCyan,
                modifier = Modifier.clickable(enabled = state != ScanState.SCANNING) { runScan() }
            )
        }
        Spacer(Modifier.height(4.dp))
        Text(
            "Checks install source and sensitive permission combinations on your installed apps. " +
            "Not a signature antivirus — no app can safely claim that without root access.",
            color = Text2, fontSize = 10.5.sp, lineHeight = 14.sp
        )
        Spacer(Modifier.height(18.dp))

        when (state) {
            ScanState.SCANNING -> ScanningCard()
            ScanState.IDLE -> {}
            ScanState.DONE -> summary?.let { s ->
                SummaryCard(s)
                Spacer(Modifier.height(18.dp))
                val flagged = s.high + s.medium + s.low
                if (flagged.isEmpty()) {
                    CleanCard(s.scannedCount)
                } else {
                    LazyColumn(modifier = Modifier.weight(1f)) {
                        items(flagged) { risk -> AppRiskRow(risk) }
                    }
                }
            }
        }
    }
}

@Composable
private fun ScanningCard() {
    Column(
        modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).border(1.dp, Line, RoundedCornerShape(14.dp)).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        CircularProgressIndicator(color = XCyan, strokeWidth = 3.dp, modifier = Modifier.size(28.dp))
        Spacer(Modifier.height(10.dp))
        Text("Checking installed apps…", color = Text1, fontSize = 12.sp)
    }
}

@Composable
private fun SummaryCard(s: ScanSummary) {
    val worst = when {
        s.high.isNotEmpty() -> RiskLevel.HIGH
        s.medium.isNotEmpty() -> RiskLevel.MEDIUM
        s.low.isNotEmpty() -> RiskLevel.LOW
        else -> RiskLevel.SAFE
    }
    val (accent, headline) = when (worst) {
        RiskLevel.HIGH -> XRed to "${s.high.size} app(s) need attention"
        RiskLevel.MEDIUM -> XAmber to "${s.medium.size} app(s) worth reviewing"
        RiskLevel.LOW -> XCyan to "${s.low.size} minor flag(s) found"
        RiskLevel.SAFE -> XCyan to "No risky permission patterns found"
    }
    Column(
        modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).border(1.dp, accent.copy(alpha = 0.45f), RoundedCornerShape(16.dp)).padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(if (worst == RiskLevel.SAFE) Icons.Filled.Shield else Icons.Filled.WarningAmber, contentDescription = null, tint = accent, modifier = Modifier.size(26.dp))
            Spacer(Modifier.width(10.dp))
            Column {
                Text(headline, color = Text0, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("${s.scannedCount} apps scanned", color = Text2, fontSize = 10.5.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CountChip("High", s.high.size, XRed)
            CountChip("Medium", s.medium.size, XAmber)
            CountChip("Low", s.low.size, XCyan)
        }
        val ppText = when (s.playProtectOn) {
            true -> "App verification (Play Protect / package verifier) is ON"
            false -> "App verification (Play Protect / package verifier) appears OFF"
            null -> "App verification status not exposed by this device/OEM build"
        }
        Text(ppText, color = Text2, fontSize = 10.sp, modifier = Modifier.padding(top = 12.dp))
    }
}

@Composable
private fun CountChip(label: String, count: Int, color: Color) {
    Row(
        modifier = Modifier.background(color.copy(alpha = 0.14f), RoundedCornerShape(10.dp)).padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("$count", color = color, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Spacer(Modifier.width(4.dp))
        Text(label, color = color, fontSize = 10.sp)
    }
}

@Composable
private fun CleanCard(scannedCount: Int) {
    Column(
        modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).border(1.dp, XCyan.copy(alpha = 0.35f), RoundedCornerShape(14.dp)).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(Icons.Filled.VerifiedUser, contentDescription = null, tint = XCyan, modifier = Modifier.size(30.dp))
        Spacer(Modifier.height(8.dp))
        Text("Nothing flagged", color = Text0, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        Text(
            "None of the $scannedCount non-system apps checked matched a risky install-source or permission pattern.",
            color = Text2, fontSize = 10.5.sp, lineHeight = 14.sp
        )
    }
}

@Composable
private fun AppRiskRow(risk: AppRisk) {
    val context = LocalContext.current
    val accent = when (risk.riskLevel) {
        RiskLevel.HIGH -> XRed
        RiskLevel.MEDIUM -> XAmber
        RiskLevel.LOW -> XCyan
        RiskLevel.SAFE -> Text2
    }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .background(Panel, RoundedCornerShape(14.dp))
            .border(1.dp, accent.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(30.dp).background(accent.copy(alpha = 0.16f), RoundedCornerShape(9.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(risk.label.take(1).uppercase(), color = accent, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(risk.label, color = Text0, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Text(risk.packageName, color = Text2, fontSize = 9.5.sp)
            }
            Text(
                risk.riskLevel.name, color = accent, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.background(accent.copy(alpha = 0.14f), RoundedCornerShape(8.dp)).padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(risk.installerLabel, color = Text2, fontSize = 10.sp)
        risk.reasons.forEach { reason ->
            Text("•  $reason", color = Text1, fontSize = 10.5.sp, lineHeight = 15.sp, modifier = Modifier.padding(top = 3.dp))
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            TextButton(onClick = {
                val intent = Intent(Intent.ACTION_DELETE, Uri.parse("package:${risk.packageName}"))
                runCatching { context.startActivity(intent) }
            }) {
                Text("Uninstall", color = XRed, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
            TextButton(onClick = {
                val intent = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${risk.packageName}"))
                runCatching { context.startActivity(intent) }
            }) {
                Text("App Info", color = XCyan, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}
