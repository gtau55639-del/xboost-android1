package com.xboost.app.core

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager

enum class ThermalLevel { COOL, WARM, HOT }

object ThermalGuardManager {

    /** Registering a receiver with null and this filter just reads the last sticky broadcast — real, instant, no permission. */
    fun currentBatteryTempCelsius(context: Context): Float? {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val tenths = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: return null
        if (tenths == Int.MIN_VALUE) return null
        return tenths / 10f
    }

    fun levelFor(tempCelsius: Float?): ThermalLevel = when {
        tempCelsius == null -> ThermalLevel.COOL
        tempCelsius >= 45f -> ThermalLevel.HOT
        tempCelsius >= 38f -> ThermalLevel.WARM
        else -> ThermalLevel.COOL
    }
}
