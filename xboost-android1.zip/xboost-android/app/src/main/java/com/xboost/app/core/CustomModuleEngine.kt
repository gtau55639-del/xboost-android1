package com.xboost.app.core

import android.app.ActivityManager
import android.content.Context
import android.content.Intent

/**
 * Non-root Module Installer.
 *
 * This is deliberately NOT a plugin system that loads or executes arbitrary
 * user-supplied code — Android (rightly) makes that unsafe and unnecessary
 * without root, and XBoost isn't going to fake a "code module" that's
 * really just a placebo switch. Instead, every module — whether the user
 * installs it from the built-in catalog or builds one manually — is a named,
 * saved binding onto one of a fixed set of REAL actions XBoost already knows
 * how to do (the same calls BoosterEngine/SystemMonitor/ThermalGuardManager
 * use elsewhere in the app). "Manual install" means the user assembles their
 * own module (name + action + target), not that they inject code.
 *
 * Installed modules are saved to DataStore (see PreferencesManager) as
 * simple delimited strings — no JSON/serialization library is in this
 * project's dependencies, so this stays dependency-free on purpose.
 */

/** The fixed set of real, verifiable no-root actions a module can bind to. */
enum class ModuleActionType { KILL_APP, TOGGLE_DND, PING_HOST, THERMAL_CHECK, OPEN_APP }

/** Where a module came from — shown in the UI, doesn't change how it runs. */
enum class ModuleSource { CATALOG, MANUAL }

data class CustomModule(
    val id: String,
    val name: String,
    val desc: String,
    val actionType: ModuleActionType,
    val param: String,
    val enabled: Boolean,
    val source: ModuleSource
) {
    /** Delimited encoding for DataStore's stringSetPreferencesKey. */
    fun encode(): String {
        fun clean(s: String) = s.replace(FIELD_SEP, "").replace("\n", " ")
        return listOf(clean(id), clean(name), clean(desc), actionType.name, clean(param), enabled.toString(), source.name)
            .joinToString(FIELD_SEP)
    }

    companion object {
        const val FIELD_SEP = "\u0001"

        fun decode(raw: String): CustomModule? {
            val parts = raw.split(FIELD_SEP)
            if (parts.size < 7) return null
            return try {
                CustomModule(
                    id = parts[0],
                    name = parts[1],
                    desc = parts[2],
                    actionType = ModuleActionType.valueOf(parts[3]),
                    param = parts[4],
                    enabled = parts[5].toBooleanStrictOrNull() ?: true,
                    source = ModuleSource.valueOf(parts[6])
                )
            } catch (e: Exception) {
                null // corrupted/old-format entry — skip rather than crash the list
            }
        }
    }
}

/** A catalog entry the user can install with one tap (plus a target pick where needed). */
data class ModuleTemplate(
    val templateId: String,
    val name: String,
    val desc: String,
    val actionType: ModuleActionType,
    val needsPackageParam: Boolean = false,
    val needsHostParam: Boolean = false,
    val defaultParam: String = ""
)

object ModuleCatalog {
    /** "Sudah disediakan" — pre-built templates, all bound to real actions. */
    val templates = listOf(
        ModuleTemplate(
            templateId = "kill_target_app",
            name = "Kill Target App",
            desc = "Matikan proses background 1 app pilihanmu secara instan — ActivityManager.killBackgroundProcesses() yang sama seperti Background Trim, tapi ditarget ke 1 app spesifik.",
            actionType = ModuleActionType.KILL_APP,
            needsPackageParam = true
        ),
        ModuleTemplate(
            templateId = "dnd_pulse_on",
            name = "Quick DND Pulse",
            desc = "Nyalain Do Not Disturb sistem sekali tekan. Real system setting, butuh izin Notification Access yang sama seperti modul Game DND.",
            actionType = ModuleActionType.TOGGLE_DND,
            defaultParam = "on"
        ),
        ModuleTemplate(
            templateId = "ping_custom_server",
            name = "Ping Server Custom",
            desc = "Tes latency real ke host/IP pilihanmu sendiri (bukan cuma 8.8.8.8 bawaan Network screen).",
            actionType = ModuleActionType.PING_HOST,
            needsHostParam = true,
            defaultParam = "1.1.1.1"
        ),
        ModuleTemplate(
            templateId = "thermal_snapshot",
            name = "Battery Temp Snapshot",
            desc = "Baca suhu baterai real device kamu kapan saja, sensor sama seperti Thermal Guard.",
            actionType = ModuleActionType.THERMAL_CHECK
        ),
        ModuleTemplate(
            templateId = "quick_launch_app",
            name = "Quick Launch App",
            desc = "Buka 1 app pilihanmu langsung dari daftar modul, tanpa balik ke home screen.",
            actionType = ModuleActionType.OPEN_APP,
            needsPackageParam = true
        )
    )
}

data class ModuleRunResult(val success: Boolean, val message: String)

object CustomModuleEngine {

    /** Runs a module's real action right now and returns an honest, specific result — never a fake "Success!". */
    suspend fun run(context: Context, module: CustomModule): ModuleRunResult = when (module.actionType) {
        ModuleActionType.KILL_APP -> runKillApp(context, module.param)
        ModuleActionType.TOGGLE_DND -> runToggleDnd(context, module.param)
        ModuleActionType.PING_HOST -> runPing(module.param)
        ModuleActionType.THERMAL_CHECK -> runThermal(context)
        ModuleActionType.OPEN_APP -> runOpenApp(context, module.param)
    }

    private fun runKillApp(context: Context, pkg: String): ModuleRunResult {
        if (pkg.isBlank()) return ModuleRunResult(false, "Belum ada target app.")
        if (pkg == context.packageName) return ModuleRunResult(false, "Tidak bisa mematikan XBoost sendiri.")
        // Same protected-package rule Background Trim already enforces — a
        // custom module shouldn't be a backdoor around a safety check the
        // app makes everywhere else (launcher, default dialer/SMS, whatever
        // currently holds audio focus).
        val protectedPkgs = BoosterEngine.protectedPackages(context)
        if (protectedPkgs.contains("*music_active*")) {
            return ModuleRunResult(false, "Musik/audio sedang aktif — kill app di-skip biar nggak matiin player yang lagi kepakai.")
        }
        if (pkg in protectedPkgs) {
            return ModuleRunResult(false, "App ini dilindungi (launcher/dialer/SMS default) — tidak akan dimatikan.")
        }
        val pm = context.packageManager
        val appInfo = try {
            pm.getApplicationInfo(pkg, 0)
        } catch (e: Exception) {
            return ModuleRunResult(false, "App ($pkg) sudah tidak terinstall di device ini.")
        }
        return try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            am.killBackgroundProcesses(pkg)
            val label = runCatching { pm.getApplicationLabel(appInfo).toString() }.getOrDefault(pkg)
            ModuleRunResult(true, "Proses background \"$label\" diminta OS untuk dimatikan.")
        } catch (e: SecurityException) {
            ModuleRunResult(false, "OEM device ini memblokir kill process untuk app ini.")
        }
    }

    private fun runToggleDnd(context: Context, param: String): ModuleRunResult {
        val enable = param != "off"
        val ok = BoosterEngine.setGameDnd(context, enable)
        return if (ok) {
            ModuleRunResult(true, if (enable) "Do Not Disturb dinyalakan." else "Do Not Disturb dimatikan.")
        } else {
            ModuleRunResult(false, "Izin Notification Access belum diberikan (Settings > Modules akan minta ini juga untuk Game DND).")
        }
    }

    private suspend fun runPing(host: String): ModuleRunResult {
        val target = host.ifBlank { "8.8.8.8" }
        val ms = SystemMonitor.pingMs(target)
        return if (ms != null) ModuleRunResult(true, "$target balas dalam ${ms}ms.")
        else ModuleRunResult(false, "$target tidak terjangkau dari jaringan ini.")
    }

    private fun runThermal(context: Context): ModuleRunResult {
        val temp = ThermalGuardManager.currentBatteryTempCelsius(context)
        return if (temp != null) {
            val level = ThermalGuardManager.levelFor(temp)
            ModuleRunResult(true, "Suhu baterai: %.1f°C (%s)".format(temp, level.name.lowercase()))
        } else {
            ModuleRunResult(false, "Sensor suhu baterai tidak terbaca di device ini.")
        }
    }

    private fun runOpenApp(context: Context, pkg: String): ModuleRunResult {
        if (pkg.isBlank()) return ModuleRunResult(false, "Belum ada app target.")
        val intent = context.packageManager.getLaunchIntentForPackage(pkg)
            ?: return ModuleRunResult(false, "App tidak ditemukan atau sudah dihapus.")
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            ModuleRunResult(true, "App dibuka.")
        } catch (e: Exception) {
            ModuleRunResult(false, "Gagal membuka app: ${e.message ?: "unknown error"}")
        }
    }
}
