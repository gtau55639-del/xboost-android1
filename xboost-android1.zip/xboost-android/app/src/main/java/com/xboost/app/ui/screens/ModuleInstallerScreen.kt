package com.xboost.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.xboost.app.core.*
import com.xboost.app.ui.theme.*
import kotlinx.coroutines.launch

/**
 * Non-root Module Installer.
 *
 * Two ways in, one real engine underneath:
 * - "Katalog" — pre-built modules, install with one tap (plus a target pick
 *   for the ones that need it).
 * - "Manual" — assemble your own: name it, pick which real action it runs,
 *   pick its target. Not a code/plugin loader — Android doesn't allow that
 *   safely without root, and XBoost isn't going to fake one.
 *
 * Every installed module — from either tab — is executed by
 * CustomModuleEngine, the same real, verifiable calls the rest of the app
 * already uses (kill process, toggle DND, ping, read battery temp, launch
 * app). Nothing here is a placebo switch.
 */

private sealed class AppPickTarget {
    data class ForCatalog(val template: ModuleTemplate) : AppPickTarget()
    data class ForManual(val actionType: ModuleActionType) : AppPickTarget()
}

private fun iconFor(type: ModuleActionType): ImageVector = when (type) {
    ModuleActionType.KILL_APP -> Icons.Filled.CleaningServices
    ModuleActionType.TOGGLE_DND -> Icons.Filled.DoNotDisturbOn
    ModuleActionType.PING_HOST -> Icons.Filled.NetworkCheck
    ModuleActionType.THERMAL_CHECK -> Icons.Filled.Thermostat
    ModuleActionType.OPEN_APP -> Icons.Filled.OpenInNew
}

private fun labelFor(type: ModuleActionType): String = when (type) {
    ModuleActionType.KILL_APP -> "Kill App"
    ModuleActionType.TOGGLE_DND -> "Toggle DND"
    ModuleActionType.PING_HOST -> "Ping Host"
    ModuleActionType.THERMAL_CHECK -> "Cek Suhu"
    ModuleActionType.OPEN_APP -> "Buka App"
}

@Composable
fun ModuleInstallerScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var tab by remember { mutableStateOf(0) } // 0 = Katalog, 1 = Manual
    var appPickTarget by remember { mutableStateOf<AppPickTarget?>(null) }
    var expandedHostTemplateId by remember { mutableStateOf<String?>(null) }
    var hostInput by remember { mutableStateOf("") }

    val installed by PreferencesManager.customModules(context).collectAsState(initial = emptyList())
    val results = remember { mutableStateMapOf<String, ModuleRunResult>() }

    // Manual form state
    var manualName by remember { mutableStateOf("") }
    var manualDesc by remember { mutableStateOf("") }
    var manualType by remember { mutableStateOf(ModuleActionType.KILL_APP) }
    var manualPackageParam by remember { mutableStateOf("") }
    var manualHostParam by remember { mutableStateOf("") }
    var manualDndOn by remember { mutableStateOf(true) }

    val installedApps = remember {
        context.packageManager.getInstalledApplications(0)
            .filter { it.packageName != context.packageName && (it.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) == 0 }
            .sortedBy { context.packageManager.getApplicationLabel(it).toString() }
            .take(120)
    }

    fun appLabel(pkg: String): String =
        runCatching { context.packageManager.getApplicationLabel(context.packageManager.getApplicationInfo(pkg, 0)).toString() }
            .getOrDefault(pkg)

    Column(modifier = Modifier.fillMaxSize().background(Bg0).padding(horizontal = 20.dp, vertical = 24.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Filled.ArrowBack, contentDescription = "Back", tint = Text1,
                modifier = Modifier.clickable { if (appPickTarget != null) appPickTarget = null else onBack() }
            )
            Spacer(Modifier.width(10.dp))
            Text(
                if (appPickTarget != null) "PILIH APP" else "MODULE INSTALLER (NON-ROOT)",
                color = Text0, fontWeight = FontWeight.Bold, fontSize = 16.sp
            )
        }

        if (appPickTarget != null) {
            Spacer(Modifier.height(16.dp))
            LazyColumn(modifier = Modifier.weight(1f)) {
                items(installedApps) { app ->
                    val pkg = app.packageName
                    val label = context.packageManager.getApplicationLabel(app).toString()
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                when (val target = appPickTarget) {
                                    is AppPickTarget.ForCatalog -> {
                                        val t = target.template
                                        scope.launch {
                                            PreferencesManager.saveCustomModule(
                                                context,
                                                CustomModule(
                                                    id = "catalog_${t.templateId}",
                                                    name = t.name,
                                                    desc = t.desc,
                                                    actionType = t.actionType,
                                                    param = pkg,
                                                    enabled = true,
                                                    source = ModuleSource.CATALOG
                                                )
                                            )
                                        }
                                    }
                                    is AppPickTarget.ForManual -> manualPackageParam = pkg
                                    null -> {}
                                }
                                appPickTarget = null
                            }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Apps, contentDescription = null, tint = Text2, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(10.dp))
                        Text(label, color = Text0, fontSize = 13.sp)
                    }
                }
            }
            return@Column
        }

        Text(
            "Pasang modul dari katalog atau bikin sendiri manual. Semua modul di sini nempel ke aksi nyata yang " +
            "sudah jalan di XBoost (kill process, toggle DND, ping, baca suhu baterai, buka app) — bukan modul " +
            "root/system, karena itu butuh akses yang XBoost sengaja tidak minta.",
            color = Text2, fontSize = 11.sp, lineHeight = 15.sp,
            modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
        )

        TabRow(
            selectedTabIndex = tab,
            containerColor = Bg1,
            contentColor = XCyan,
            modifier = Modifier.clip(RoundedCornerShape(10.dp))
        ) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Katalog", fontSize = 12.sp) })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Manual", fontSize = 12.sp) })
        }
        Spacer(Modifier.height(14.dp))

        Column(modifier = Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState())) {
            if (tab == 0) {
                ModuleCatalog.templates.forEach { t ->
                    val installedModule = installed.find { it.id == "catalog_${t.templateId}" }
                    CatalogCard(
                        template = t,
                        installedModule = installedModule,
                        hostExpanded = expandedHostTemplateId == t.templateId,
                        hostInput = hostInput,
                        onHostInputChange = { hostInput = it },
                        onInstallClick = {
                            when {
                                installedModule != null -> {
                                    scope.launch { PreferencesManager.deleteCustomModule(context, installedModule.id) }
                                }
                                t.needsPackageParam -> appPickTarget = AppPickTarget.ForCatalog(t)
                                t.needsHostParam -> {
                                    hostInput = t.defaultParam
                                    expandedHostTemplateId = t.templateId
                                }
                                else -> scope.launch {
                                    PreferencesManager.saveCustomModule(
                                        context,
                                        CustomModule(
                                            id = "catalog_${t.templateId}", name = t.name, desc = t.desc,
                                            actionType = t.actionType, param = t.defaultParam,
                                            enabled = true, source = ModuleSource.CATALOG
                                        )
                                    )
                                }
                            }
                        },
                        onConfirmHost = {
                            scope.launch {
                                PreferencesManager.saveCustomModule(
                                    context,
                                    CustomModule(
                                        id = "catalog_${t.templateId}", name = t.name, desc = t.desc,
                                        actionType = t.actionType, param = hostInput.ifBlank { t.defaultParam },
                                        enabled = true, source = ModuleSource.CATALOG
                                    )
                                )
                            }
                            expandedHostTemplateId = null
                        }
                    )
                }
            } else {
                // ---------- Manual builder ----------
                Column(
                    modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp))
                        .border(1.dp, Line, RoundedCornerShape(14.dp)).padding(14.dp)
                ) {
                    Text("Bikin Modul Manual", color = Text0, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = manualName, onValueChange = { manualName = it },
                        label = { Text("Nama modul", fontSize = 11.sp) },
                        singleLine = true, modifier = Modifier.fillMaxWidth(),
                        colors = fieldColors()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = manualDesc, onValueChange = { manualDesc = it },
                        label = { Text("Deskripsi singkat (opsional)", fontSize = 11.sp) },
                        singleLine = true, modifier = Modifier.fillMaxWidth(),
                        colors = fieldColors()
                    )
                    Spacer(Modifier.height(12.dp))
                    Text("Aksi nyata yang dijalankan modul ini:", color = Text2, fontSize = 10.sp)
                    Spacer(Modifier.height(6.dp))
                    Row(modifier = Modifier.horizontalScrollFix(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ModuleActionType.values().forEach { type ->
                            FilterChip(
                                selected = manualType == type,
                                onClick = { manualType = type },
                                label = { Text(labelFor(type), fontSize = 11.sp) },
                                leadingIcon = { Icon(iconFor(type), contentDescription = null, modifier = Modifier.size(14.dp)) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = XCyanDim, selectedLabelColor = XCyan, selectedLeadingIconColor = XCyan,
                                    containerColor = Bg1, labelColor = Text1, iconColor = Text1
                                )
                            )
                        }
                    }
                    Spacer(Modifier.height(12.dp))

                    when (manualType) {
                        ModuleActionType.KILL_APP, ModuleActionType.OPEN_APP -> {
                            Text("Target app:", color = Text2, fontSize = 10.sp)
                            Spacer(Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth()
                                    .background(Bg1, RoundedCornerShape(10.dp))
                                    .clickable { appPickTarget = AppPickTarget.ForManual(manualType) }
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Filled.Apps, contentDescription = null, tint = Text2, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    if (manualPackageParam.isBlank()) "Ketuk untuk pilih app" else appLabel(manualPackageParam),
                                    color = if (manualPackageParam.isBlank()) Text2 else Text0, fontSize = 12.sp
                                )
                            }
                        }
                        ModuleActionType.PING_HOST -> {
                            OutlinedTextField(
                                value = manualHostParam, onValueChange = { manualHostParam = it },
                                label = { Text("Host / IP (mis. 1.1.1.1)", fontSize = 11.sp) },
                                singleLine = true, modifier = Modifier.fillMaxWidth(),
                                colors = fieldColors()
                            )
                        }
                        ModuleActionType.TOGGLE_DND -> {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = manualDndOn, onClick = { manualDndOn = true },
                                    label = { Text("Nyalakan", fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = XCyanDim, selectedLabelColor = XCyan, containerColor = Bg1, labelColor = Text1)
                                )
                                FilterChip(
                                    selected = !manualDndOn, onClick = { manualDndOn = false },
                                    label = { Text("Matikan", fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = XCyanDim, selectedLabelColor = XCyan, containerColor = Bg1, labelColor = Text1)
                                )
                            }
                        }
                        ModuleActionType.THERMAL_CHECK -> {
                            Text("Tidak perlu target tambahan — langsung baca sensor suhu baterai.", color = Text2, fontSize = 10.5.sp)
                        }
                    }

                    Spacer(Modifier.height(14.dp))
                    val canSave = manualName.isNotBlank() && when (manualType) {
                        ModuleActionType.KILL_APP, ModuleActionType.OPEN_APP -> manualPackageParam.isNotBlank()
                        ModuleActionType.PING_HOST -> true
                        ModuleActionType.TOGGLE_DND, ModuleActionType.THERMAL_CHECK -> true
                    }
                    Button(
                        onClick = {
                            val param = when (manualType) {
                                ModuleActionType.KILL_APP, ModuleActionType.OPEN_APP -> manualPackageParam
                                ModuleActionType.PING_HOST -> manualHostParam.ifBlank { "8.8.8.8" }
                                ModuleActionType.TOGGLE_DND -> if (manualDndOn) "on" else "off"
                                ModuleActionType.THERMAL_CHECK -> ""
                            }
                            scope.launch {
                                PreferencesManager.saveCustomModule(
                                    context,
                                    CustomModule(
                                        id = "manual_${System.currentTimeMillis()}",
                                        name = manualName.trim(),
                                        desc = manualDesc.trim().ifBlank { "Modul manual — ${labelFor(manualType)}" },
                                        actionType = manualType, param = param,
                                        enabled = true, source = ModuleSource.MANUAL
                                    )
                                )
                            }
                            manualName = ""; manualDesc = ""; manualPackageParam = ""; manualHostParam = ""
                        },
                        enabled = canSave,
                        colors = ButtonDefaults.buttonColors(containerColor = XCyan, disabledContainerColor = Bg1),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Simpan Modul", color = if (canSave) Bg0 else Text2, fontSize = 12.sp, fontWeight = FontWeight.Medium) }
                }
            }

            Spacer(Modifier.height(20.dp))
            Text("MODUL TERPASANG (${installed.size})", color = Text1, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))

            if (installed.isEmpty()) {
                Text("Belum ada modul terpasang. Pasang dari Katalog atau bikin di tab Manual.", color = Text2, fontSize = 11.sp)
            }

            installed.forEach { module ->
                InstalledModuleCard(
                    module = module,
                    label = when (module.actionType) {
                        ModuleActionType.KILL_APP, ModuleActionType.OPEN_APP ->
                            if (module.param.isNotBlank()) "Target: ${appLabel(module.param)}" else null
                        ModuleActionType.PING_HOST -> "Host: ${module.param}"
                        ModuleActionType.TOGGLE_DND -> if (module.param == "off") "Aksi: matikan DND" else "Aksi: nyalakan DND"
                        ModuleActionType.THERMAL_CHECK -> null
                    },
                    result = results[module.id],
                    onToggleEnabled = { on -> scope.launch { PreferencesManager.setCustomModuleEnabled(context, module.id, on) } },
                    onRunNow = {
                        scope.launch { results[module.id] = CustomModuleEngine.run(context, module) }
                    },
                    onDelete = {
                        scope.launch { PreferencesManager.deleteCustomModule(context, module.id) }
                        results.remove(module.id)
                    }
                )
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Text0, unfocusedTextColor = Text0,
    focusedBorderColor = XCyan, unfocusedBorderColor = Line,
    focusedLabelColor = XCyan, unfocusedLabelColor = Text2,
    cursorColor = XCyan
)

@Composable
private fun Modifier.horizontalScrollFix(): Modifier {
    val scrollState = rememberScrollState()
    return this.horizontalScroll(scrollState)
}

@Composable
private fun CatalogCard(
    template: ModuleTemplate,
    installedModule: CustomModule?,
    hostExpanded: Boolean,
    hostInput: String,
    onHostInputChange: (String) -> Unit,
    onInstallClick: () -> Unit,
    onConfirmHost: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp))
            .border(1.dp, Line, RoundedCornerShape(14.dp)).padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Icon(iconFor(template.actionType), contentDescription = null, tint = if (installedModule != null) XCyan else Text1, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(template.name, color = Text0, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Text(template.desc, color = Text2, fontSize = 10.sp, lineHeight = 13.sp)
            }
            Spacer(Modifier.width(8.dp))
            Button(
                onClick = onInstallClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (installedModule != null) Bg1 else XCyan
                ),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    if (installedModule != null) "Copot" else "Install",
                    fontSize = 11.sp,
                    color = if (installedModule != null) XRed else Bg0
                )
            }
        }
        if (hostExpanded) {
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = hostInput, onValueChange = onHostInputChange,
                label = { Text("Host / IP", fontSize = 11.sp) },
                singleLine = true, modifier = Modifier.fillMaxWidth(),
                colors = fieldColors()
            )
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = onConfirmHost,
                colors = ButtonDefaults.buttonColors(containerColor = XCyan),
                modifier = Modifier.fillMaxWidth()
            ) { Text("Pasang", color = Bg0, fontSize = 12.sp) }
        }
    }
    Spacer(Modifier.height(10.dp))
}

@Composable
private fun InstalledModuleCard(
    module: CustomModule,
    label: String?,
    result: ModuleRunResult?,
    onToggleEnabled: (Boolean) -> Unit,
    onRunNow: () -> Unit,
    onDelete: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp))
            .border(1.dp, if (module.enabled) Line else Bg1, RoundedCornerShape(14.dp)).padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Icon(iconFor(module.actionType), contentDescription = null, tint = if (module.enabled) XCyan else Text2, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(module.name, color = Text0, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.width(6.dp))
                    Text(
                        if (module.source == ModuleSource.CATALOG) "· katalog" else "· manual",
                        color = Text2, fontSize = 9.5.sp
                    )
                }
                Text(module.desc, color = Text2, fontSize = 10.sp)
                if (label != null) Text(label, color = Text2, fontSize = 9.5.sp)
            }
            Icon(
                Icons.Filled.DeleteOutline, contentDescription = "Hapus", tint = Text2,
                modifier = Modifier.size(18.dp).clickable { onDelete() }
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Switch(
                checked = module.enabled, onCheckedChange = onToggleEnabled,
                colors = SwitchDefaults.colors(checkedThumbColor = XCyan, checkedTrackColor = XCyanDim)
            )
            Spacer(Modifier.width(6.dp))
            Text(if (module.enabled) "Aktif" else "Non-aktif", color = Text2, fontSize = 10.sp, modifier = Modifier.weight(1f))
            Button(
                onClick = onRunNow,
                enabled = module.enabled,
                colors = ButtonDefaults.buttonColors(containerColor = XRed, disabledContainerColor = Bg1),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
            ) { Text("Run Now", fontSize = 11.sp, color = if (module.enabled) Text0 else Text2) }
        }
        if (result != null) {
            Spacer(Modifier.height(8.dp))
            Text(
                result.message,
                color = if (result.success) XCyan else XAmber,
                fontSize = 10.5.sp, lineHeight = 14.sp
            )
        }
    }
    Spacer(Modifier.height(10.dp))
}
