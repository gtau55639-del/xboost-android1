package com.xboost.app.overlay

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Choreographer
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.xboost.app.MainActivity
import com.xboost.app.R

/**
 * Draws a small floating FPS readout over whatever app is in front.
 *
 * How the number is real: Choreographer.postFrameCallback fires on every
 * vsync pulse the system delivers to this process. Counting callbacks per
 * second gives the actual display refresh cadence XBoost is being driven
 * at — the same technique third-party (non-root) FPS overlays use, since
 * there is no public API to read another app's internal render loop
 * without root. It is an approximation of system frame delivery, not a
 * per-app engine-level FPS counter — documented honestly, not sold as more
 * than it is.
 */
class FpsOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var overlayView: TextView? = null
    private var frameCount = 0
    private var lastReportMs = 0L
    private var running = false

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!running) return
            frameCount++
            val now = System.currentTimeMillis()
            if (now - lastReportMs >= 1000) {
                overlayView?.text = "${frameCount} FPS"
                frameCount = 0
                lastReportMs = now
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        startForeground(NOTIF_ID, buildNotification())
        addOverlay()
        running = true
        lastReportMs = System.currentTimeMillis()
        Choreographer.getInstance().postFrameCallback(frameCallback)
    }

    override fun onDestroy() {
        running = false
        overlayView?.let { runCatching { windowManager.removeView(it) } }
        overlayView = null
        super.onDestroy()
    }

    private fun addOverlay() {
        val tv = TextView(this).apply {
            text = "…"
            setTextColor(Color.parseColor("#26F0D0"))
            setBackgroundColor(Color.parseColor("#CC0D0E15"))
            textSize = 12f
            setPadding(20, 10, 20, 10)
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 24
            y = 120
        }

        windowManager.addView(tv, params)
        overlayView = tv
    }

    private fun buildNotification(): android.app.Notification {
        val channelId = "xboost_fps_overlay"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(channelId, "FPS Overlay", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("XBoost FPS overlay active")
            .setContentText("Tap to open XBoost")
            .setSmallIcon(R.drawable.ic_xboost_logo)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val NOTIF_ID = 4201
    }
}
