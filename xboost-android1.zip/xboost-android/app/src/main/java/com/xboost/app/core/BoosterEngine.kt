package com.xboost.app.core

import android.app.ActivityManager
import android.app.NotificationManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.media.AudioManager
import android.os.PowerManager
import android.os.Process
import android.provider.Telephony
import android.telecom.TelecomManager
import android.view.Window
import android.view.WindowManager

/**
 * Everything here does something real and verifiable on a non-rooted device.
 * Nothing in this file overclocks a CPU/GPU or force-frees another app's RAM —
 * that requires root and is out of scope for a Play-Store-distributable app.
 */
data class BoostResult(
    val processesSignaled: Int,
    val dndEnabled: Boolean,
    val message: String
)

object BoosterEngine {

    /**
     * Asks the OS to trim/kill eligible cached background processes.
     * Android 8+ (Oreo, targetSdk 26+) heavily restricts this by design —
     * apps in the foreground or with active services are never touched.
     * Real effect: modest RAM headroom before launching a game, not a
     * system-wide "wipe". Requires KILL_BACKGROUND_PROCESSES permission
     * (granted automatically, not a runtime prompt).
     */
    /**
     * Packages trim must never touch, beyond system apps: our own app, the
     * current launcher, default dialer, default SMS app, and — if music/audio
     * is actively playing right now — whatever's holding that audio focus.
     * Killing any of these mid-session is exactly the kind of disruptive
     * "background boost" behavior that makes booster apps annoying to use.
     *
     * Not private: CustomModuleEngine's "Kill App" module action reuses this
     * so a catalog/manual module can't target something Background Trim
     * itself refuses to touch.
     */
    internal fun protectedPackages(context: Context): Set<String> {
        val protectedPkgs = mutableSetOf(context.packageName)
        val pm = context.packageManager

        runCatching {
            pm.resolveActivity(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),
                android.content.pm.PackageManager.MATCH_DEFAULT_ONLY
            )?.activityInfo?.packageName?.let { protectedPkgs.add(it) }
        }

        runCatching {
            val telecom = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
            telecom?.defaultDialerPackage?.let { protectedPkgs.add(it) }
        }

        runCatching {
            Telephony.Sms.getDefaultSmsPackage(context)?.let { protectedPkgs.add(it) }
        }

        runCatching {
            val audio = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            if (audio?.isMusicActive == true) {
                // We can't know exactly which package owns the audio session without
                // a notification-listener permission we don't request, so when music
                // is playing at all, skip trim entirely rather than gamble on killing
                // the wrong player mid-song.
                protectedPkgs.add("*music_active*")
            }
        }

        return protectedPkgs
    }

    fun trimBackgroundProcesses(context: Context): Int {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val pm = context.packageManager
        val protectedPkgs = protectedPackages(context)

        if (protectedPkgs.contains("*music_active*")) return 0

        val candidates = pm.getInstalledApplications(0)
            .filter { app ->
                app.packageName !in protectedPkgs &&
                (app.flags and ApplicationInfo.FLAG_SYSTEM) == 0 // never touch system apps
            }

        var signaled = 0
        for (app in candidates) {
            try {
                am.killBackgroundProcesses(app.packageName)
                signaled++
            } catch (_: SecurityException) {
                // some OEMs block this per-package; skip silently, don't crash the boost flow
            }
        }
        return signaled
    }

    /**
     * Toggles system Do Not Disturb. This is a genuine system setting change,
     * not a cosmetic in-app switch. Requires the user to have granted
     * "Notification access" in system settings first (ACCESS_NOTIFICATION_POLICY
     * cannot be auto-granted — Android requires an explicit user trip to Settings).
     */
    fun setGameDnd(context: Context, enabled: Boolean): Boolean {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (!nm.isNotificationPolicyAccessGranted) return false
        nm.setInterruptionFilter(
            if (enabled) NotificationManager.INTERRUPTION_FILTER_PRIORITY
            else NotificationManager.INTERRUPTION_FILTER_ALL
        )
        return true
    }

    /**
     * Detects the current foreground app using UsageStatsManager, so XBoost
     * can auto-trigger Game Mode when a known game package comes to front.
     * Requires PACKAGE_USAGE_STATS, which the user must enable manually in
     * Settings > Apps > Special access > Usage access (Android does not allow
     * silently granting this — a real, unavoidable OS restriction).
     */
    fun currentForegroundApp(context: Context): String? {
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        val begin = end - 10_000
        val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, begin, end)
            ?: return null
        return stats.maxByOrNull { it.lastTimeUsed }?.packageName
    }

    fun runFullBoost(context: Context, dnd: Boolean): BoostResult {
        val killed = trimBackgroundProcesses(context)
        val dndOk = if (dnd) setGameDnd(context, true) else true
        val msg = when {
            killed == 0 && dndOk -> "No idle apps to trim. Device already lean."
            dndOk -> "Trimmed $killed background app(s)."
            else -> "Trimmed $killed background app(s). Grant Notification Access for DND."
        }
        return BoostResult(killed, dndOk, msg)
    }

    /**
     * Real toggle: keeps the display awake while XBoost is in the foreground,
     * using the standard Window flag. Turns off the moment the user leaves
     * the app or disables it — it never fights the OS in the background.
     */
    fun setKeepScreenOn(window: Window, enabled: Boolean) {
        if (enabled) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    /** Real, read-only status — Android does not allow third-party apps to flip system Battery Saver, only Settings can. */
    fun isPowerSaveMode(context: Context): Boolean {
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isPowerSaveMode
    }

    /**
     * If Auto Game Mode is on and the current foreground app is a known game,
     * silently enables Game DND. Meant to be called periodically (e.g. from
     * the Boost screen's live-polling loop) — real behavior, not a toggle
     * that does nothing.
     */
    fun checkAutoGameMode(context: Context, autoEnabled: Boolean): String? {
        if (!autoEnabled) return null
        val pkg = currentForegroundApp(context) ?: return null
        val gameName = KNOWN_GAMES[pkg] ?: return null
        setGameDnd(context, true)
        return gameName
    }

    /** A quick list of well-known game packages used to power the Game Library screen. */
    val KNOWN_GAMES = mapOf(
        "com.tencent.ig" to "PUBG Mobile",
        "com.mobile.legends" to "Mobile Legends",
        "com.miHoYo.GenshinImpact" to "Genshin Impact",
        "com.activision.callofduty.shooter" to "Call of Duty Mobile",
        "com.dts.freefireth" to "Free Fire"
    )

    fun installedKnownGames(context: Context): List<Pair<String, String>> {
        val pm = context.packageManager
        return KNOWN_GAMES.filter { (pkg, _) ->
            try {
                pm.getApplicationInfo(pkg, 0)
                true
            } catch (_: Exception) {
                false
            }
        }.map { it.key to it.value }
    }

    /**
     * Same as installedKnownGames but also includes user-added custom games
     * (added via the Quick Panel's "+ Game" tile or the Game Library's Add
     * Game picker), using the app's real installed label — not a fixed map,
     * since these can be any app the user chooses. Verified installed the
     * same way, no placeholder entries for an app that's been uninstalled.
     */
    fun allKnownGames(context: Context, customPkgs: Set<String>): List<Pair<String, String>> {
        val pm = context.packageManager
        val builtIn = installedKnownGames(context)
        val builtInPkgs = builtIn.map { it.first }.toSet()
        val custom = customPkgs.filter { it !in builtInPkgs }.mapNotNull { pkg ->
            runCatching {
                val info = pm.getApplicationInfo(pkg, 0)
                pkg to pm.getApplicationLabel(info).toString()
            }.getOrNull()
        }
        return (builtIn + custom).sortedBy { it.second.lowercase() }
    }
}
