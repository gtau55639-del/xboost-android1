# XBoost — Android Game Booster (Kotlin + Jetpack Compose)

## Update terbaru (revisi ke-13) — Module Installer (Non-Root): pasang dari katalog atau bikin manual

File lama tidak ada yang dihapus — ini murni penambahan modul baru (modul ke-10 di
layar Modules), plus 3 file baru (`CustomModuleEngine.kt`, `ModuleInstallerScreen.kt`,
route `module_installer`).

**Kenapa dibuat begini:** ini **bukan** plugin system yang menjalankan kode
sembarangan dari user — Android sengaja tidak mengizinkan itu tanpa root, dan
XBoost tidak mau bikin "modul" yang cuma placebo UI. Sebagai gantinya, tiap
modul (dari katalog maupun bikinan manual) adalah **binding bernama** ke satu
dari sekumpulan aksi nyata yang XBoost sudah bisa lakukan — persis panggilan
yang sama yang dipakai `BoosterEngine`/`SystemMonitor`/`ThermalGuardManager` di
tempat lain di app ini:

| Aksi | Cara kerja nyata |
|---|---|
| **Kill App** | `ActivityManager.killBackgroundProcesses()` ke 1 package target — sama seperti Background Trim, tapi ditarget |
| **Toggle DND** | `NotificationManager.setInterruptionFilter()` — sama seperti modul Game DND, butuh Notification Access |
| **Ping Host** | Latency real ke host/IP pilihan sendiri (bukan cuma 8.8.8.8 bawaan Network screen) |
| **Cek Suhu** | Baca suhu baterai real, sensor sama seperti Thermal Guard |
| **Buka App** | Launch intent standar ke 1 app target |

**Settings → Modules → "Module Installer (Non-Root)"**, dua cara pasang:
- **Katalog** — 5 modul siap pasang (`ModuleCatalog.kt`), tinggal tap Install
  (yang butuh target app/host akan minta dipilih dulu). Tap lagi untuk copot.
- **Manual** — user bikin modul sendiri: nama, deskripsi, pilih aksi dari 5
  yang tersedia, isi target (app picker / host field / on-off DND sesuai
  aksinya). Disimpan lewat `PreferencesManager` (DataStore) seperti modul lain.

Semua modul terpasang (dari katalog maupun manual) muncul di satu daftar
"Modul Terpasang" dengan toggle Aktif/Non-aktif dan tombol **Run Now** yang
benar-benar menjalankan aksinya lewat `CustomModuleEngine` dan menampilkan
hasil apa adanya (termasuk kalau gagal — misalnya izin belum di-grant, app
target sudah di-uninstall, atau host tidak terjangkau — bukan pura-pura
berhasil). Modul non-aktif tidak bisa di-Run Now sampai dinyalakan lagi, dan
modul bisa dihapus kapan saja.


## Update sebelumnya (revisi ke-12) — UI dirombak total ala game booster mainstream + AI Tips dibikin lebih pintar

Semua file lama tetap ada, tidak ada yang dihapus — ini murni penambahan/penggantian tampilan
di atas fungsi yang sudah nyata jalan (BoosterEngine, ThermalGuardManager, GameWatcherService,
dll — logiknya tidak disentuh, hanya cara nampilkannya yang dirombak).

**1. Tema visual baru — token warna tambahan, bukan pengganti**
- `Color.kt` dapat token baru (`BgDeep`, `PanelGlass`, `PanelGlassHi`, `LineSoft`, `XGreen`,
  `XPurple`, `XBlue`, gradient stops) — semua *additive*, token lama (`Bg0`, `Panel`, `Line`,
  `XRed`, `XCyan`, dll) tetap ada persis seperti sebelumnya supaya layar lain yang belum
  disentuh (Games, Network, Metrics, Settings, dll) tetap kompatibel tanpa perubahan.

**2. Boost Screen (dashboard utama) dirombak total**
- Background gradasi vertikal + dua "glow blob" radial di pojok layar (statis, bukan Canvas
  per-frame — jadi nol biaya CPU tambahan, aman juga di device LOW tier).
- Status strip baru di atas: Engine Active/Standby, Mode aktif, Thermal, dan badge tier device
  (LOW/MID/HIGH) — rangkuman "sekali lihat" yang jadi ciri khas game booster mainstream
  (Game Space, GFX Tool, dsb), yang sebelumnya nggak ada.
- Tombol Boost heksagonal sekarang dibungkus panel "glass" (gradient + border tipis), dapat
  ring ketiga (device non-LOW) dan efek pulse/glow saat aktif — tetap menghormati device
  tier yang sudah ada (LOW tier tetap dapat animasi lebih ringan, tidak berubah).
- Kartu RAM/CPU/PING/TEMP sekarang pakai sweep-gradient arc + ikon per-metric, bukan arc
  polos satu warna.
- Mode switcher (Balance/Performance/Battery) jadi pill segmented dengan ikon, bukan teks
  polos. Quick Functions jadi tile dengan badge ikon bulat + indikator titik saat aktif.

**3. Game AI Assistant (tab "AI Tips") dibikin lebih pintar — tetap 100% offline, tetap bukan cheat**
- Matching pertanyaan sekarang pakai *scoring* (kecocokan kata utuh lebih tinggi dari sekadar
  substring, dan menjumlah semua keyword yang match), bukan cuma "keyword pertama yang cocok
  menang" seperti revisi sebelumnya — jauh lebih akurat buat pertanyaan yang agak panjang.
- Suggestion chip sekarang nampilin pertanyaan natural ("Kenapa game aku lag/fps drop?"),
  bukan raw keyword ("lag").
- Ditambahkan entry khusus: kalau user nanya soal cheat/hack/aimbot/mod menu, XBoost jawab
  jujur bahwa itu di luar cakupan aplikasi (berisiko kena ban, melanggar TOS) dan mengarahkan
  balik ke fitur performa/legal yang memang ada — bukan cuma diam/nggak kejawab.
- UI chat diperbarui: avatar assistant, animasi "sedang mengetik" (tiga titik), bubble dengan
  gradient, auto-scroll ke pesan terbaru. Disclaimer offline/non-otomatisasi tetap ditampilkan
  jelas di atas, sama seperti sebelumnya — jujur soal batasannya.
- `GameContentRepository` tetap tidak membaca memori game, tidak menyuntik input, dan tidak
  mengotomatisasi permainan apapun — itu tetap di luar cakupan XBoost secara permanen, sesuai
  batasan yang sudah didokumentasikan sejak revisi-revisi sebelumnya.


## Update terbaru (revisi ke-11) — Panel auto-muncul saat masuk game + tampilan panel dirombak

**1. Bug nyata diperbaiki: Auto Game Mode sebelumnya nggak pernah benar-benar jalan**
Sebelumnya, deteksi game foreground cuma jalan di dalam loop polling
`BoostScreen`, yang di-gate oleh `appInForeground` — artinya cuma aktif
selagi layar XBoost sendiri yang kebuka. Begitu kamu benar-benar masuk game
(XBoost bukan lagi yang di depan), deteksinya berhenti. Jadi fitur "Auto
Game Mode" secara efektif nggak pernah kena kondisi nyata.

**2. `GameWatcherService` baru — jalan independen dari layar XBoost**
- Foreground service ringan yang mantau app foreground pakai
  `UsageStatsManager` di interval yang skala ke tier RAM device (≥4 detik,
  makin longgar di device 1-3GB).
- Begitu game dikenal (`BoosterEngine.KNOWN_GAMES`) kebuka: langsung terapkan
  profil DND per-game yang disimpan (real, system-wide), dan **otomatis
  memunculkan Floating Quick Panel** — ini bagian "panel pas masuk game"-nya.
- Begitu kamu keluar dari game (grace period ~12 detik), panel yang
  auto-muncul tadi otomatis nutup sendiri — kalau kamu sudah pin manual lewat
  saklar "Floating Quick Panel", punya kamu nggak akan diganggu sama sekali.
- Dinyalakan/dimatikan dari saklar **Auto Game Mode** (Modules maupun Quick
  Functions di Boost) — pola opt-in yang sama seperti service lain di app
  ini, plus self-healing: buka layar Modules lagi otomatis restart watcher
  kalau sempat di-kill OEM battery manager.

**3. Panel dirombak total — bukan kotak-kotak polos lagi**
- Bubble sekarang lingkaran gradasi merah dengan border cyan + elevation,
  bukan kotak teks flat.
- Panel dapat rounded corner + border tipis cyan-transparan + elevation
  (drop shadow asli), plus animasi masuk fade + naik 160ms — nggak lagi
  muncul mendadak.
- **Header baru**: begitu panel dipicu otomatis oleh game, header
  nampilin "▶ <Nama Game> detected" — ini yang bikin jelas *kenapa* panel
  itu nongol, bukan cuma dekorasi.
- 7 tombol aksi (Trim/DND/FPS/Guide/Split/Open/Close) sekarang dibungkus
  `HorizontalScrollView` supaya nggak lagi kepotong/numpuk di HP layar
  sempit — sebelumnya baris tombol bisa overflow di luar tepi layar.
- Tombol jadi pill rounded dengan border warna, tombol Close dikasih warna
  merah solid biar beda dari aksi lain.
- Panel auto-muncul akan collapse sendiri balik ke bubble ~4.5 detik
  kemudian — nyapa lalu minggir, gak nutupin game terus-terusan.


## Update terbaru (revisi ke-10) — Ikon lengkap, splash screen, signing, dukungan RAM 1-12GB+

**1. Ikon dibereskan total, bukan cuma foreground vector**
- PNG launcher lama di `mipmap-mdpi/hdpi/xhdpi/xxhdpi/xxxhdpi` (`ic_launcher.png`
  dan `ic_launcher_round.png`) **digambar ulang** dari logo baru — sebelumnya
  cuma adaptive icon (API 26+) yang ke-update, HP API 24-25 masih lihat logo
  lama. Sekarang semua level API lihat logo yang sama.
- Ditambahkan **monochrome layer** (`ic_xboost_logo_monochrome.xml`) buat
  themed icon Android 13+ — kalau user aktifin ikon ngikut wallpaper, XBoost
  ikut nampilin siluet bolt-X, bukan jatuh ke ikon abu-abu generik.
- Ikon 512×512 buat Play Store listing digenerate di luar folder res (lihat
  pesan chat, filenya `play_store_icon_512.png`) — bukan bagian dari APK, itu
  aset upload store terpisah.

**2. Splash screen resmi (`androidx.core:core-splashscreen`)**
- `Theme.XBoost.Splash` di `themes.xml`, dipasang sebagai theme awal
  `MainActivity` di manifest, otomatis balik ke `Theme.XBoost` lewat
  `postSplashScreenTheme` begitu frame pertama Compose selesai digambar.
  Native di Android 12+, digambar kompatibel oleh library di Android 7-11 —
  tidak ada cabang kode manual per versi.

**3. Release signing beneran, bukan build unsigned**
- `app/keystore.properties` + `app/xboost-release.keystore.jks` disertakan
  supaya `./gradlew assembleRelease` / `bundleRelease` langsung jalan tanpa
  setup tambahan. **Baca catatan di `keystore.properties`** — keystore ini
  aman buat testing tapi HARUS diganti keystore milik sendiri sebelum publish
  publik ke Play Store (siapa saja yang pegang file ini bisa re-sign update
  atas nama app kamu).

**4. Dukungan device 1GB–12GB+ RAM dibuat nyata, bukan cuma label**
`DeviceCompat.classify()` (sudah ada sejak revisi ke-8: LOW/MID/HIGH dari RAM
asli) sekarang benar-benar **mengubah rendering**, bukan cuma angka di layar
Settings:
- `LocalDeviceProfile` (CompositionLocal baru) menyebarkan tier device ke
  semua layar Compose sekali di root `XBoostTheme`.
- Hex dial di BoostScreen: di device LOW tier (~1-3GB), animasi ring diperlambat
  (11s vs 6s) dan ring kedua yang berlawanan arah **tidak digambar sama
  sekali** — sekitar setengah beban re-draw per frame dibanding device
  MID/HIGH, karena animasi terus-menerus di Canvas itu nyata biayanya di CPU
  budget device 1-2GB.
- Floating Panel: ikon favorit dibatasi ke 2 (bukan 4) di LOW tier, dan
  interval baca suhu ikut `pollingFloorMs` per-tier alih-alih hardcode 3
  detik buat semua device.
- Settings → Device Compatibility sekarang secara eksplisit bilang XBoost
  didesain jalan dari ~1GB sampai 12GB+ RAM dengan detail apa yang
  auto-scale.

Batasan jujur: ini bukan "RAM booster ajaib" yang bikin device 1GB jadi
serasa 12GB — itu di luar kemampuan software apapun tanpa root/hardware
baru. Yang beneran terjadi adalah XBoost sendiri **tidak menambah beban** ke
device lemah dengan cara memangkas biaya CPU/baterai fitur monitoring &
overlay-nya sendiri, sesuai kapasitas riil device.


## Update terbaru (revisi ke-9) — Logo baru, Split Screen & Floating Apps

**1. Logo diperbarui** — `ic_xboost_logo.xml` diganti total: hex-shield
angular berlapis, bolt-X merah bergradasi + aksen cyan, dipakai sebagai
adaptive icon foreground (Android 8+). File launcher PNG lama di
`mipmap-*` masih dipakai apa adanya di Android < 8; kalau mau ikon lama
ikut ganti total, generate ulang lewat Image Asset tool di Android Studio
dari vector baru ini.

**2. Modul baru: Split Screen & Floating Apps** (Modules → kartu ke-9)
- **Split Screen pair** — pilih App A / App B, satu tombol "Launch Split"
  membuka App A lalu App B dengan `FLAG_ACTIVITY_LAUNCH_ADJACENT`
  (`SplitScreenManager.kt`). **Jujur soal batasannya**: tidak ada API
  non-root yang bisa memaksa HP masuk ke split-screen dari nol — itu memang
  dibatasi Android supaya app pihak ketiga tidak bisa membajak layar. Yang
  beneran terjadi: sekali kamu sudah masuk mode split (lewat Recents →
  ikon app → "Split screen", gesture resmi Android 7+), tombol ini akan
  benar-benar menaruh App B di panel kedua, bukan menimpa App A.
- **Floating Bubble Favorites** — hingga 4 app dipilih sebagai ikon
  quick-launch di dalam panel bubble yang sudah ada (`FloatingPanelService`).
  Ini bagian "aplikasi layang/mengambang"-nya: bubble yang sudah bisa
  di-drag sekarang juga bisa langsung membuka app favorit di atas game yang
  sedang berjalan, dan tombol **Split** baru di panel memakai pasangan App
  A/App B yang sama tanpa perlu buka XBoost dulu.
- Semua pengaturan ini ada di layar baru **Split Screen & Floating Apps**
  (Settings → Modules → kartu baru), disimpan lewat DataStore seperti modul
  lain.


Fondasi UI terinspirasi tampilan gahar Nubia RedMagic (hex boost dial, merah-cyan,
angular, minim ikon emoji — pakai logo/vector icon). Semua data di layar Boost
dibaca **real-time dari device**, bukan animasi acak.

## Update terbaru (revisi ke-8) — Game Modules, panel "Game Mode" penuh, kompatibilitas device

Tiga hal utama yang diminta di revisi ini, semuanya real:

**1. Game AI Assistant & Guide — modul ke-11, per-game**
Modul baru di Settings → Modules (toggle "Game AI Assistant & Guide") yang
memunculkan tab **"AI Tips & Guide"** di tiap kartu game di Game Library.
Dua tab di dalamnya:
- **AI Tips** — chat box, kamu ketik pertanyaan **atau tap tombol mic buat
  ngomong langsung** (mis. "sensitivitas", "drop"), XBoost mencocokkan ke
  tabel tips terkurasi per game secara **offline, di device**
  (`GameContentRepository.kt`). Voice input lewat intent standar Android
  `RECOGNIZE_SPEECH` — diteruskan ke recognizer sistem (Google app/OEM
  equivalent), XBoost sendiri **tidak pernah merekam audio**, jadi tidak
  butuh izin RECORD_AUDIO. Kalau device tidak punya speech recognizer
  terpasang, tombol mic kasih tahu apa adanya lewat toast, bukan diam saja.
  Ini bukan model AI cloud, dan **tidak pernah membaca memori game,
  meng-inject input, atau mengotomasi permainan** — itu di luar scope
  XBoost secara sengaja (lihat bagian "Yang TIDAK dimasukkan" di bawah).
  Jujur dari awal: ini buku tips yang bisa ditanya (ketik atau suara),
  bukan bot yang main buat kamu.
- **Guide** — daftar tips strategi/setelan yang selalu terlihat per game
  (loot priority, rotasi zona, team comp, sensitivity, dst — general
  gameplay knowledge, bukan exploit).

Konten tersedia untuk 5 game yang sudah dikenal XBoost (PUBG Mobile, Mobile
Legends, Genshin Impact, COD Mobile, Free Fire) + fallback tips umum
(lag/FPS, thermal, baterai, koneksi) buat game lain.

**2. Floating Quick Panel jadi panel "Game Mode" beneran**
Panel yang muncul saat bubble di-tap sekarang punya:
- **Suhu real-time** — baca ulang tiap 3 detik dari `ThermalGuardManager`,
  berhenti otomatis begitu panel ditutup (gak nguras baterai).
- Tombol **FPS** — nyala/matiin FPS Overlay langsung dari panel, status
  tersimpan sinkron ke Modules.
- Tombol **Guide** — buka XBoost langsung ke tab AI Assistant & Guide untuk
  game yang lagi di foreground (kalau game itu dikenali); kalau tidak, jatuh
  ke Game Library, bukan menebak.
- Tombol Trim/DND/Open/Close yang sudah ada tetap ada.

**3. Kompatibilitas device diperluas (`DeviceCompat.kt`)**
- Deteksi tier device (LOW/MID/HIGH) dari RAM total & flag `isLowRamDevice`
  bawaan Android — bukan dari nama device yang di-hardcode.
- Kecepatan polling live-stat sekarang **di-clamp ke device**, bukan cuma ke
  mode: di HP RAM kecil, mode Performance tetap dibatasi minimal ~1.5 detik
  antar-refresh biar loop monitoring sendiri gak jadi beban CPU tambahan.
  Angka aslinya kelihatan jujur di Settings → Device Compatibility.
- Ditambahkan `<queries>` di manifest buat 5 known-game package — tanpa ini,
  deteksi Game Library **diam-diam gagal** di Android 11+ (API 30+) karena
  package visibility, walau game-nya beneran ke-install. Ini bug lama yang
  baru ketahuan & diperbaiki di revisi ini.

## Update sebelumnya (revisi ke-7) — Support Developer

Settings → **Support Developer**, layar baru dengan aksi real:
- **Donate** — buka link donasi (isi `DeveloperInfo.kt` dengan link Saweria/Trakteer/Ko-fi kamu sendiri)
- **Rate on Play Store** — buka listing app via `market://` intent
- **Share XBoost** — share sheet Android standar
- **Contact/Feedback** — kirim email via `mailto:` intent
- Telegram/Instagram — opsional, sembunyi otomatis kalau link dikosongin

**Penting:** semua link di `core/DeveloperInfo.kt` masih placeholder
(`support@example.com`, `saweria.co/yourname`, dst) — saya sengaja gak
ngarang link asli. Ganti sendiri sebelum publish.

**Soal atribusi:** tidak ada nama AI/assistant apapun di kode, nama app,
comment, atau README — sudah dicek ulang di seluruh project, bersih.

## Update sebelumnya (revisi ke-6) — Landscape lock + Floating Quick Panel

- **Orientasi dikunci landscape** (`android:screenOrientation="landscape"` di `MainActivity`). `LockScreenActivity` sengaja dibiarkan tidak dikunci karena dia muncul di atas app/game lain yang orientasinya bisa beda.
- **Navigasi diganti ke `NavigationRail`** (sisi kiri) — pola Material3 standar buat layar landscape, gak makan tinggi layar kayak bottom bar.
- **BoostScreen dirombak jadi 2 kolom**: kiri = hex dial + mode, kanan = monitor live + quick functions. Hex dial diperkecil biar muat di tinggi landscape phone (~360–420dp).
- **GamesScreen jadi grid 2 kolom**, **MetricsScreen** grafik RAM/CPU & Storage/Device disandingkan — manfaatin lebar landscape.
- **Fitur baru: Floating Quick Panel** (modul ke-10) — bubble merah melayang yang bisa di-drag, tap buat expand jadi toolbar mini (Trim / DND / Open / Close), nyambung ke `BoosterEngine` yang sama kayak fitur lain. Ini paling deket sama referensi gambar awal kamu (panel Basic Features/Quick Tools ala Samsung Game Booster).

## Update sebelumnya (revisi ke-5) — Settings > Modules, 9 modul pilih sendiri

Sekarang ada layar **Modules** baru (Settings → Manage Modules) — konsep "pasang
modul yang kamu mau" persis kayak modul tweak no-root. 9 modul, semuanya real:

1. **Background Trim** — kill cached background apps
2. **Game DND** — silent notifikasi saat boost
3. **Screen Awake** — layar gak mati selama XBoost dibuka
4. **Auto Game Mode** — jalanin profile per-game otomatis
5. **FPS Boost Overlay** — window FPS real di atas game (Choreographer)
6. **App Lock** — PIN-protect app pilihan (nav ke layar sendiri)
7. **High Refresh Rate (120Hz)** — lihat batasan jujurnya di bawah
8. **Thermal Guard** — suhu baterai real, warning warna saat panas
9. **Background Persistence** — exempt dari Doze biar App Lock & FPS Overlay gak gampang dibunuh OEM

### Soal modul "buka 120Hz" — jujur dari awal
Gak ada API resmi buat app pihak ketiga maksa **game lain** jalan di refresh
rate lebih tinggi tanpa root/ADB (`WRITE_SECURE_SETTINGS` gak bisa didapat app
biasa). Kalau ada booster app yang klaim bisa "unlock 120Hz di game kamu"
tanpa root, itu klaim yang gak sesuai cara kerja Android. Yang modul ini
beneran lakukan:
- Nunjukin refresh rate asli yang didukung hardware kamu
- Minta refresh rate tertinggi buat **window XBoost sendiri**
- Antar langsung ke Settings > Display, tempat kamu bisa ganti refresh rate
  sistem cuma 2 tap — itu satu-satunya cara sah tanpa root

## Update sebelumnya (revisi ke-4) — Performance Module, 3 mode beneran beda aksi

Sebelumnya Balance/Performance/Battery Save cuma label. Sekarang ketiganya
adalah **modul performa no-root** — tiap mode benar-benar mengubah setting
berbeda, real dan bisa dicek langsung di device:

| | Performance | Balance | Battery Save |
|---|---|---|---|
| Brightness | 85% (manual) | tidak diubah (adaptive) | 35% (manual) |
| Screen timeout | 120s | tidak diubah | 15s |
| Kecepatan monitor live | tiap 500ms | tiap 1000ms | tiap 3000ms |
| Trim background apps | ya, agresif | ya | **skip** (hemat baterai, karena trim sendiri makan CPU) |
| Game DND default | ON | OFF | OFF |
| Screen Awake default | ON | OFF | OFF |

Semua lewat `PerformanceModuleManager.kt` — dipicu tiap kali user pilih mode
di layar Boost, hasilnya ditampilkan apa adanya (termasuk kalau ada yang
di-skip karena izin belum di-grant), bukan pura-pura berhasil.

### Kenapa cuma segini, dan kenapa itu memang wajar
Ini **plafon jujur** yang bisa dilakukan app non-root di Android modern:
brightness & timeout (butuh izin *Modify System Settings*), agresivitas
trim background app (dibatasi OS sejak Android 8+), dan kecepatan polling
app sendiri (real, mengurangi wake-up CPU untuk proses XBoost sendiri).
XBoost **tidak** menyentuh CPU governor, GPU clock, atau RAM app lain —
itu butuh root. Efeknya nyata tapi sedang (mengurangi kontensi
background & overhead baterai), bukan overclock ajaib — sama seperti
semua "game booster no-root" lain di Play Store yang jujur soal batasannya.

## Update sebelumnya (revisi ke-3) — fitur baru
Semua real, tidak ada yang cuma UI kosong:

| Fitur | Cara kerja nyata | Izin tambahan |
|---|---|---|
| **FPS Overlay** | Window overlay + `Choreographer` vsync callback, hitung frame/detik asli | Display over other apps |
| **Game Mode Profile per-game** | Tiap game di Game Library bisa disetel DND & Screen Awake sendiri, disimpan DataStore, otomatis dipakai saat Auto Game Mode aktif | — |
| **App Lock** | PIN 4-digit (di-hash SHA-256), `LockGuardService` poll foreground app tiap 500ms via UsageStatsManager, munculin PIN screen | Display over other apps + Usage Access |
| **Accent color picker** | 4 warna (Red/Cyan/Purple/Green), berlaku ke hex dial & header lewat `CompositionLocal` | — |
| **Home screen widget** | RAM/CPU mini, `RemoteViews`, refresh instan saat di-tap | — |
| **Storage info** | `StatFs` — ruang kosong/total device asli | — |

### Batasan jujur yang perlu ditahu
- **FPS Overlay** mengukur vsync render dari proses XBoost sendiri (pendekatan yang sama dipakai semua overlay FPS non-root), bukan pembacaan langsung engine game — tidak ada API publik untuk itu tanpa root.
- **App Lock** hanya aktif selagi `LockGuardService` hidup. OEM yang agresif membunuh background service (MIUI, ColorOS, dll) bisa menghentikannya — batasan yang sama dialami semua app-locker non-root, bukan bug XBoost. Alternatif lebih andal (AccessibilityService) sengaja tidak dipakai karena minta izin privasi jauh lebih luas dari yang dibutuhkan fitur ini.
- **Widget** dibatasi Android minimal update 30 menit (`updatePeriodMillis` di-clamp OS) — makanya ada tombol refresh manual di widget-nya.
- **Accent color** baru mewarnai hex dial & header (elemen paling terlihat). Rekolor seluruh app (semua card, ikon, border) belum — itu roadmap berikutnya karena banyak layar masih pakai warna hardcoded.
- **Screenshot/Screen Record** sengaja belum dibuat — butuh `MediaProjection` yang minta izin popup tiap kali dibuka + foreground service simpan file, scope-nya beda batch.

## Update sebelumnya (revisi ke-2)
Semua kekurangan dari revisi sebelumnya sudah diperbaiki:
- ✅ **5 layar lengkap + bottom navigation**: Boost, Games, Network, Metrics, Settings
- ✅ **Permission flow**: kartu kuning muncul otomatis kalau Usage Access / Notification
  Access belum di-grant, dengan tombol yang langsung buka halaman Settings yang tepat
  (status ke-detect ulang otomatis begitu user balik ke app)
- ✅ **6 Quick Functions dipangkas dari 12 → 6, semuanya real** (tidak ada lagi tombol
  kosong `{ }`): Clear Cache, Game DND, Screen Awake, Ping Check, Power Saver, Auto Game Mode
- ✅ **State tersimpan** pakai DataStore (mode Balance/Performance/Battery, toggle fungsi,
  Auto Game Mode) — tidak reset saat app ditutup
- ✅ **Animasi hex ring pause otomatis** saat app di-background (dipantau via
  Lifecycle observer), hemat baterai
- ✅ **`SYSTEM_ALERT_WINDOW` dihapus** dari manifest karena belum ada fitur overlay
  yang memakainya — menghindari red flag review Play Store
- ✅ Layar **Games** menampilkan game yang **benar-benar terinstall** di device (bukan
  daftar statis), layar **Metrics** punya grafik RAM/CPU real 40 detik terakhir +
  info baterai/uptime asli, layar **Network** punya tes ping real yang bisa di-refresh

## Cara build
1. Buka folder ini di Android Studio (Koala/Ladybug ke atas).
2. Biarkan Gradle sync otomatis (butuh koneksi internet untuk download dependency).
3. Run ke device/emulator (`minSdk 26` / Android 8.0+).
4. Untuk APK release: `Build > Generate Signed App Bundle / APK`.

## Fungsi yang REAL dan langsung jalan
| Fitur | Cara kerja | File |
|---|---|---|
| RAM live | `ActivityManager.MemoryInfo`, publik, tanpa izin khusus | `SystemMonitor.kt` |
| CPU live | Baca `/proc/stat` 2x lalu hitung delta | `SystemMonitor.kt` |
| Ping live | Cek latency ke `8.8.8.8` | `SystemMonitor.kt` |
| Clear/trim background apps | `ActivityManager.killBackgroundProcesses()` per app | `BoosterEngine.kt` |
| Game DND | `NotificationManager.setInterruptionFilter()` | `BoosterEngine.kt` |
| Deteksi game di foreground | `UsageStatsManager` | `BoosterEngine.kt` |

## Izin yang HARUS di-grant manual oleh user (batasan OS Android, bukan bug)
- **Usage access** (buat deteksi game aktif) → user diarahkan ke
  `Settings > Apps > Special access > Usage access`.
- **Notification access** (buat Game DND) → `Settings > Apps > Special access > Notification access`.
- Android **tidak mengizinkan** aplikasi pihak ketiga memberi izin ini ke diri
  sendiri secara otomatis — ini proteksi sistem, semua booster app resmi di
  Play Store juga wajib lewat alur yang sama.

## Yang TIDAK dimasukkan karena secara teknis tidak mungkin tanpa root
- Overclock/underclock CPU-GPU sungguhan
- Memaksa "membebaskan" RAM milik app lain
- Ubah CPU governor / thermal profile pabrik

## Yang TIDAK dimasukkan secara sengaja (bukan soal teknis, tapi soal batasan yang benar)
- **Autoplay / aim-assist / macro / input injection ke game manapun.** Modul
  "AI Assistant" sengaja dibuat sebagai pencarian tips offline (lihat revisi
  ke-8), bukan bot yang membaca layar/memori game atau mengirim input
  otomatis. Fitur semacam itu melanggar ToS hampir semua game online,
  berisiko kena ban akun pengguna, dan bukan sesuatu yang mau dibangun
  XBoost — beda dari batasan teknis root di atas, ini pilihan desain sadar.

Kalau ada app booster yang klaim bisa itu tanpa root, itu tampilan palsu
(placebo UI) — bukan sesuatu yang OS Android izinkan sejak sandboxing ketat
diberlakukan (Android 8+). Jujur soal ini penting supaya XBoost tidak jadi
app "bohong" seperti kebanyakan game booster di Play Store.

## Struktur project
```
xboost-android/
  app/src/main/java/com/xboost/app/
    MainActivity.kt
    core/SystemMonitor.kt       # baca RAM/CPU/ping/storage real
    core/BoosterEngine.kt       # aksi boost real
    core/PermissionManager.kt   # cek status izin real + deep-link ke Settings
    core/PreferencesManager.kt  # DataStore: mode, toggle, profile per-game, accent, PIN
    overlay/FpsOverlayService.kt   # window overlay real, ukur FPS via Choreographer
    lock/PinHasher.kt              # hash PIN, sesi unlock
    lock/LockGuardService.kt       # poll foreground app, trigger lock screen
    lock/LockScreenActivity.kt     # UI PIN full-screen
    widget/XBoostWidgetProvider.kt # widget homescreen RAM/CPU
    core/DisplayRefreshManager.kt  # info refresh rate real + request untuk window sendiri
    core/ThermalGuardManager.kt    # baca suhu baterai real
    core/CustomModuleEngine.kt     # engine + katalog buat Module Installer (non-root)
    ui/theme/                   # warna, tipografi, LocalAccent (CompositionLocal)
    ui/nav/XBoostNav.kt         # bottom navigation, 5 destinasi + route modules/app_lock
    ui/screens/
      BoostScreen.kt      # hex dial, gauge live, permission card, quick functions, 3-mode module
      GamesScreen.kt      # game terinstall + profile DND/Screen Awake per game
      NetworkScreen.kt    # ping test real
      MetricsScreen.kt    # grafik RAM/CPU 40 detik + storage + info device
      SettingsScreen.kt   # izin, accent picker, entry ke Modules
      ModulesScreen.kt    # modul pilih sendiri, termasuk entry ke Module Installer
      ModuleInstallerScreen.kt # pasang modul dari katalog atau bikin manual
      AppLockScreen.kt    # set PIN, pilih app, nyalain lock guard service
```

## Langkah lanjutan yang disarankan
1. Ganti font sistem dengan Rajdhani/Chakra Petch (taruh `.ttf` di `res/font/`)
   supaya persis referensi visual.
2. Tambah layar Games/Network/Metrics/Settings (skeleton belum dibuat di sini
   biar project tetap ringkas — pola sudah ada di `BoostScreen.kt` untuk ditiru).
3. Kalau target-nya ekspor ke Play Store: pastikan deskripsi listing tidak
   mengklaim "overclock" atau "boost RAM app lain" — itu melanggar kebijakan
   Google Play soal klaim performa yang tidak bisa dibuktikan.
